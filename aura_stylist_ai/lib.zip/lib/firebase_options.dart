// ⚠️⚠️⚠️ PLACEHOLDER FILE — DO NOT USE THESE VALUES AS-IS ⚠️⚠️⚠️
//
// This file mimics the output of the FlutterFire CLI so the project
// structure and `main.dart` are correct and complete, but every value below
// is a dummy placeholder. It WILL NOT connect to a real Firebase project.
//
// To generate the real version:
//   1. Create a project at https://console.firebase.google.com
//   2. Install the CLI:  dart pub global activate flutterfire_cli
//   3. From the project root (where pubspec.yaml lives), run:
//        flutterfire configure
//      This walks you through selecting your Firebase project and target
//      platforms, and REPLACES this file with real generated values. It
//      also drops the native config files Firebase needs
//      (android/app/google-services.json,
//       ios/Runner/GoogleService-Info.plist, etc.) — those can't be faked
//      here since they depend on your actual Firebase project.
//   4. In the Firebase Console, enable the sign-in providers you need under
//      Authentication > Sign-in method: Email/Password, Google, and
//      Anonymous (for Guest login).
//
// Do not check real API keys into public repos beyond what Firebase itself
// expects to be client-visible (these values are not secret the way a
// server API key would be, but treat your own project's quotas/config with
// normal care).

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform. '
          'Run `flutterfire configure` to add support, or add it manually.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'PLACEHOLDER_API_KEY',
    appId: '1:000000000000:web:0000000000000000000000',
    messagingSenderId: '000000000000',
    projectId: 'aura-stylist-ai-placeholder',
    authDomain: 'aura-stylist-ai-placeholder.firebaseapp.com',
    storageBucket: 'aura-stylist-ai-placeholder.appspot.com',
    databaseURL: 'https://aura-stylist-ai-placeholder-default-rtdb.firebaseio.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCQ4PpuWN2pA9kqWKvWtoGAFbEONZ8UZYA',
    appId: '1:58548553120:android:a41b12aa5fc8e659fb50c5',
    messagingSenderId: '58548553120',
    projectId: 'studentfoodservice-82f3b',
    databaseURL: 'https://studentfoodservice-82f3b-default-rtdb.firebaseio.com',
    storageBucket: 'studentfoodservice-82f3b.firebasestorage.app',
  );
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDMYeXdPHHEbL3x1TUG7NNYFGGjNeyUvic',
    appId: '1:58548553120:ios:85520f1ace925cecfb50c5',
    messagingSenderId: '58548553120',
    projectId: 'studentfoodservice-82f3b',
    databaseURL: 'https://studentfoodservice-82f3b-default-rtdb.firebaseio.com',
    storageBucket: 'studentfoodservice-82f3b.firebasestorage.app',
    iosBundleId: 'com.example.auraStylistAi',
  );
  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'PLACEHOLDER_API_KEY',
    appId: '1:000000000000:ios:0000000000000000000000',
    messagingSenderId: '000000000000',
    projectId: 'aura-stylist-ai-placeholder',
    storageBucket: 'aura-stylist-ai-placeholder.appspot.com',
    databaseURL: 'https://aura-stylist-ai-placeholder-default-rtdb.firebaseio.com',
    iosBundleId: 'com.example.auraStylistAi',
  );
}
