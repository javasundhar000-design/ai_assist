import 'dart:async';

import 'package:flutter/foundation.dart';

/// Bridges a `Stream` to `go_router`'s `refreshListenable`.
///
/// `GoRouter` only knows how to listen to a `Listenable` (like a
/// `ChangeNotifier`), not a raw `Stream`. This wraps the auth repository's
/// `authStateChanges` stream so that every time Firebase reports a sign-in
/// or sign-out, the router re-evaluates its `redirect` callback.
class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Stream<dynamic> stream) {
    notifyListeners();
    _subscription = stream.asBroadcastStream().listen((_) => notifyListeners());
  }

  late final StreamSubscription<dynamic> _subscription;

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }
}
