import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:go_router/go_router.dart';
import '../../features/auth/presentation/pages/forgot_password_page.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/auth/presentation/providers/auth_providers.dart';
import '../../features/dashboard/presentation/pages/dashboard_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';
import '../../features/settings/presentation/pages/settings_page.dart';
import '../../features/smart_camera/presentation/pages/smart_camera_page.dart';
import '../../features/splash/presentation/pages/splash_page.dart';
import '../../features/wardrobe/presentation/pages/wardrobe_page.dart';
import 'app_routes.dart';
import 'go_router_refresh_stream.dart';

/// App-wide router with an auth-aware `redirect`.
///
/// Guard logic:
///  - While on the splash screen, never redirect — `SplashPage` itself
///    decides where to go once its bootstrap sequence finishes (see
///    `SplashController` / `SplashPage`).
///  - Signed out + trying to reach a non-auth route -> send to /login.
///  - Signed in + sitting on an auth route (login/register/forgot) -> send
///    to /dashboard.
///
/// `redirect` deliberately checks `authRepository.currentUser` — a
/// synchronous read of Firebase Auth's own cached user — rather than
/// `authStateChangesProvider` (a Riverpod `StreamProvider` subscribed
/// independently to the same underlying stream). That used to be a real
/// bug: `refreshListenable` below fires the instant Firebase's auth-state
/// stream emits, which re-runs `redirect` immediately, but the separate
/// Riverpod subscription hadn't necessarily processed that same event yet
/// at that exact moment — so `redirect` would read one tick stale and
/// decide "still logged out," and since nothing else re-triggers it
/// afterward, sign-in would silently leave the user stuck on the login
/// screen despite Firebase having authenticated them correctly.
/// `currentUser` has no such lag: the SDK sets it synchronously as part
/// of completing sign-in, before the stream event even fires.
final routerProvider = Provider<GoRouter>((ref) {
  final authRepository = ref.watch(authRepositoryProvider);

  return GoRouter(
    initialLocation: AppRoutes.splash,
    debugLogDiagnostics: true,
    refreshListenable: GoRouterRefreshStream(authRepository.authStateChanges),
    redirect: (context, state) {
      final location = state.matchedLocation;

      if (location == AppRoutes.splash) return null;

      final isLoggedIn = authRepository.currentUser != null;
      final isAuthRoute = location == AppRoutes.login ||
          location == AppRoutes.register ||
          location == AppRoutes.forgotPassword;

      if (!isLoggedIn && !isAuthRoute) return AppRoutes.login;
      if (isLoggedIn && isAuthRoute) return AppRoutes.dashboard;
      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.splash,
        name: 'splash',
        builder: (context, state) => const SplashPage(),
      ),
      GoRoute(
        path: AppRoutes.login,
        name: 'login',
        builder: (context, state) => const LoginPage(),
      ),
      GoRoute(
        path: AppRoutes.register,
        name: 'register',
        builder: (context, state) => const RegisterPage(),
      ),
      GoRoute(
        path: AppRoutes.forgotPassword,
        name: 'forgotPassword',
        builder: (context, state) => const ForgotPasswordPage(),
      ),
      GoRoute(
        path: AppRoutes.dashboard,
        name: 'dashboard',
        builder: (context, state) => const DashboardPage(),
      ),
      GoRoute(
        path: AppRoutes.profile,
        name: 'profile',
        builder: (context, state) => const ProfilePage(),
      ),
      GoRoute(
        path: AppRoutes.smartMirror,
        name: 'smartMirror',
        builder: (context, state) => const SmartCameraPage(),
      ),
      GoRoute(
        path: AppRoutes.wardrobe,
        name: 'wardrobe',
        builder: (context, state) => const WardrobePage(),
      ),
      GoRoute(
        path: AppRoutes.settings,
        name: 'settings',
        builder: (context, state) => const SettingsPage(),
      ),
    ],
  );
});
