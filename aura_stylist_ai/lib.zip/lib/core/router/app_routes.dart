/// Central registry of route paths/names.
///
/// Every module adds its route(s) here rather than hard-coding path strings
/// in `go_router` calls scattered around the app. Keeps navigation
/// refactor-safe as more modules (Auth, Dashboard, Camera, ...) land.
class AppRoutes {
  AppRoutes._();

  static const String splash = '/';

  // --- Registered by Module 2 (Auth) ---
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';

  // --- Registered by Module 2 (temporary placeholder) / owned by Module 3 (Dashboard) ---
  static const String dashboard = '/dashboard';

  // --- Registered by Module 3 (Profile) ---
  static const String profile = '/profile';

  // --- Registered by Module 4 (Smart Camera pipeline) ---
  static const String smartMirror = '/smart-mirror';

  // --- Registered by Module 10 (Wardrobe/Favorites/History — one page, three tabs) ---
  static const String wardrobe = '/wardrobe';

  // --- Registered by Module 11 (Settings) ---
  static const String settings = '/settings';
}
