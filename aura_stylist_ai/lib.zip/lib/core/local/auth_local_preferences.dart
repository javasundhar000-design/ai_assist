import 'package:shared_preferences/shared_preferences.dart';

/// Thin wrapper around [SharedPreferences] for auth-related local state.
///
/// Firebase Auth on mobile always persists the session locally (there's no
/// SDK-level "session only" mode like on web) — so "Remember Me" is
/// implemented as an app-level preference: if the user unchecks it, we
/// force a sign-out the *next* time the app cold-starts (see
/// `AuthRepository.applyRememberMePreference`), rather than trying to fight
/// Firebase's persistence layer.
class AuthLocalPreferences {
  AuthLocalPreferences(this._prefs);

  final SharedPreferences _prefs;

  static const _rememberMeKey = 'auth_remember_me';

  bool get rememberMe => _prefs.getBool(_rememberMeKey) ?? true;

  Future<void> setRememberMe(bool value) => _prefs.setBool(_rememberMeKey, value);
}
