import 'app_permission.dart';

/// Contract for checking/requesting OS permissions. Controllers depend on
/// this, never on `permission_handler` directly — see
/// `FakePermissionGateway` in tests.
abstract class PermissionGateway {
  Future<AppPermissionState> checkStatus(AppPermission permission);
  Future<AppPermissionState> request(AppPermission permission);

  /// Opens the OS app-settings screen (used when a permission is
  /// permanently denied and can only be fixed there).
  Future<void> openSettings();
}
