import 'package:permission_handler/permission_handler.dart' as ph;

import 'app_permission.dart';
import 'permission_gateway.dart';

class PermissionHandlerGateway implements PermissionGateway {
  @override
  Future<AppPermissionState> checkStatus(AppPermission permission) async {
    final status = await _resolve(permission).status;
    return _map(status);
  }

  @override
  Future<AppPermissionState> request(AppPermission permission) async {
    final status = await _resolve(permission).request();
    return _map(status);
  }

  @override
  Future<void> openSettings() => ph.openAppSettings();

  ph.Permission _resolve(AppPermission permission) {
    switch (permission) {
      case AppPermission.camera:
        return ph.Permission.camera;
      case AppPermission.microphone:
        return ph.Permission.microphone;
    }
  }

  AppPermissionState _map(ph.PermissionStatus status) {
    if (status.isGranted || status.isLimited) return AppPermissionState.granted;
    if (status.isPermanentlyDenied) return AppPermissionState.permanentlyDenied;
    if (status.isRestricted) return AppPermissionState.restricted;
    return AppPermissionState.denied;
  }
}
