/// Permissions the app requests, abstracted away from any specific plugin.
enum AppPermission { camera, microphone }

/// Normalized permission status, decoupled from `permission_handler`'s own
/// enum so the rest of the app (and tests) don't depend on that package
/// directly.
enum AppPermissionState {
  unknown,
  granted,
  denied,

  /// User denied and checked "don't ask again" (Android) / the OS won't
  /// re-prompt (iOS) — only recoverable by sending them to Settings.
  permanentlyDenied,

  /// e.g. blocked by parental controls / MDM policy.
  restricted,
}
