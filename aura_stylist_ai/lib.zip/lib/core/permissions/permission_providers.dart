import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'permission_gateway.dart';
import 'permission_handler_gateway.dart';

final permissionGatewayProvider = Provider<PermissionGateway>((ref) {
  return PermissionHandlerGateway();
});
