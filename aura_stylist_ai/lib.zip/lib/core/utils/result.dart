import '../errors/failure.dart';

/// A minimal success/failure result wrapper.
///
/// We deliberately avoid pulling in `dartz`/`fpdart` for a single Either
/// type — Dart 3 sealed classes + pattern matching give us the same safety
/// (the compiler forces both branches to be handled) with zero extra
/// dependency weight.
sealed class Result<T> {
  const Result();

  /// Pattern-match on the result. Both callbacks are required so callers
  /// can't forget to handle the failure case.
  R when<R>({
    required R Function(T data) success,
    required R Function(Failure failure) failure,
  }) {
    final self = this;
    return switch (self) {
      Success<T>() => success(self.data),
      Err<T>() => failure(self.failure),
    };
  }

  bool get isSuccess => this is Success<T>;
  bool get isFailure => this is Err<T>;

  /// Returns the success value, or `null` if this is a failure.
  T? get valueOrNull => switch (this) {
        Success<T>(data: final d) => d,
        Err<T>() => null,
      };
}

final class Success<T> extends Result<T> {
  const Success(this.data);
  final T data;
}

final class Err<T> extends Result<T> {
  const Err(this.failure);
  final Failure failure;
}
