/// Base type for all recoverable errors surfaced from repositories to the
/// presentation layer. Kept deliberately small — add subclasses as new
/// features need distinct error categories (e.g. `NetworkFailure`,
/// `StorageFailure` in later modules).
sealed class Failure {
  const Failure(this.message);

  /// User-facing, already human-readable message. Repositories are
  /// responsible for translating raw SDK exceptions into this.
  final String message;
}

/// Any failure originating from authentication (Firebase Auth, Google
/// Sign-In, local session handling).
class AuthFailure extends Failure {
  const AuthFailure(super.message, {this.code});

  /// Original error code (e.g. Firebase's `user-not-found`), kept for
  /// logging/analytics — not shown to the user directly.
  final String? code;
}

/// Fallback for anything unexpected (parsing errors, platform exceptions
/// not explicitly mapped, etc).
class UnknownFailure extends Failure {
  const UnknownFailure(super.message);
}
