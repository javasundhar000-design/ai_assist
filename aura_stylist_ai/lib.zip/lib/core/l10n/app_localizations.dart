import 'package:flutter/material.dart';

import 'app_locale.dart';

/// String keys, kept as constants rather than raw string literals at each
/// call site so a typo becomes a compile error via `AppLocalizations.t`'s
/// map lookup falling back to the key itself (visibly wrong in the UI)
/// rather than a silent no-op.
class AppL10nKeys {
  AppL10nKeys._();

  static const dashboardSubtitleReady = 'dashboardSubtitleReady';
  static const dashboardSubtitleGuest = 'dashboardSubtitleGuest';
  static const navSmartMirror = 'navSmartMirror';
  static const navAiRecommendations = 'navAiRecommendations';
  static const navWardrobe = 'navWardrobe';
  static const navFavorites = 'navFavorites';
  static const navOutfitHistory = 'navOutfitHistory';
  static const navSettings = 'navSettings';
  static const logout = 'logout';

  static const wardrobeTitle = 'wardrobeTitle';
  static const wardrobeTabAll = 'wardrobeTabAll';
  static const wardrobeTabFavorites = 'wardrobeTabFavorites';
  static const wardrobeTabHistory = 'wardrobeTabHistory';
  static const wardrobeSearchHint = 'wardrobeSearchHint';
  static const wardrobeEmptyAll = 'wardrobeEmptyAll';
  static const wardrobeEmptyFavorites = 'wardrobeEmptyFavorites';
  static const wardrobeEmptyHistory = 'wardrobeEmptyHistory';
  static const wardrobeOccasionAll = 'wardrobeOccasionAll';
  static const wardrobeOccasionLabel = 'wardrobeOccasionLabel';
  static const wardrobeSortLabel = 'wardrobeSortLabel';
  static const wearThisButton = 'wearThisButton';

  static const settingsTitle = 'settingsTitle';
  static const settingsAppearance = 'settingsAppearance';
  static const settingsThemeLight = 'settingsThemeLight';
  static const settingsThemeDark = 'settingsThemeDark';
  static const settingsThemeSystem = 'settingsThemeSystem';
  static const settingsLanguage = 'settingsLanguage';
  static const settingsSmartMirror = 'settingsSmartMirror';
  static const settingsGestureRecognition = 'settingsGestureRecognition';
  static const settingsGestureRecognitionSubtitle = 'settingsGestureRecognitionSubtitle';
  static const settingsVoiceConfirmation = 'settingsVoiceConfirmation';
  static const settingsVoiceConfirmationSubtitle = 'settingsVoiceConfirmationSubtitle';
  static const settingsDefaultCamera = 'settingsDefaultCamera';
  static const settingsCameraFront = 'settingsCameraFront';
  static const settingsCameraBack = 'settingsCameraBack';
  static const settingsAccount = 'settingsAccount';
  static const settingsSignOut = 'settingsSignOut';
  static const settingsAbout = 'settingsAbout';

  static const save = 'save';
  static const cancel = 'cancel';
}

/// Hand-rolled localization: a per-`AppLocale` string map plus a
/// `Localizations`-compatible delegate, deliberately **not** using
/// Flutter's `.arb` + `flutter gen-l10n` codegen pipeline.
///
/// Why hand-rolled: `gen-l10n` runs as a build-time step this environment
/// can't execute or verify (no Flutter SDK here — see the module README's
/// standing caveat), so shipping `.arb` files and trusting the generated
/// output to compile without ever having run the generator would be
/// exactly the kind of "looks complete but might not compile" risk this
/// whole build has avoided from Module 0 onward. A plain `Map<String,
/// String>` per locale needs no code generation and is just as real.
///
/// Coverage is intentionally partial, not app-wide: Dashboard, Wardrobe,
/// and Settings — the screens Module 11 itself adds or revisits — are
/// fully localized. Earlier modules' screens (auth forms, the Smart
/// Mirror HUD, recommendation/fashion-score sheets) still show English
/// text. Localizing every string across ten modules' worth of screens in
/// one pass would mean touching dozens of files no one asked to change
/// right now — safer to extend `_strings` screen-by-screen later than to
/// do it all at once, unreviewed, here.
class AppLocalizations {
  const AppLocalizations(this.locale);

  final AppLocale locale;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations) ??
        const AppLocalizations(AppLocale.en);
  }

  String t(String key) => _strings[locale]?[key] ?? _strings[AppLocale.en]![key] ?? key;

  static const Map<AppLocale, Map<String, String>> _strings = {
    AppLocale.en: {
      AppL10nKeys.dashboardSubtitleReady: 'Ready to find your next look?',
      AppL10nKeys.dashboardSubtitleGuest:
          'Browsing as guest — sign up anytime to save your looks.',
      AppL10nKeys.navSmartMirror: 'Smart Mirror',
      AppL10nKeys.navAiRecommendations: 'AI Recommendations',
      AppL10nKeys.navWardrobe: 'Wardrobe',
      AppL10nKeys.navFavorites: 'Favorites',
      AppL10nKeys.navOutfitHistory: 'Outfit History',
      AppL10nKeys.navSettings: 'Settings',
      AppL10nKeys.logout: 'Logout',
      AppL10nKeys.wardrobeTitle: 'Wardrobe',
      AppL10nKeys.wardrobeTabAll: 'All',
      AppL10nKeys.wardrobeTabFavorites: 'Favorites',
      AppL10nKeys.wardrobeTabHistory: 'History',
      AppL10nKeys.wardrobeSearchHint: 'Search saved looks',
      AppL10nKeys.wardrobeEmptyAll:
          'Nothing saved yet. Say "save" or give a thumbs up in the Smart Mirror to save your first look.',
      AppL10nKeys.wardrobeEmptyFavorites:
          'No favorites yet. Tap the heart on any saved look to add it here.',
      AppL10nKeys.wardrobeEmptyHistory: 'Your outfit history will show up here.',
      AppL10nKeys.wardrobeOccasionAll: 'All occasions',
      AppL10nKeys.wardrobeOccasionLabel: 'Occasion',
      AppL10nKeys.wardrobeSortLabel: 'Sort',
      AppL10nKeys.wearThisButton: 'Wear this in Smart Mirror',
      AppL10nKeys.settingsTitle: 'Settings',
      AppL10nKeys.settingsAppearance: 'Appearance',
      AppL10nKeys.settingsThemeLight: 'Light',
      AppL10nKeys.settingsThemeDark: 'Dark',
      AppL10nKeys.settingsThemeSystem: 'System default',
      AppL10nKeys.settingsLanguage: 'Language',
      AppL10nKeys.settingsSmartMirror: 'Smart Mirror',
      AppL10nKeys.settingsGestureRecognition: 'Gesture recognition',
      AppL10nKeys.settingsGestureRecognitionSubtitle:
          'Control the app with hand-raise and pose gestures',
      AppL10nKeys.settingsVoiceConfirmation: 'Spoken confirmations',
      AppL10nKeys.settingsVoiceConfirmationSubtitle:
          'Have the voice assistant speak back what it understood',
      AppL10nKeys.settingsDefaultCamera: 'Default camera',
      AppL10nKeys.settingsCameraFront: 'Front (selfie)',
      AppL10nKeys.settingsCameraBack: 'Back',
      AppL10nKeys.settingsAccount: 'Account',
      AppL10nKeys.settingsSignOut: 'Sign out',
      AppL10nKeys.settingsAbout: 'About AURA STYLIST AI',
      AppL10nKeys.save: 'Save',
      AppL10nKeys.cancel: 'Cancel',
    },
    AppLocale.ta: {
      AppL10nKeys.dashboardSubtitleReady: 'உங்கள் அடுத்த தோற்றத்தைக் கண்டறியத் தயாரா?',
      AppL10nKeys.dashboardSubtitleGuest:
          'விருந்தினராகப் பார்க்கிறீர்கள் — உங்கள் தோற்றங்களைச் சேமிக்க எப்போது வேண்டுமானாலும் பதிவு செய்யலாம்.',
      AppL10nKeys.navSmartMirror: 'ஸ்மார்ட் மிரர்',
      AppL10nKeys.navAiRecommendations: 'AI பரிந்துரைகள்',
      AppL10nKeys.navWardrobe: 'உடை அலமாரி',
      AppL10nKeys.navFavorites: 'பிடித்தவை',
      AppL10nKeys.navOutfitHistory: 'உடை வரலாறு',
      AppL10nKeys.navSettings: 'அமைப்புகள்',
      AppL10nKeys.logout: 'வெளியேறு',
      AppL10nKeys.wardrobeTitle: 'உடை அலமாரி',
      AppL10nKeys.wardrobeTabAll: 'அனைத்தும்',
      AppL10nKeys.wardrobeTabFavorites: 'பிடித்தவை',
      AppL10nKeys.wardrobeTabHistory: 'வரலாறு',
      AppL10nKeys.wardrobeSearchHint: 'சேமித்த தோற்றங்களைத் தேடு',
      AppL10nKeys.wardrobeEmptyAll:
          'இதுவரை எதுவும் சேமிக்கப்படவில்லை. ஸ்மார்ட் மிரரில் "save" என்று சொல்லவும் அல்லது தம்ஸ் அப் சைகை காட்டவும்.',
      AppL10nKeys.wardrobeEmptyFavorites:
          'பிடித்தவை இன்னும் இல்லை. சேமித்த தோற்றத்தின் இதயத்தை தட்டவும்.',
      AppL10nKeys.wardrobeEmptyHistory: 'உங்கள் உடை வரலாறு இங்கே தோன்றும்.',
      AppL10nKeys.wardrobeOccasionAll: 'அனைத்து சந்தர்ப்பங்களும்',
      AppL10nKeys.wardrobeOccasionLabel: 'சந்தர்ப்பம்',
      AppL10nKeys.wardrobeSortLabel: 'வரிசைப்படுத்து',
      AppL10nKeys.wearThisButton: 'ஸ்மார்ட் மிரரில் இதை அணியவும்',
      AppL10nKeys.settingsTitle: 'அமைப்புகள்',
      AppL10nKeys.settingsAppearance: 'தோற்றம்',
      AppL10nKeys.settingsThemeLight: 'வெளிச்சம்',
      AppL10nKeys.settingsThemeDark: 'இருள்',
      AppL10nKeys.settingsThemeSystem: 'சாதன இயல்புநிலை',
      AppL10nKeys.settingsLanguage: 'மொழி',
      AppL10nKeys.settingsSmartMirror: 'ஸ்மார்ட் மிரர்',
      AppL10nKeys.settingsGestureRecognition: 'சைகை அங்கீகாரம்',
      AppL10nKeys.settingsGestureRecognitionSubtitle:
          'கை-உயர்த்தும் மற்றும் நிலை சைகைகளால் ஆப்பைக் கட்டுப்படுத்தவும்',
      AppL10nKeys.settingsVoiceConfirmation: 'பேசும் உறுதிப்படுத்தல்கள்',
      AppL10nKeys.settingsVoiceConfirmationSubtitle:
          'குரல் உதவியாளர் புரிந்ததை மீண்டும் பேசட்டும்',
      AppL10nKeys.settingsDefaultCamera: 'இயல்புநிலை கேமரா',
      AppL10nKeys.settingsCameraFront: 'முன் (செல்·ஃபி)',
      AppL10nKeys.settingsCameraBack: 'பின்',
      AppL10nKeys.settingsAccount: 'கணக்கு',
      AppL10nKeys.settingsSignOut: 'வெளியேறு',
      AppL10nKeys.settingsAbout: 'AURA STYLIST AI பற்றி',
      AppL10nKeys.save: 'சேமி',
      AppL10nKeys.cancel: 'ரத்து செய்',
    },
    AppLocale.hi: {
      AppL10nKeys.dashboardSubtitleReady: 'अपना अगला लुक ढूंढने के लिए तैयार हैं?',
      AppL10nKeys.dashboardSubtitleGuest:
          'आप गेस्ट के रूप में देख रहे हैं — अपने लुक सेव करने के लिए कभी भी साइन अप करें।',
      AppL10nKeys.navSmartMirror: 'स्मार्ट मिरर',
      AppL10nKeys.navAiRecommendations: 'AI सिफारिशें',
      AppL10nKeys.navWardrobe: 'वॉर्डरोब',
      AppL10nKeys.navFavorites: 'पसंदीदा',
      AppL10nKeys.navOutfitHistory: 'आउटफिट इतिहास',
      AppL10nKeys.navSettings: 'सेटिंग्स',
      AppL10nKeys.logout: 'लॉगआउट',
      AppL10nKeys.wardrobeTitle: 'वॉर्डरोब',
      AppL10nKeys.wardrobeTabAll: 'सभी',
      AppL10nKeys.wardrobeTabFavorites: 'पसंदीदा',
      AppL10nKeys.wardrobeTabHistory: 'इतिहास',
      AppL10nKeys.wardrobeSearchHint: 'सेव किए गए लुक खोजें',
      AppL10nKeys.wardrobeEmptyAll:
          'अभी तक कुछ भी सेव नहीं हुआ। स्मार्ट मिरर में "save" बोलें या थम्स अप दिखाएं।',
      AppL10nKeys.wardrobeEmptyFavorites:
          'अभी तक कोई पसंदीदा नहीं। किसी भी सेव किए गए लुक पर दिल पर टैप करें।',
      AppL10nKeys.wardrobeEmptyHistory: 'आपका आउटफिट इतिहास यहां दिखेगा।',
      AppL10nKeys.wardrobeOccasionAll: 'सभी अवसर',
      AppL10nKeys.wardrobeOccasionLabel: 'अवसर',
      AppL10nKeys.wardrobeSortLabel: 'क्रमबद्ध करें',
      AppL10nKeys.wearThisButton: 'स्मार्ट मिरर में यह पहनें',
      AppL10nKeys.settingsTitle: 'सेटिंग्स',
      AppL10nKeys.settingsAppearance: 'दिखावट',
      AppL10nKeys.settingsThemeLight: 'लाइट',
      AppL10nKeys.settingsThemeDark: 'डार्क',
      AppL10nKeys.settingsThemeSystem: 'सिस्टम डिफ़ॉल्ट',
      AppL10nKeys.settingsLanguage: 'भाषा',
      AppL10nKeys.settingsSmartMirror: 'स्मार्ट मिरर',
      AppL10nKeys.settingsGestureRecognition: 'जेस्चर पहचान',
      AppL10nKeys.settingsGestureRecognitionSubtitle:
          'हाथ उठाने और पोज़ जेस्चर से ऐप नियंत्रित करें',
      AppL10nKeys.settingsVoiceConfirmation: 'बोली गई पुष्टि',
      AppL10nKeys.settingsVoiceConfirmationSubtitle:
          'वॉइस असिस्टेंट जो समझा उसे वापस बोले',
      AppL10nKeys.settingsDefaultCamera: 'डिफ़ॉल्ट कैमरा',
      AppL10nKeys.settingsCameraFront: 'फ्रंट (सेल्फी)',
      AppL10nKeys.settingsCameraBack: 'बैक',
      AppL10nKeys.settingsAccount: 'खाता',
      AppL10nKeys.settingsSignOut: 'साइन आउट',
      AppL10nKeys.settingsAbout: 'AURA STYLIST AI के बारे में',
      AppL10nKeys.save: 'सेव करें',
      AppL10nKeys.cancel: 'रद्द करें',
    },
  };
}

class AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const AppLocalizationsDelegate();

  static const supportedLocales = [Locale('en'), Locale('ta'), Locale('hi')];

  @override
  bool isSupported(Locale locale) =>
      supportedLocales.any((l) => l.languageCode == locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    final appLocale = AppLocaleMeta.fromLanguageCode(locale.languageCode) ?? AppLocale.en;
    return AppLocalizations(appLocale);
  }

  @override
  bool shouldReload(AppLocalizationsDelegate old) => false;
}
