import 'package:flutter/material.dart';

/// The three languages the spec's "LOCALIZATION" section calls for:
/// English, Tamil, Hindi.
enum AppLocale { en, ta, hi }

extension AppLocaleMeta on AppLocale {
  Locale get locale => Locale(name);

  /// Shown in `SettingsPage`'s language picker, always in that language's
  /// own script (not translated into whatever the current locale is) —
  /// the standard convention for language pickers, so someone who can't
  /// read the current language can still recognize their own.
  String get nativeLabel => switch (this) {
        AppLocale.en => 'English',
        AppLocale.ta => 'தமிழ்',
        AppLocale.hi => 'हिन्दी',
      };

  static AppLocale? fromLanguageCode(String? code) {
    if (code == null) return null;
    for (final locale in AppLocale.values) {
      if (locale.name == code) return locale;
    }
    return null;
  }
}
