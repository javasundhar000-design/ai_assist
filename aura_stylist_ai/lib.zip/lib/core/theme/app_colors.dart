import 'package:flutter/material.dart';

/// Centralized color palette for AURA STYLIST AI.
///
/// Keeping colors here (rather than scattered as magic hex codes across
/// widgets) means the whole app can be re-themed by editing this one file,
/// and it keeps light/dark mode visually consistent in tone.
class AppColors {
  AppColors._();

  // --- Brand ---
  static const Color primary = Color(0xFF7C5CFC); // violet - "AI" accent
  static const Color primaryDark = Color(0xFF5B3FD6);
  static const Color secondary = Color(0xFF00E5C9); // teal accent
  static const Color tertiary = Color(0xFFFF6FA5); // pink accent (fashion)

  // --- Neutral / surfaces (Light) ---
  static const Color lightBackground = Color(0xFFF7F6FB);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightOnSurface = Color(0xFF1C1B23);

  // --- Neutral / surfaces (Dark) ---
  static const Color darkBackground = Color(0xFF0E0B18);
  static const Color darkSurface = Color(0xFF17131F);
  static const Color darkOnSurface = Color(0xFFF2F0F7);

  // --- Semantic ---
  static const Color success = Color(0xFF2ED47A);
  static const Color warning = Color(0xFFFFB020);
  static const Color error = Color(0xFFFF5470);
  static const Color info = Color(0xFF3DA9FC);

  // --- Glassmorphism helpers ---
  static Color glassFillLight = Colors.white.withOpacity(0.55);
  static Color glassFillDark = Colors.white.withOpacity(0.08);
  static Color glassBorderLight = Colors.white.withOpacity(0.6);
  static Color glassBorderDark = Colors.white.withOpacity(0.14);

  /// Gradient used behind the splash / hero AI moments.
  static const LinearGradient auraGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primary, tertiary],
  );
}
