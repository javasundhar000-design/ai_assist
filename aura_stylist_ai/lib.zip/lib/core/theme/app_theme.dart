import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';
import 'app_tokens.dart';

/// Builds the app's Material 3 [ThemeData] for light and dark mode.
///
/// Typography uses Google Fonts' Poppins (headlines) + Inter (body) pairing,
/// which reads as premium/modern without shipping custom font files yet.
/// If/when brand fonts are supplied, swap the `GoogleFonts.*` calls for
/// `fontFamily` referencing assets registered in pubspec.yaml.
class AppTheme {
  AppTheme._();

  static ThemeData get light => _base(Brightness.light);
  static ThemeData get dark => _base(Brightness.dark);

  static ThemeData _base(Brightness brightness) {
    final isDark = brightness == Brightness.dark;

    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: brightness,
      secondary: AppColors.secondary,
      tertiary: AppColors.tertiary,
      error: AppColors.error,
      surface: isDark ? AppColors.darkSurface : AppColors.lightSurface,
    );

    final textTheme = _textTheme(isDark);

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: colorScheme,
      scaffoldBackgroundColor:
          isDark ? AppColors.darkBackground : AppColors.lightBackground,
      textTheme: textTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: textTheme.titleLarge,
        iconTheme: IconThemeData(
          color: isDark ? AppColors.darkOnSurface : AppColors.lightOnSurface,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.pill),
          ),
          textStyle: textTheme.labelLarge,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: isDark
            ? Colors.white.withOpacity(0.05)
            : Colors.black.withOpacity(0.03),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.md,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide.none,
        ),
      ),
      splashFactory: InkSparkle.splashFactory,
    );
  }

  static TextTheme _textTheme(bool isDark) {
    final base = isDark
        ? Typography.whiteMountainView
        : Typography.blackMountainView;

    final headline = GoogleFonts.poppinsTextTheme(base);
    final body = GoogleFonts.interTextTheme(base);

    return body.copyWith(
      displayLarge: headline.displayLarge?.copyWith(fontWeight: FontWeight.w700),
      displayMedium: headline.displayMedium?.copyWith(fontWeight: FontWeight.w700),
      headlineLarge: headline.headlineLarge?.copyWith(fontWeight: FontWeight.w600),
      headlineMedium: headline.headlineMedium?.copyWith(fontWeight: FontWeight.w600),
      headlineSmall: headline.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
      titleLarge: headline.titleLarge?.copyWith(fontWeight: FontWeight.w600),
      titleMedium: headline.titleMedium?.copyWith(fontWeight: FontWeight.w500),
      labelLarge: headline.labelLarge?.copyWith(fontWeight: FontWeight.w600),
    );
  }
}
