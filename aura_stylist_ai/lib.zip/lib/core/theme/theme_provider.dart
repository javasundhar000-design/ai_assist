import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/settings/data/settings_local_preferences.dart';
import '../../features/settings/presentation/providers/settings_providers.dart';

/// Holds the current [ThemeMode] for the app.
///
/// Backed by `SettingsLocalPreferences` (Module 11) so the choice
/// survives app restarts — the persistence this class's doc comment used
/// to describe as a future TODO. There's no per-account Firebase sync:
/// theme is a device preference, not profile data, so it stays local by
/// design rather than following the user between devices.
class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  ThemeModeNotifier(this._prefs) : super(_prefs.themeMode);

  final SettingsLocalPreferences _prefs;

  void setLight() => _set(ThemeMode.light);
  void setDark() => _set(ThemeMode.dark);
  void setSystem() => _set(ThemeMode.system);

  void toggle() => _set(state == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark);

  void _set(ThemeMode mode) {
    state = mode;
    _prefs.setThemeMode(mode);
  }
}

final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((ref) {
  return ThemeModeNotifier(ref.watch(settingsLocalPreferencesProvider));
});
