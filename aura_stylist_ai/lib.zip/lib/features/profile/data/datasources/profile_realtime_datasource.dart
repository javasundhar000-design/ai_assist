import 'package:firebase_database/firebase_database.dart';

/// Raw Realtime Database access for `users/{uid}/profile`. Kept "dumb" —
/// no domain types, just maps in/out — so `ProfileRepositoryImpl` owns all
/// the translation to/from `UserProfile`.
class ProfileRealtimeDataSource {
  ProfileRealtimeDataSource(this._db);

  final FirebaseDatabase _db;

  DatabaseReference _profileRef(String uid) => _db.ref('users/$uid/profile');

  Stream<Map<Object?, Object?>?> watchProfile(String uid) {
    return _profileRef(uid).onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return null;
      return value as Map<Object?, Object?>;
    });
  }

  Future<Map<Object?, Object?>?> getProfileOnce(String uid) async {
    final snapshot = await _profileRef(uid).get();
    if (!snapshot.exists || snapshot.value == null) return null;
    return snapshot.value as Map<Object?, Object?>;
  }

  Future<void> setProfile(String uid, Map<String, dynamic> data) {
    return _profileRef(uid).set(data);
  }

  Future<void> updateProfile(String uid, Map<String, dynamic> patch) {
    return _profileRef(uid).update(patch);
  }
}
