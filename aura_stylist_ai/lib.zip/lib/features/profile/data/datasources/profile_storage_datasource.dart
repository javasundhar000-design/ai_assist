import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';

/// Raw Storage access for profile photos. Stored at a stable path per user
/// (`profileImages/{uid}.jpg`) so re-uploading simply overwrites the old
/// photo rather than accumulating orphaned files.
class ProfileStorageDataSource {
  ProfileStorageDataSource(this._storage);

  final FirebaseStorage _storage;

  Future<String> uploadProfileImage(String uid, File file) async {
    final ref = _storage.ref('profileImages/$uid.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return ref.getDownloadURL();
  }
}
