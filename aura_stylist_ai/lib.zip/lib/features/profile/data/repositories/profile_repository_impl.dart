import 'dart:io';

import 'package:firebase_core/firebase_core.dart' show FirebaseException;

import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/user_profile.dart';
import '../../domain/repositories/profile_repository.dart';
import '../datasources/profile_realtime_datasource.dart';
import '../datasources/profile_storage_datasource.dart';

class ProfileRepositoryImpl implements ProfileRepository {
  ProfileRepositoryImpl(this._dbDataSource, this._storageDataSource);

  final ProfileRealtimeDataSource _dbDataSource;
  final ProfileStorageDataSource _storageDataSource;

  @override
  Stream<UserProfile?> watchProfile(String uid) {
    return _dbDataSource
        .watchProfile(uid)
        .map((map) => map == null ? null : UserProfile.fromMap(uid, map));
  }

  @override
  Future<Result<UserProfile>> ensureProfileExists({
    required String uid,
    String? email,
    String? displayName,
  }) async {
    try {
      final existing = await _dbDataSource.getProfileOnce(uid);
      if (existing != null) {
        return Success(UserProfile.fromMap(uid, existing));
      }

      final fallbackName = displayName?.trim().isNotEmpty == true
          ? displayName!.trim()
          : (email != null && email.contains('@') ? email.split('@').first : 'Stylist');

      final profile = UserProfile(
        uid: uid,
        name: fallbackName,
        email: email,
        preferredLanguage: 'en',
        createdAt: DateTime.now(),
      );

      await _dbDataSource.setProfile(uid, profile.toMap());
      return Success(profile);
    } on FirebaseException catch (e) {
      return Err(UnknownFailure(e.message ?? 'Database error (${e.code}).'));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<UserProfile>> updateProfile(UserProfile profile) async {
    try {
      await _dbDataSource.updateProfile(profile.uid, profile.toMap());
      return Success(profile);
    } on FirebaseException catch (e) {
      return Err(UnknownFailure(e.message ?? 'Database error (${e.code}).'));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<String>> uploadProfileImage({
    required String uid,
    required File file,
  }) async {
    try {
      final url = await _storageDataSource.uploadProfileImage(uid, file);
      await _dbDataSource.updateProfile(uid, {'photoUrl': url});
      return Success(url);
    } on FirebaseException catch (e) {
      return Err(UnknownFailure(e.message ?? 'Storage error (${e.code}).'));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }
}
