import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../data/datasources/profile_realtime_datasource.dart';
import '../../data/datasources/profile_storage_datasource.dart';
import '../../data/repositories/profile_repository_impl.dart';
import '../../domain/entities/user_profile.dart';
import '../../domain/repositories/profile_repository.dart';

final firebaseDatabaseProvider =
    Provider<FirebaseDatabase>((ref) => FirebaseDatabase.instance);

final firebaseStorageProvider =
    Provider<FirebaseStorage>((ref) => FirebaseStorage.instance);

final profileRealtimeDataSourceProvider =
    Provider<ProfileRealtimeDataSource>((ref) {
  return ProfileRealtimeDataSource(ref.watch(firebaseDatabaseProvider));
});

final profileStorageDataSourceProvider =
    Provider<ProfileStorageDataSource>((ref) {
  return ProfileStorageDataSource(ref.watch(firebaseStorageProvider));
});

/// Typed as the abstract `ProfileRepository` so tests can override this
/// with `FakeProfileRepository`.
final profileRepositoryProvider = Provider<ProfileRepository>((ref) {
  return ProfileRepositoryImpl(
    ref.watch(profileRealtimeDataSourceProvider),
    ref.watch(profileStorageDataSourceProvider),
  );
});

/// Live profile for whoever is currently signed in. Emits `null` while
/// signed out, or while a just-created account's default profile document
/// hasn't been written yet (see `ensureProfileExists`, triggered from
/// `DashboardPage`).
final currentUserProfileProvider = StreamProvider.autoDispose<UserProfile?>((ref) {
  final user = ref.watch(authStateChangesProvider).valueOrNull;
  if (user == null) return Stream.value(null);
  return ref.watch(profileRepositoryProvider).watchProfile(user.uid);
});
