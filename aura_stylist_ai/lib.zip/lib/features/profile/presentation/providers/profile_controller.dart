import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/user_profile.dart';
import '../../domain/repositories/profile_repository.dart';
import 'profile_providers.dart';

class ProfileFormState {
  const ProfileFormState({
    this.isSubmitting = false,
    this.isUploadingPhoto = false,
    this.errorMessage,
    this.isSuccess = false,
  });

  final bool isSubmitting;
  final bool isUploadingPhoto;
  final String? errorMessage;
  final bool isSuccess;

  static const initial = ProfileFormState();

  ProfileFormState copyWith({
    bool? isSubmitting,
    bool? isUploadingPhoto,
    String? errorMessage,
    bool? isSuccess,
  }) {
    return ProfileFormState(
      isSubmitting: isSubmitting ?? this.isSubmitting,
      isUploadingPhoto: isUploadingPhoto ?? this.isUploadingPhoto,
      errorMessage: errorMessage,
      isSuccess: isSuccess ?? this.isSuccess,
    );
  }
}

class ProfileController extends StateNotifier<ProfileFormState> {
  ProfileController(this._repository) : super(ProfileFormState.initial);

  final ProfileRepository _repository;

  Future<void> save(UserProfile updated) async {
    state = state.copyWith(isSubmitting: true, errorMessage: null, isSuccess: false);
    final result = await _repository.updateProfile(updated);
    result.when(
      success: (_) => state = state.copyWith(isSubmitting: false, isSuccess: true),
      failure: (f) =>
          state = state.copyWith(isSubmitting: false, errorMessage: f.message),
    );
  }

  Future<void> uploadPhoto({required String uid, required File file}) async {
    state = state.copyWith(isUploadingPhoto: true, errorMessage: null);
    final result =
        await _repository.uploadProfileImage(uid: uid, file: file);
    result.when(
      success: (_) => state = state.copyWith(isUploadingPhoto: false),
      failure: (f) =>
          state = state.copyWith(isUploadingPhoto: false, errorMessage: f.message),
    );
  }

  void clearError() => state = state.copyWith(errorMessage: null);
}

final profileControllerProvider =
    StateNotifierProvider.autoDispose<ProfileController, ProfileFormState>((ref) {
  return ProfileController(ref.watch(profileRepositoryProvider));
});
