import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../core/theme/app_tokens.dart';
import '../../../../core/utils/validators.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../domain/entities/user_profile.dart';
import '../providers/profile_controller.dart';
import '../providers/profile_providers.dart';
import '../widgets/profile_avatar.dart';

const _genderOptions = ['Female', 'Male', 'Non-binary', 'Prefer not to say'];
const _languageOptions = [
  ('en', 'English'),
  ('ta', 'Tamil'),
  ('hi', 'Hindi'),
];

class ProfilePage extends ConsumerStatefulWidget {
  const ProfilePage({super.key});

  @override
  ConsumerState<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends ConsumerState<ProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _ageController = TextEditingController();
  String? _gender;
  String _preferredLanguage = 'en';
  bool _initialized = false;

  void _hydrateFrom(UserProfile profile) {
    if (_initialized) return;
    _nameController.text = profile.name;
    _ageController.text = profile.age?.toString() ?? '';
    _gender = profile.gender;
    _preferredLanguage = profile.preferredLanguage;
    _initialized = true;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  Future<void> _pickAndUploadPhoto(String uid) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1024,
      imageQuality: 85,
    );
    if (picked == null) return;
    await ref
        .read(profileControllerProvider.notifier)
        .uploadPhoto(uid: uid, file: File(picked.path));
  }

  void _submit(UserProfile current) {
    if (!_formKey.currentState!.validate()) return;
    final updated = current.copyWith(
      name: _nameController.text.trim(),
      gender: _gender,
      age: int.tryParse(_ageController.text.trim()),
      preferredLanguage: _preferredLanguage,
    );
    ref.read(profileControllerProvider.notifier).save(updated);
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(currentUserProfileProvider);
    final formState = ref.watch(profileControllerProvider);
    final user = ref.watch(authStateChangesProvider).valueOrNull;

    ref.listen(profileControllerProvider, (previous, next) {
      if (next.errorMessage != null &&
          next.errorMessage != previous?.errorMessage) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text(next.errorMessage!)));
      }
      if (next.isSuccess && previous?.isSuccess != true) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('Profile updated')));
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Your Profile')),
      body: profileAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(child: Text('Could not load profile: $err')),
        data: (profile) {
          if (profile == null || user == null) {
            return const Center(child: Text('No profile found yet.'));
          }
          _hydrateFrom(profile);

          return SingleChildScrollView(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Stack(
                      children: [
                        ProfileAvatar(
                          photoUrl: profile.photoUrl,
                          label: profile.name,
                          radius: 48,
                        ),
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Material(
                            color: Theme.of(context).colorScheme.primary,
                            shape: const CircleBorder(),
                            child: InkWell(
                              customBorder: const CircleBorder(),
                              onTap: formState.isUploadingPhoto
                                  ? null
                                  : () => _pickAndUploadPhoto(user.uid),
                              child: Padding(
                                padding: const EdgeInsets.all(6),
                                child: formState.isUploadingPhoto
                                    ? const SizedBox(
                                        width: 14,
                                        height: 14,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: Colors.white,
                                        ),
                                      )
                                    : const Icon(Icons.camera_alt_rounded,
                                        size: 16, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.xl),
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: 'Full name'),
                    validator: Validators.displayName,
                  ),
                  const SizedBox(height: AppSpacing.md),
                  DropdownButtonFormField<String>(
                    value: _gender,
                    decoration: const InputDecoration(labelText: 'Gender'),
                    items: _genderOptions
                        .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                        .toList(),
                    onChanged: (v) => setState(() => _gender = v),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  TextFormField(
                    controller: _ageController,
                    decoration: const InputDecoration(labelText: 'Age'),
                    keyboardType: TextInputType.number,
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return null; // optional
                      final n = int.tryParse(v.trim());
                      if (n == null || n < 10 || n > 100) {
                        return 'Enter a valid age';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: AppSpacing.md),
                  DropdownButtonFormField<String>(
                    value: _preferredLanguage,
                    decoration:
                        const InputDecoration(labelText: 'Preferred language'),
                    items: _languageOptions
                        .map((l) => DropdownMenuItem(
                              value: l.$1,
                              child: Text(l.$2),
                            ))
                        .toList(),
                    onChanged: (v) =>
                        setState(() => _preferredLanguage = v ?? 'en'),
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  FilledButton(
                    onPressed:
                        formState.isSubmitting ? null : () => _submit(profile),
                    child: formState.isSubmitting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Save Changes'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
