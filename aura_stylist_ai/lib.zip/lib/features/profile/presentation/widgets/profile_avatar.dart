import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';

/// Circular avatar showing the user's profile photo, or a gradient
/// initials/icon fallback while there is no photo yet (the common case
/// right after signup, before Module 4's camera/photo capture exists).
class ProfileAvatar extends StatelessWidget {
  const ProfileAvatar({
    super.key,
    required this.photoUrl,
    required this.label,
    this.radius = 28,
    this.onTap,
  });

  final String? photoUrl;
  final String label;
  final double radius;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final hasPhoto = photoUrl != null && photoUrl!.isNotEmpty;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: radius * 2,
        height: radius * 2,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          gradient: AppColors.auraGradient,
        ),
        padding: const EdgeInsets.all(2),
        child: ClipOval(
          child: hasPhoto
              ? CachedNetworkImage(
                  imageUrl: photoUrl!,
                  fit: BoxFit.cover,
                  placeholder: (context, url) => _initialsFallback(context),
                  errorWidget: (context, url, error) => _initialsFallback(context),
                )
              : _initialsFallback(context),
        ),
      ),
    );
  }

  Widget _initialsFallback(BuildContext context) {
    final initial = label.trim().isNotEmpty ? label.trim()[0].toUpperCase() : '?';
    return Container(
      color: Theme.of(context).colorScheme.surface,
      alignment: Alignment.center,
      child: Text(
        initial,
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: AppColors.primary,
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}
