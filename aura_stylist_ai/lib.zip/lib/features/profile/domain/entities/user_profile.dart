import 'package:equatable/equatable.dart';

/// A user's profile, stored at `users/{uid}/profile` in Firebase Realtime
/// Database (matching the RTDB structure from the project spec).
///
/// `skinTone`, `bodyType`, and `faceShape` are nullable and start out empty —
/// they get populated once Module 5 (Face/Pose AI) runs its analyzers and
/// writes the results back through `ProfileRepository.updateProfile`.
class UserProfile extends Equatable {
  const UserProfile({
    required this.uid,
    required this.name,
    required this.createdAt,
    this.email,
    this.gender,
    this.age,
    this.preferredLanguage = 'en',
    this.skinTone,
    this.bodyType,
    this.faceShape,
    this.photoUrl,
  });

  final String uid;
  final String name;
  final String? email;
  final String? gender;
  final int? age;

  /// ISO 639-1 code: 'en', 'ta', or 'hi' (Module 11 — Localization).
  final String preferredLanguage;

  /// Filled in by Module 5's Skin Tone Analyzer (Fair/Light/Medium/Olive/Brown/Dark).
  final String? skinTone;

  /// Filled in by Module 5's Body Type Estimator (Slim/Athletic/Average/Broad).
  final String? bodyType;

  /// Filled in by Module 5's Face Shape Estimator (Oval/Round/Square/Heart/Diamond).
  final String? faceShape;

  final String? photoUrl;
  final DateTime createdAt;

  factory UserProfile.fromMap(String uid, Map<Object?, Object?> map) {
    final createdAtRaw = map['createdAt'];
    return UserProfile(
      uid: uid,
      name: map['name'] as String? ?? 'Stylist',
      email: map['email'] as String?,
      gender: map['gender'] as String?,
      age: (map['age'] as num?)?.toInt(),
      preferredLanguage: map['preferredLanguage'] as String? ?? 'en',
      skinTone: map['skinTone'] as String?,
      bodyType: map['bodyType'] as String?,
      faceShape: map['faceShape'] as String?,
      photoUrl: map['photoUrl'] as String?,
      createdAt: createdAtRaw is num
          ? DateTime.fromMillisecondsSinceEpoch(createdAtRaw.toInt())
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'gender': gender,
      'age': age,
      'preferredLanguage': preferredLanguage,
      'skinTone': skinTone,
      'bodyType': bodyType,
      'faceShape': faceShape,
      'photoUrl': photoUrl,
      'createdAt': createdAt.millisecondsSinceEpoch,
    };
  }

  UserProfile copyWith({
    String? name,
    String? email,
    String? gender,
    int? age,
    String? preferredLanguage,
    String? skinTone,
    String? bodyType,
    String? faceShape,
    String? photoUrl,
  }) {
    return UserProfile(
      uid: uid,
      createdAt: createdAt,
      name: name ?? this.name,
      email: email ?? this.email,
      gender: gender ?? this.gender,
      age: age ?? this.age,
      preferredLanguage: preferredLanguage ?? this.preferredLanguage,
      skinTone: skinTone ?? this.skinTone,
      bodyType: bodyType ?? this.bodyType,
      faceShape: faceShape ?? this.faceShape,
      photoUrl: photoUrl ?? this.photoUrl,
    );
  }

  @override
  List<Object?> get props => [
        uid,
        name,
        email,
        gender,
        age,
        preferredLanguage,
        skinTone,
        bodyType,
        faceShape,
        photoUrl,
        createdAt,
      ];
}
