import 'dart:io';

import '../../../../core/utils/result.dart';
import '../entities/user_profile.dart';

/// Contract for reading/writing the user's profile (Realtime Database) and
/// their profile photo (Storage). Presentation-layer code depends only on
/// this interface — see `FakeProfileRepository` in tests.
abstract class ProfileRepository {
  /// Live updates for `users/{uid}/profile`. Emits `null` if no profile
  /// document exists yet (e.g. the instant after a brand-new signup, before
  /// `ensureProfileExists` has finished writing the default one).
  Stream<UserProfile?> watchProfile(String uid);

  /// Reads the profile once; if none exists yet, creates a sensible default
  /// (name from [displayName]/[email], empty AI-derived fields, `en`
  /// language) and returns that. Safe to call every time the dashboard
  /// loads — it's a no-op if a profile already exists.
  Future<Result<UserProfile>> ensureProfileExists({
    required String uid,
    String? email,
    String? displayName,
  });

  Future<Result<UserProfile>> updateProfile(UserProfile profile);

  /// Uploads [file] to Storage as the user's profile photo, updates
  /// `photoUrl` on their profile, and returns the resulting download URL.
  Future<Result<String>> uploadProfileImage({
    required String uid,
    required File file,
  });
}
