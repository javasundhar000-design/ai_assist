import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../providers/splash_controller.dart';
import '../widgets/animated_aura_logo.dart';

/// The app's entry screen.
///
/// Responsibilities:
///  - Show branded, animated loading experience while [SplashController]
///    runs its bootstrap steps.
///  - Reflect real-time progress + step label.
///  - Show a retry affordance on failure.
///  - Once bootstrap reaches [SplashStatus.ready], navigate to /dashboard
///    if a session was restored, otherwise /login (Module 2).
class SplashPage extends ConsumerWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final splashState = ref.watch(splashControllerProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Splash owns its own navigation decision (rather than relying solely
    // on the router's redirect) so the very first hop after boot is
    // intentional: once bootstrap is done, go straight to /dashboard if a
    // session was restored, otherwise /login. The router's redirect still
    // guards direct/deep-link navigation to protected routes afterwards.
    ref.listen(splashControllerProvider, (previous, next) {
      if (next.status == SplashStatus.ready &&
          previous?.status != SplashStatus.ready) {
        final user = ref.read(authRepositoryProvider).currentUser;
        if (user != null) {
          context.go(AppRoutes.dashboard);
        } else {
          context.go(AppRoutes.login);
        }
      }
    });

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDark
                ? [AppColors.darkBackground, const Color(0xFF1B1330)]
                : [AppColors.lightBackground, const Color(0xFFEDE7FB)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            child: Column(
              children: [
                const Spacer(flex: 3),
                const AnimatedAuraLogo(size: 140),
                const SizedBox(height: AppSpacing.lg),
                Text(
                  'AURA STYLIST AI',
                  style: GoogleFonts.poppins(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  'Your AI-Powered Virtual Dressing Assistant',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurface
                            .withOpacity(0.65),
                      ),
                ),
                const Spacer(flex: 2),
                _StatusCard(state: splashState),
                const SizedBox(height: AppSpacing.xxl),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StatusCard extends ConsumerWidget {
  const _StatusCard({required this.state});

  final SplashState state;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GlassContainer(
      width: double.infinity,
      child: state.status == SplashStatus.error
          ? _ErrorContent(
              message: state.errorMessage ?? 'Something went wrong.',
              onRetry: () =>
                  ref.read(splashControllerProvider.notifier).retry(),
            )
          : _ProgressContent(state: state),
    );
  }
}

class _ProgressContent extends StatelessWidget {
  const _ProgressContent({required this.state});

  final SplashState state;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Icon(
              state.status == SplashStatus.ready
                  ? Icons.check_circle_rounded
                  : Icons.bolt_rounded,
              color: state.status == SplashStatus.ready
                  ? AppColors.success
                  : AppColors.primary,
              size: 20,
            ),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              child: Text(
                state.currentLabel,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.pill),
          child: LinearProgressIndicator(
            value: state.progress == 0 ? null : state.progress,
            minHeight: 6,
            backgroundColor: Theme.of(context)
                .colorScheme
                .onSurface
                .withOpacity(0.08),
            valueColor: const AlwaysStoppedAnimation(AppColors.primary),
          ),
        ),
      ],
    );
  }
}

class _ErrorContent extends StatelessWidget {
  const _ErrorContent({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            const Icon(Icons.error_outline_rounded, color: AppColors.error),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              child: Text(
                message,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: onRetry,
            child: const Text('Retry'),
          ),
        ),
      ],
    );
  }
}
