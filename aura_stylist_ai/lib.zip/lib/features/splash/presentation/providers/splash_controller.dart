import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';

/// A single bootstrap step shown on the splash screen (e.g. "Loading AI
/// Engine", "Checking session"). Each step's [task] is awaited in order.
class BootstrapStep {
  const BootstrapStep(this.label, this.task);

  final String label;
  final Future<void> Function() task;
}

enum SplashStatus { loading, ready, error }

class SplashState {
  const SplashState({
    required this.status,
    required this.currentLabel,
    required this.progress, // 0.0 - 1.0
    this.errorMessage,
  });

  final SplashStatus status;
  final String currentLabel;
  final double progress;
  final String? errorMessage;

  SplashState copyWith({
    SplashStatus? status,
    String? currentLabel,
    double? progress,
    String? errorMessage,
  }) {
    return SplashState(
      status: status ?? this.status,
      currentLabel: currentLabel ?? this.currentLabel,
      progress: progress ?? this.progress,
      errorMessage: errorMessage,
    );
  }

  static const initial = SplashState(
    status: SplashStatus.loading,
    currentLabel: 'Starting AURA...',
    progress: 0,
  );
}

/// Drives the splash screen's bootstrap sequence.
///
/// As of Module 2, the "Checking your session..." step is REAL: it applies
/// the "Remember Me" preference (signing the user out if they'd previously
/// unchecked it) and then waits for Firebase Auth's first `authStateChanges`
/// emission, so by the time this reaches `SplashStatus.ready`,
/// `authRepository.currentUser` reflects the actual restored session (or
/// lack thereof). `SplashPage` uses that to decide whether to land on
/// /login or /dashboard.
///
/// Remaining steps are still placeholders with artificial delays; they'll
/// become real as their modules land:
///   Module 5 (Face/Pose AI): warm up ML Kit detectors
///   Module 8 (Wardrobe):     hydrate local cache / Hive boxes
class SplashController extends StateNotifier<SplashState> {
  SplashController(this._ref) : super(SplashState.initial) {
    _run();
  }

  final Ref _ref;

  late final List<BootstrapStep> _steps = [
    BootstrapStep(
      'Initializing core services...',
      () => Future.delayed(const Duration(milliseconds: 500)),
    ),
    BootstrapStep(
      'Warming up AI engine...',
      () => Future.delayed(const Duration(milliseconds: 700)),
    ),
    BootstrapStep(
      'Checking your session...',
      () async {
        final authRepository = _ref.read(authRepositoryProvider);
        await authRepository.applyRememberMePreference();
        await authRepository.authStateChanges.first;
      },
    ),
    BootstrapStep(
      'Preparing your wardrobe...',
      () => Future.delayed(const Duration(milliseconds: 500)),
    ),
  ];

  Future<void> _run() async {
    try {
      for (var i = 0; i < _steps.length; i++) {
        final step = _steps[i];
        state = state.copyWith(
          currentLabel: step.label,
          progress: i / _steps.length,
        );
        await step.task();
      }
      state = state.copyWith(
        status: SplashStatus.ready,
        currentLabel: 'Ready!',
        progress: 1,
      );
    } catch (e) {
      state = state.copyWith(
        status: SplashStatus.error,
        errorMessage: e.toString(),
      );
    }
  }

  void retry() {
    state = SplashState.initial;
    _run();
  }
}

final splashControllerProvider =
    StateNotifierProvider<SplashController, SplashState>(
  (ref) => SplashController(ref),
);
