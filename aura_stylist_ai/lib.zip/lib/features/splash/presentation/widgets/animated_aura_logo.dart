import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';

/// Animated logo mark for AURA STYLIST AI: a soft pulsing gradient ring
/// with a rotating inner glow, meant to read as "AI is thinking / warming
/// up". No external asset required, so Module 1 has zero image dependencies
/// — swap in a Lottie file later by dropping it in assets/lottie and
/// replacing the body of this widget with a Lottie.asset(...) call.
class AnimatedAuraLogo extends StatefulWidget {
  const AnimatedAuraLogo({super.key, this.size = 140});

  final double size;

  @override
  State<AnimatedAuraLogo> createState() => _AnimatedAuraLogoState();
}

class _AnimatedAuraLogoState extends State<AnimatedAuraLogo>
    with TickerProviderStateMixin {
  late final AnimationController _pulseController;
  late final AnimationController _rotateController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _rotateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseController, _rotateController]),
      builder: (context, _) {
        final pulse = 0.9 + (_pulseController.value * 0.1);
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer soft glow, pulsing.
              Transform.scale(
                scale: pulse,
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        AppColors.primary.withOpacity(0.35),
                        AppColors.primary.withOpacity(0.0),
                      ],
                    ),
                  ),
                ),
              ),
              // Rotating gradient ring.
              Transform.rotate(
                angle: _rotateController.value * 6.28318,
                child: Container(
                  width: widget.size * 0.75,
                  height: widget.size * 0.75,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const SweepGradient(
                      colors: [
                        AppColors.primary,
                        AppColors.tertiary,
                        AppColors.secondary,
                        AppColors.primary,
                      ],
                    ),
                  ),
                  child: Center(
                    child: Container(
                      width: widget.size * 0.6,
                      height: widget.size * 0.6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Theme.of(context).scaffoldBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ),
              // Static center icon.
              Icon(
                Icons.auto_awesome,
                size: widget.size * 0.28,
                color: AppColors.primary,
              ),
            ],
          ),
        );
      },
    );
  }
}
