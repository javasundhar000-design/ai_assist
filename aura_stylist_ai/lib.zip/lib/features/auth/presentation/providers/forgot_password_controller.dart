import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/repositories/auth_repository.dart';
import 'auth_form_state.dart';
import 'auth_providers.dart';

class ForgotPasswordController extends StateNotifier<AuthFormState> {
  ForgotPasswordController(this._repository) : super(AuthFormState.initial);

  final AuthRepository _repository;

  /// On success, `isSuccess` means "reset email sent" — there is no
  /// sign-in to redirect on, so the page shows a confirmation instead.
  Future<void> submit(String email) async {
    state = state.copyWith(isSubmitting: true, errorMessage: null);
    final result = await _repository.sendPasswordResetEmail(email);
    result.when(
      success: (_) => state = state.copyWith(isSubmitting: false, isSuccess: true),
      failure: (f) =>
          state = state.copyWith(isSubmitting: false, errorMessage: f.message),
    );
  }

  void clearError() => state = state.copyWith(errorMessage: null);
}

final forgotPasswordControllerProvider = StateNotifierProvider.autoDispose<
    ForgotPasswordController, AuthFormState>((ref) {
  return ForgotPasswordController(ref.watch(authRepositoryProvider));
});
