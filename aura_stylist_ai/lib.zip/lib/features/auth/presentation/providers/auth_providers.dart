import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../core/local/auth_local_preferences.dart';
import '../../data/datasources/firebase_auth_datasource.dart';
import '../../data/repositories/auth_repository_impl.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/repositories/auth_repository.dart';

/// Provided a real value via `ProviderScope(overrides: [...])` in `main()`
/// once `SharedPreferences.getInstance()` has been awaited. Throwing here
/// (rather than silently returning a fresh instance) makes a missing
/// override fail loudly during development instead of behaving oddly.
final sharedPreferencesProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError(
    'sharedPreferencesProvider must be overridden in main() after '
    'awaiting SharedPreferences.getInstance()',
  );
});

final firebaseAuthProvider = Provider<FirebaseAuth>((ref) => FirebaseAuth.instance);

final googleSignInProvider = Provider<GoogleSignIn>((ref) {
  return GoogleSignIn(scopes: const ['email', 'profile']);
});

final authLocalPreferencesProvider = Provider<AuthLocalPreferences>((ref) {
  return AuthLocalPreferences(ref.watch(sharedPreferencesProvider));
});

final firebaseAuthDataSourceProvider = Provider<FirebaseAuthDataSource>((ref) {
  return FirebaseAuthDataSource(
    ref.watch(firebaseAuthProvider),
    ref.watch(googleSignInProvider),
  );
});

/// The single source of truth for auth operations, typed as the abstract
/// `AuthRepository` so tests can override this provider with a fake.
final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepositoryImpl(
    ref.watch(firebaseAuthDataSourceProvider),
    ref.watch(authLocalPreferencesProvider),
  );
});

/// App-wide reactive auth state. The router's `redirect` logic and the
/// splash screen both watch/read this to decide where to send the user.
final authStateChangesProvider = StreamProvider<AppUser?>((ref) {
  return ref.watch(authRepositoryProvider).authStateChanges;
});
