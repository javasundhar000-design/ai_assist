/// UI state for a single auth form (login, register, or forgot-password).
///
/// `isSuccess` is intentionally generic — for login/register it means
/// "signed in" (the router redirect takes over from there via
/// `authStateChangesProvider`); for forgot-password it means "reset email
/// sent".
class AuthFormState {
  const AuthFormState({
    this.isSubmitting = false,
    this.errorMessage,
    this.isSuccess = false,
  });

  final bool isSubmitting;
  final String? errorMessage;
  final bool isSuccess;

  static const initial = AuthFormState();

  AuthFormState copyWith({
    bool? isSubmitting,
    String? errorMessage,
    bool? isSuccess,
  }) {
    return AuthFormState(
      isSubmitting: isSubmitting ?? this.isSubmitting,
      // Passing an explicit null clears the error; omitting the param keeps it.
      errorMessage: errorMessage,
      isSuccess: isSuccess ?? this.isSuccess,
    );
  }
}
