import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/repositories/auth_repository.dart';
import 'auth_form_state.dart';
import 'auth_providers.dart';

class LoginController extends StateNotifier<AuthFormState> {
  LoginController(this._repository) : super(AuthFormState.initial);

  final AuthRepository _repository;

  Future<void> submit({
    required String email,
    required String password,
    required bool rememberMe,
  }) async {
    state = state.copyWith(isSubmitting: true, errorMessage: null);
    await _repository.setRememberMe(rememberMe);

    final result = await _repository.signInWithEmail(
      email: email,
      password: password,
    );

    result.when(
      success: (_) => state = state.copyWith(isSubmitting: false, isSuccess: true),
      failure: (f) =>
          state = state.copyWith(isSubmitting: false, errorMessage: f.message),
    );
  }

  Future<void> signInWithGoogle() async {
    state = state.copyWith(isSubmitting: true, errorMessage: null);
    final result = await _repository.signInWithGoogle();
    result.when(
      success: (_) => state = state.copyWith(isSubmitting: false, isSuccess: true),
      failure: (f) =>
          state = state.copyWith(isSubmitting: false, errorMessage: f.message),
    );
  }

  Future<void> continueAsGuest() async {
    state = state.copyWith(isSubmitting: true, errorMessage: null);
    final result = await _repository.signInAsGuest();
    result.when(
      success: (_) => state = state.copyWith(isSubmitting: false, isSuccess: true),
      failure: (f) =>
          state = state.copyWith(isSubmitting: false, errorMessage: f.message),
    );
  }

  void clearError() => state = state.copyWith(errorMessage: null);
}

final loginControllerProvider =
    StateNotifierProvider.autoDispose<LoginController, AuthFormState>((ref) {
  return LoginController(ref.watch(authRepositoryProvider));
});
