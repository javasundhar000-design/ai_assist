import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/repositories/auth_repository.dart';
import 'auth_form_state.dart';
import 'auth_providers.dart';

class RegisterController extends StateNotifier<AuthFormState> {
  RegisterController(this._repository) : super(AuthFormState.initial);

  final AuthRepository _repository;

  Future<void> submit({
    required String displayName,
    required String email,
    required String password,
  }) async {
    state = state.copyWith(isSubmitting: true, errorMessage: null);

    final result = await _repository.registerWithEmail(
      email: email,
      password: password,
      displayName: displayName,
    );

    result.when(
      success: (_) => state = state.copyWith(isSubmitting: false, isSuccess: true),
      failure: (f) =>
          state = state.copyWith(isSubmitting: false, errorMessage: f.message),
    );
  }

  void clearError() => state = state.copyWith(errorMessage: null);
}

final registerControllerProvider =
    StateNotifierProvider.autoDispose<RegisterController, AuthFormState>((ref) {
  return RegisterController(ref.watch(authRepositoryProvider));
});
