import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;

/// App-level user model.
///
/// The rest of the app (dashboard, wardrobe, recommendation engine, ...)
/// should depend on this, never directly on `firebase_auth`'s `User` — that
/// keeps auth swappable in theory and keeps widgets/tests decoupled from
/// the Firebase SDK.
class AppUser extends Equatable {
  const AppUser({
    required this.uid,
    required this.isGuest,
    required this.emailVerified,
    this.email,
    this.displayName,
    this.photoUrl,
  });

  final String uid;
  final String? email;
  final String? displayName;
  final String? photoUrl;

  /// True if this is an anonymous/guest Firebase session.
  final bool isGuest;
  final bool emailVerified;

  factory AppUser.fromFirebaseUser(fb.User user) {
    return AppUser(
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoUrl: user.photoURL,
      isGuest: user.isAnonymous,
      emailVerified: user.emailVerified,
    );
  }

  /// Best-effort display label: name -> email -> "Guest".
  String get label {
    if (displayName != null && displayName!.trim().isNotEmpty) {
      return displayName!;
    }
    if (email != null && email!.isNotEmpty) return email!;
    return 'Guest';
  }

  @override
  List<Object?> get props =>
      [uid, email, displayName, photoUrl, isGuest, emailVerified];
}
