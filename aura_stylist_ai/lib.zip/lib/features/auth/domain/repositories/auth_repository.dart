import '../../../../core/utils/result.dart';
import '../entities/app_user.dart';

/// Contract for all authentication operations.
///
/// Presentation-layer code (controllers/pages) depends only on this
/// interface, never on `AuthRepositoryImpl` or Firebase types directly —
/// which is what makes the controllers unit-testable with a fake
/// repository (see `test/features/auth`).
abstract class AuthRepository {
  /// Emits the current user (or `null` when signed out) immediately on
  /// subscription and on every subsequent auth change.
  Stream<AppUser?> get authStateChanges;

  /// Synchronous snapshot of the current user, if any.
  AppUser? get currentUser;

  Future<Result<AppUser>> signInWithEmail({
    required String email,
    required String password,
  });

  Future<Result<AppUser>> registerWithEmail({
    required String email,
    required String password,
    required String displayName,
  });

  Future<Result<AppUser>> signInWithGoogle();

  Future<Result<AppUser>> signInAsGuest();

  Future<Result<void>> sendPasswordResetEmail(String email);

  Future<Result<void>> signOut();

  // --- Remember Me ---

  bool get rememberMe;

  Future<void> setRememberMe(bool value);

  /// Called once during app bootstrap (splash). If the user previously
  /// unchecked "Remember Me", this signs them out and resets the
  /// preference back to `true` so the next successful login "remembers"
  /// again by default.
  Future<void> applyRememberMePreference();
}
