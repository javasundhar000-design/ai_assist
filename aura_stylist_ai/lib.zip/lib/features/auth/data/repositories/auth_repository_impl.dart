import 'package:firebase_auth/firebase_auth.dart';

import '../../../../core/errors/failure.dart';
import '../../../../core/local/auth_local_preferences.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/firebase_auth_datasource.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl(this._dataSource, this._localPreferences);

  final FirebaseAuthDataSource _dataSource;
  final AuthLocalPreferences _localPreferences;

  @override
  Stream<AppUser?> get authStateChanges => _dataSource.authStateChanges
      .map((user) => user == null ? null : AppUser.fromFirebaseUser(user));

  @override
  AppUser? get currentUser {
    final user = _dataSource.currentUser;
    return user == null ? null : AppUser.fromFirebaseUser(user);
  }

  @override
  Future<Result<AppUser>> signInWithEmail({
    required String email,
    required String password,
  }) async {
    try {
      final credential =
          await _dataSource.signInWithEmail(email.trim(), password);
      return _requireUser(credential);
    } on FirebaseAuthException catch (e) {
      return Err(AuthFailure(_mapFirebaseError(e), code: e.code));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<AppUser>> registerWithEmail({
    required String email,
    required String password,
    required String displayName,
  }) async {
    try {
      final credential =
          await _dataSource.registerWithEmail(email.trim(), password);
      if (displayName.trim().isNotEmpty) {
        await _dataSource.updateDisplayName(displayName.trim());
      }
      // Re-read currentUser since updateDisplayName + reload() mutated it
      // after the credential above was captured.
      final user = _dataSource.currentUser;
      if (user == null) {
        return const Err(AuthFailure('Registration failed. Please try again.'));
      }
      return Success(AppUser.fromFirebaseUser(user));
    } on FirebaseAuthException catch (e) {
      return Err(AuthFailure(_mapFirebaseError(e), code: e.code));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<AppUser>> signInWithGoogle() async {
    try {
      final credential = await _dataSource.signInWithGoogle();
      return _requireUser(credential);
    } on FirebaseAuthException catch (e) {
      return Err(AuthFailure(_mapFirebaseError(e), code: e.code));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<AppUser>> signInAsGuest() async {
    try {
      final credential = await _dataSource.signInAnonymously();
      return _requireUser(credential);
    } on FirebaseAuthException catch (e) {
      return Err(AuthFailure(_mapFirebaseError(e), code: e.code));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> sendPasswordResetEmail(String email) async {
    try {
      await _dataSource.sendPasswordResetEmail(email.trim());
      return const Success(null);
    } on FirebaseAuthException catch (e) {
      return Err(AuthFailure(_mapFirebaseError(e), code: e.code));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> signOut() async {
    try {
      await _dataSource.signOut();
      return const Success(null);
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  bool get rememberMe => _localPreferences.rememberMe;

  @override
  Future<void> setRememberMe(bool value) => _localPreferences.setRememberMe(value);

  @override
  Future<void> applyRememberMePreference() async {
    if (!_localPreferences.rememberMe && _dataSource.currentUser != null) {
      await _dataSource.signOut();
      // Reset so the next successful login "remembers" again by default.
      await _localPreferences.setRememberMe(true);
    }
  }

  Result<AppUser> _requireUser(UserCredential credential) {
    final user = credential.user;
    if (user == null) {
      return const Err(AuthFailure('Sign-in failed. Please try again.'));
    }
    return Success(AppUser.fromFirebaseUser(user));
  }

  /// Translates Firebase's error codes into messages a non-technical user
  /// can act on. Falls back to the SDK message for anything not explicitly
  /// handled (which still beats hiding the error entirely).
  String _mapFirebaseError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'No account found with that email.';
      case 'wrong-password':
      case 'invalid-credential':
        return 'Incorrect email or password.';
      case 'email-already-in-use':
        return 'An account already exists with that email.';
      case 'weak-password':
        return 'Please choose a stronger password (at least 6 characters).';
      case 'invalid-email':
        return 'That email address looks invalid.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'too-many-requests':
        return 'Too many attempts. Please wait a moment and try again.';
      case 'network-request-failed':
        return 'Network error. Check your connection and try again.';
      case 'sign_in_cancelled':
        return 'Sign-in was cancelled.';
      case 'account-exists-with-different-credential':
        return 'An account already exists with a different sign-in method.';
      default:
        return e.message ?? 'Authentication error (${e.code}).';
    }
  }
}
