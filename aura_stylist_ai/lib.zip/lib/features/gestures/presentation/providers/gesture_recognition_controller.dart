import 'package:camera/camera.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../smart_camera/presentation/providers/camera_providers.dart';
import '../../../settings/presentation/providers/settings_providers.dart';
import '../../../vision/domain/entities/pose_analysis.dart';
import '../../../vision/presentation/providers/vision_pipeline_controller.dart';
import '../../domain/entities/gesture_action.dart';
import '../../domain/entities/gesture_event.dart';
import '../../domain/services/pose_gesture_classifier.dart';

class GestureRecognitionState {
  const GestureRecognitionState({this.lastEvent, this.lastAction});

  final GestureEvent? lastEvent;
  final GestureAction? lastAction;

  static const initial = GestureRecognitionState();
}

/// Turns live pose data into gesture events.
///
/// Deliberately does **not** subscribe to camera frames or run any
/// detection of its own — `VisionPipelineController` (Module 5) already
/// runs pose detection once per frame, and re-running it here would waste
/// CPU for no benefit. Instead, this reacts to `VisionPipelineController`'s
/// state via `ref.listen` (wired up in the provider below) and feeds each
/// new pose into `PoseGestureClassifier`.
class GestureRecognitionController extends StateNotifier<GestureRecognitionState> {
  GestureRecognitionController() : super(GestureRecognitionState.initial);

  final PoseGestureClassifier _classifier = PoseGestureClassifier();

  void setMirror(bool mirror) => _classifier.mirrorHorizontal = mirror;

  void onPoseUpdate(PoseAnalysis pose, DateTime timestamp) {
    final event = _classifier.classify(pose, timestamp);
    if (event == null || !mounted) return;
    state = GestureRecognitionState(lastEvent: event, lastAction: event.type.action);
  }

  void reset() {
    _classifier.reset();
    if (mounted) state = GestureRecognitionState.initial;
  }
}

final gestureRecognitionControllerProvider = StateNotifierProvider.autoDispose<
    GestureRecognitionController, GestureRecognitionState>((ref) {
  final controller = GestureRecognitionController();

  ref.listen<VisionAnalysisState>(visionPipelineControllerProvider, (previous, next) {
    // Real target for the "Gesture recognition" toggle in Settings
    // (Module 11): when disabled, poses still flow through
    // `VisionPipelineController` (the try-on overlay still needs body
    // landmarks), they just never reach the gesture classifier — so
    // turning this off genuinely stops gestures from triggering actions,
    // rather than only hiding a UI indicator.
    if (!ref.read(gestureSettingsProvider)) return;

    final pose = next.pose;
    final updatedAt = next.lastUpdated;
    if (pose == null || updatedAt == null) return;
    if (updatedAt == previous?.lastUpdated) return; // no new frame since last time

    final lensDirection =
        ref.read(cameraRepositoryProvider).controller?.description.lensDirection ??
            CameraLensDirection.front;
    controller.setMirror(lensDirection == CameraLensDirection.front);
    controller.onPoseUpdate(pose, updatedAt);
  });

  return controller;
});
