import 'gesture_type.dart';

/// A single recognized gesture instance.
class GestureEvent {
  const GestureEvent({
    required this.type,
    required this.confidence,
    required this.detectedAt,
  });

  final GestureType type;

  /// 0-1 heuristic confidence — not a trained-model probability, just a
  /// rough indicator of how clean the underlying signal was (e.g. how far
  /// past the swipe-distance threshold the motion was).
  final double confidence;

  final DateTime detectedAt;
}
