/// The ten gestures named in the spec.
enum GestureType {
  swipeLeft,
  swipeRight,
  raisedRightHand,
  raisedLeftHand,
  bothHandsUp,
  openPalm,
  closedFist,
  thumbsUp,
  thumbsDown,
  peaceSign,
}

extension GestureTypeMeta on GestureType {
  String get label => switch (this) {
        GestureType.swipeLeft => 'Swipe Left',
        GestureType.swipeRight => 'Swipe Right',
        GestureType.raisedRightHand => 'Raised Right Hand',
        GestureType.raisedLeftHand => 'Raised Left Hand',
        GestureType.bothHandsUp => 'Both Hands Up',
        GestureType.openPalm => 'Open Palm',
        GestureType.closedFist => 'Closed Fist',
        GestureType.thumbsUp => 'Thumbs Up',
        GestureType.thumbsDown => 'Thumbs Down',
        GestureType.peaceSign => 'Peace Sign',
      };

  /// Whether this gesture is actually detected in this build.
  ///
  /// The five `true` values are derived from Module 5's pose landmarks —
  /// arm/wrist *position and movement*, which ML Kit's pose detector
  /// already provides. The five `false` values are hand-*shape* gestures
  /// (finger configuration: open palm vs. closed fist, thumbs up/down,
  /// peace sign) — telling those apart needs per-finger hand landmarks,
  /// which pose detection doesn't give us. Google ML Kit has no
  /// hand-landmark detector; the spec's own suggestion (MediaPipe Hands)
  /// has no actively maintained, production-ready Flutter plugin as of
  /// this build. Rather than fake a classifier that can't actually see
  /// fingers, these stay explicitly unimplemented — see the module
  /// README for the full reasoning and what a real implementation would
  /// need (most realistically: a bundled on-device hand-landmark model
  /// run via `tflite_flutter`, cropped to the hand region using the wrist
  /// position Module 5 already tracks).
  bool get isImplemented => switch (this) {
        GestureType.swipeLeft ||
        GestureType.swipeRight ||
        GestureType.raisedRightHand ||
        GestureType.raisedLeftHand ||
        GestureType.bothHandsUp =>
          true,
        _ => false,
      };
}
