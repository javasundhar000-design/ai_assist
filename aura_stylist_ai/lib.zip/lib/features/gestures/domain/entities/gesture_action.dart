import 'gesture_type.dart';

/// The actions the spec assigns to gestures.
enum GestureAction {
  previousOutfit,
  nextOutfit,
  saveFavorite,
  capturePhoto,
  openMenu,
  closeMenu,
  startVoiceMode,
  stopVoiceMode,
  resetTryOn,
}

extension GestureActionMeta on GestureAction {
  String get label => switch (this) {
        GestureAction.previousOutfit => 'Previous Outfit',
        GestureAction.nextOutfit => 'Next Outfit',
        GestureAction.saveFavorite => 'Save Favorite',
        GestureAction.capturePhoto => 'Capture Photo',
        GestureAction.openMenu => 'Open Menu',
        GestureAction.closeMenu => 'Close Menu',
        GestureAction.startVoiceMode => 'Start Voice Mode',
        GestureAction.stopVoiceMode => 'Stop Voice Mode',
        GestureAction.resetTryOn => 'Reset Try-On',
      };

  /// Whether this action is wired to real app behavior in the current
  /// build, rather than just being detected-and-acknowledged. Mirrors
  /// `GestureType.isImplemented`'s honesty pattern — but note this is a
  /// *separate* flag from that one: `openMenu`/`closeMenu` are real now
  /// (Module 8's clothing picker sheet), even though the gestures that
  /// would trigger them (`openPalm`/`closedFist`) still can't be detected
  /// (see `GestureType.isImplemented`). That's a gesture-*detection*
  /// limitation, not an action-*implementation* one — if hand-shape
  /// detection is ever added, these two gestures work with zero further
  /// wiring changes, since `SmartCameraPage` already calls the real
  /// handler for both.
  bool get isImplemented => switch (this) {
        GestureAction.startVoiceMode ||
        GestureAction.stopVoiceMode ||
        GestureAction.resetTryOn ||
        GestureAction.openMenu ||
        GestureAction.closeMenu ||
        GestureAction.previousOutfit ||
        GestureAction.nextOutfit ||
        GestureAction.saveFavorite =>
          true,
        _ => false,
      };

  /// Which module implements this action's real behavior. Null once
  /// `isImplemented` is true — there's nothing left to point to.
  ///
  /// `previousOutfit`/`nextOutfit`/`saveFavorite` became real in Module 10,
  /// once `WardrobeController` existed to cycle through and save saved
  /// outfits against — see `SmartCameraPage`'s gesture dispatch.
  String? get owningModule => switch (this) {
        GestureAction.capturePhoto => 'Photo Capture (planned, not yet built)',
        GestureAction.openMenu ||
        GestureAction.closeMenu ||
        GestureAction.startVoiceMode ||
        GestureAction.stopVoiceMode ||
        GestureAction.resetTryOn ||
        GestureAction.previousOutfit ||
        GestureAction.nextOutfit ||
        GestureAction.saveFavorite =>
          null,
      };
}

/// Maps each gesture to the action the spec assigns it.
///
/// `GestureType.thumbsDown` is intentionally absent — the spec lists it
/// under recognized gestures but never assigns it an action in the
/// "Gesture Actions" section, so there's genuinely nothing to map it to.
const Map<GestureType, GestureAction> gestureActionMap = {
  GestureType.swipeLeft: GestureAction.previousOutfit,
  GestureType.swipeRight: GestureAction.nextOutfit,
  GestureType.thumbsUp: GestureAction.saveFavorite,
  GestureType.peaceSign: GestureAction.capturePhoto,
  GestureType.openPalm: GestureAction.openMenu,
  GestureType.closedFist: GestureAction.closeMenu,
  GestureType.raisedRightHand: GestureAction.startVoiceMode,
  GestureType.raisedLeftHand: GestureAction.stopVoiceMode,
  GestureType.bothHandsUp: GestureAction.resetTryOn,
};

extension GestureTypeAction on GestureType {
  GestureAction? get action => gestureActionMap[this];
}
