import '../../../vision/domain/entities/pose_analysis.dart';
import '../entities/gesture_event.dart';
import '../entities/gesture_type.dart';

class _PositionSample {
  const _PositionSample(this.x, this.y, this.time);
  final double x;
  final double y;
  final DateTime time;
}

/// Classifies the five pose-derivable gestures (see `GestureType.
/// isImplemented`) from a stream of `PoseAnalysis` frames.
///
/// Stateful by necessity — swipes and "held" raised-hand poses are
/// inherently temporal, not something a single frame can tell you. Feed
/// frames in order via `classify()`; call `reset()` when leaving the Smart
/// Mirror screen so stale history doesn't leak into the next session.
///
/// Pure Dart, no camera/ML Kit/plugin dependencies beyond the already-
/// mapped `PoseAnalysis` domain entity — fully unit-testable.
class PoseGestureClassifier {
  PoseGestureClassifier({
    this.historyWindow = const Duration(milliseconds: 450),
    this.swipeDisplacementFraction = 0.22,
    this.swipeMaxVerticalFraction = 0.12,
    this.raisedHoldDuration = const Duration(milliseconds: 450),
    this.gestureCooldown = const Duration(milliseconds: 1000),
  });

  /// How far back (in time) wrist positions are kept for swipe detection.
  final Duration historyWindow;

  /// Minimum horizontal wrist displacement within [historyWindow], as a
  /// fraction of image width, to count as a deliberate swipe.
  final double swipeDisplacementFraction;

  /// Maximum vertical drift allowed during that displacement, as a
  /// fraction of image height — keeps a raised/lowering arm from being
  /// misread as a horizontal swipe.
  final double swipeMaxVerticalFraction;

  /// How long a wrist must stay above the nose to count as "raised"
  /// (rather than a hand briefly passing through, e.g. while gesturing).
  final Duration raisedHoldDuration;

  /// Minimum time between two emissions of the *same* gesture type, so a
  /// held pose doesn't fire the same action every single frame.
  final Duration gestureCooldown;

  static const _minLikelihood = 0.5;

  /// Set by the caller based on the active camera's lens direction.
  /// ML Kit's `leftWrist`/`rightWrist` labels already refer to the
  /// subject's own anatomical left/right regardless of mirroring (pose
  /// models are trained to output subject-relative handedness from visual
  /// cues, not raw image position) — so raised-hand detection needs no
  /// mirroring correction. Swipe *direction*, however, is about on-screen
  /// movement, and the front camera's preview is mirrored for a natural
  /// "real mirror" feel (see `MirroredCameraPreview`), so a swipe that
  /// moves right in raw sensor space appears to move left on screen. This
  /// flag corrects for that.
  bool mirrorHorizontal = true;

  final List<_PositionSample> _rightWristHistory = [];
  final List<_PositionSample> _leftWristHistory = [];

  DateTime? _rightRaisedSince;
  DateTime? _leftRaisedSince;

  GestureType? _lastEmittedType;
  DateTime? _lastEmittedAt;

  GestureEvent? classify(PoseAnalysis pose, DateTime now) {
    final imageWidth = pose.imageSize.width;
    final imageHeight = pose.imageSize.height;
    if (imageWidth <= 0 || imageHeight <= 0) return null;

    final rightWrist = pose[PoseLandmarkKind.rightWrist];
    final leftWrist = pose[PoseLandmarkKind.leftWrist];
    final nose = pose[PoseLandmarkKind.nose];

    _recordAndPrune(_rightWristHistory, rightWrist, now);
    _recordAndPrune(_leftWristHistory, leftWrist, now);

    // Swipe detection takes priority — deliberate horizontal motion is a
    // stronger, more intentional signal than a raised/held pose, and a
    // fast swipe naturally passes the wrist above the nose briefly too.
    final swipe = _detectSwipe(_rightWristHistory, imageWidth, imageHeight) ??
        _detectSwipe(_leftWristHistory, imageWidth, imageHeight);
    if (swipe != null) {
      return _emit(swipe, now, confidence: 0.75);
    }

    final rightRaised = _isRaised(rightWrist, nose);
    final leftRaised = _isRaised(leftWrist, nose);

    _rightRaisedSince = rightRaised ? (_rightRaisedSince ?? now) : null;
    _leftRaisedSince = leftRaised ? (_leftRaisedSince ?? now) : null;

    final rightHeld = _rightRaisedSince != null &&
        now.difference(_rightRaisedSince!) >= raisedHoldDuration;
    final leftHeld = _leftRaisedSince != null &&
        now.difference(_leftRaisedSince!) >= raisedHoldDuration;

    if (rightHeld && leftHeld) {
      return _emit(GestureType.bothHandsUp, now, confidence: 0.8);
    }
    if (rightHeld) {
      return _emit(GestureType.raisedRightHand, now, confidence: 0.7);
    }
    if (leftHeld) {
      return _emit(GestureType.raisedLeftHand, now, confidence: 0.7);
    }

    return null;
  }

  void reset() {
    _rightWristHistory.clear();
    _leftWristHistory.clear();
    _rightRaisedSince = null;
    _leftRaisedSince = null;
    _lastEmittedType = null;
    _lastEmittedAt = null;
  }

  void _recordAndPrune(
    List<_PositionSample> history,
    PoseKeypoint? point,
    DateTime now,
  ) {
    if (point != null && point.likelihood >= _minLikelihood) {
      history.add(_PositionSample(point.x, point.y, now));
    }
    history.removeWhere((s) => now.difference(s.time) > historyWindow);
  }

  bool _isRaised(PoseKeypoint? wrist, PoseKeypoint? nose) {
    if (wrist == null || nose == null) return false;
    if (wrist.likelihood < _minLikelihood || nose.likelihood < _minLikelihood) {
      return false;
    }
    return wrist.y < nose.y; // image y grows downward — "above the nose"
  }

  GestureType? _detectSwipe(
    List<_PositionSample> history,
    double imageWidth,
    double imageHeight,
  ) {
    if (history.length < 3) return null;

    final first = history.first;
    final last = history.last;
    final dx = last.x - first.x;
    final dy = (last.y - first.y).abs();

    if (dy > imageHeight * swipeMaxVerticalFraction) return null;
    if (dx.abs() < imageWidth * swipeDisplacementFraction) return null;

    final onScreenDx = mirrorHorizontal ? -dx : dx;
    return onScreenDx > 0 ? GestureType.swipeRight : GestureType.swipeLeft;
  }

  GestureEvent? _emit(GestureType type, DateTime now, {required double confidence}) {
    if (_lastEmittedType == type &&
        _lastEmittedAt != null &&
        now.difference(_lastEmittedAt!) < gestureCooldown) {
      return null; // debounced — same gesture too soon after the last one
    }

    _lastEmittedType = type;
    _lastEmittedAt = now;
    // Clear swipe history after emitting so one sweep doesn't retrigger
    // itself across the next couple of frames.
    _rightWristHistory.clear();
    _leftWristHistory.clear();

    return GestureEvent(type: type, confidence: confidence, detectedAt: now);
  }
}
