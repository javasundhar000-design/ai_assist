import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/l10n/app_locale.dart';
import '../../../../core/l10n/app_localizations.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../core/theme/theme_provider.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../profile/presentation/providers/profile_controller.dart';
import '../../../profile/presentation/providers/profile_providers.dart';
import '../../data/settings_local_preferences.dart';
import '../providers/settings_providers.dart';

/// The real Module 11 screen: appearance, language, Smart Mirror
/// behavior toggles, account, and about — the settings the dashboard's
/// "Settings" card used to point to a "coming soon" sheet for.
class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final themeMode = ref.watch(themeModeProvider);
    final locale = ref.watch(localeProvider);
    final gestureEnabled = ref.watch(gestureSettingsProvider);
    final voiceConfirmation = ref.watch(voiceSettingsProvider);
    final cameraLens = ref.watch(cameraSettingsProvider);
    final user = ref.watch(authStateChangesProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(AppL10nKeys.settingsTitle))),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
        children: [
          _SectionHeader(title: l10n.t(AppL10nKeys.settingsAppearance)),
          RadioListTile<ThemeMode>(
            title: Text(l10n.t(AppL10nKeys.settingsThemeLight)),
            value: ThemeMode.light,
            groupValue: themeMode,
            onChanged: (_) => ref.read(themeModeProvider.notifier).setLight(),
          ),
          RadioListTile<ThemeMode>(
            title: Text(l10n.t(AppL10nKeys.settingsThemeDark)),
            value: ThemeMode.dark,
            groupValue: themeMode,
            onChanged: (_) => ref.read(themeModeProvider.notifier).setDark(),
          ),
          RadioListTile<ThemeMode>(
            title: Text(l10n.t(AppL10nKeys.settingsThemeSystem)),
            value: ThemeMode.system,
            groupValue: themeMode,
            onChanged: (_) => ref.read(themeModeProvider.notifier).setSystem(),
          ),
          const Divider(),
          _SectionHeader(title: l10n.t(AppL10nKeys.settingsLanguage)),
          for (final option in AppLocale.values)
            RadioListTile<AppLocale>(
              title: Text(option.nativeLabel),
              value: option,
              groupValue: locale,
              onChanged: (selected) async {
                if (selected == null) return;
                await ref.read(localeProvider.notifier).setLocale(selected);

                // Best-effort mirror onto the signed-in profile's
                // `preferredLanguage` field (Module 3) — same field
                // `ProfilePage`'s own language picker writes to, so the
                // two stay in sync rather than disagreeing about which
                // language "the account" prefers. Silently skipped for
                // guests/signed-out, same as everything else here that
                // needs an account.
                final profile = ref.read(currentUserProfileProvider).valueOrNull;
                if (profile != null) {
                  await ref
                      .read(profileControllerProvider.notifier)
                      .save(profile.copyWith(preferredLanguage: selected.name));
                }
              },
            ),
          const Divider(),
          _SectionHeader(title: l10n.t(AppL10nKeys.settingsSmartMirror)),
          SwitchListTile(
            title: Text(l10n.t(AppL10nKeys.settingsGestureRecognition)),
            subtitle: Text(l10n.t(AppL10nKeys.settingsGestureRecognitionSubtitle)),
            value: gestureEnabled,
            onChanged: (value) =>
                ref.read(gestureSettingsProvider.notifier).setEnabled(value),
          ),
          SwitchListTile(
            title: Text(l10n.t(AppL10nKeys.settingsVoiceConfirmation)),
            subtitle: Text(l10n.t(AppL10nKeys.settingsVoiceConfirmationSubtitle)),
            value: voiceConfirmation,
            onChanged: (value) =>
                ref.read(voiceSettingsProvider.notifier).setEnabled(value),
          ),
          ListTile(
            title: Text(l10n.t(AppL10nKeys.settingsDefaultCamera)),
            trailing: SegmentedButton<PreferredCameraLens>(
              segments: [
                ButtonSegment(
                  value: PreferredCameraLens.front,
                  label: Text(l10n.t(AppL10nKeys.settingsCameraFront)),
                ),
                ButtonSegment(
                  value: PreferredCameraLens.back,
                  label: Text(l10n.t(AppL10nKeys.settingsCameraBack)),
                ),
              ],
              selected: {cameraLens},
              onSelectionChanged: (selection) => ref
                  .read(cameraSettingsProvider.notifier)
                  .setLens(selection.first),
            ),
          ),
          const Divider(),
          if (user != null) ...[
            _SectionHeader(title: l10n.t(AppL10nKeys.settingsAccount)),
            ListTile(
              leading: const Icon(Icons.logout_rounded),
              title: Text(l10n.t(AppL10nKeys.settingsSignOut)),
              onTap: () async {
                await ref.read(authRepositoryProvider).signOut();
                if (context.mounted) context.go(AppRoutes.login);
              },
            ),
            const Divider(),
          ],
          _SectionHeader(title: l10n.t(AppL10nKeys.settingsAbout)),
          const _AboutTile(),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.md,
        AppSpacing.md,
        AppSpacing.md,
        AppSpacing.xs,
      ),
      child: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .labelLarge
            ?.copyWith(color: Theme.of(context).colorScheme.primary),
      ),
    );
  }
}

/// Static version/module info. Deliberately not read from a package-info
/// plugin: adding a new pub.dev dependency for one about-screen line
/// isn't worth it — see the pubspec's Module 10/11 dependency notes for
/// why this build keeps new dependencies to the minimum something can't
/// be done without.
class _AboutTile extends StatelessWidget {
  const _AboutTile();

  @override
  Widget build(BuildContext context) {
    return const ListTile(
      leading: Icon(Icons.info_outline_rounded),
      title: Text('AURA STYLIST AI'),
      subtitle: Text('v0.12.0 · Modules 0–12 of 12'),
    );
  }
}
