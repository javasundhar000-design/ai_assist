import 'dart:ui' show PlatformDispatcher;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/l10n/app_locale.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../data/settings_local_preferences.dart';


final settingsLocalPreferencesProvider = Provider<SettingsLocalPreferences>((ref) {
  return SettingsLocalPreferences(ref.watch(sharedPreferencesProvider));
});

/// The app's current language. Defaults to the device locale if it's one
/// of the three supported (`en`/`ta`/`hi`), else English — set once at
/// startup, then whatever the user explicitly picks in `SettingsPage`
/// from then on.
class LocaleNotifier extends StateNotifier<AppLocale> {
  LocaleNotifier(this._prefs, AppLocale initial) : super(initial);

  final SettingsLocalPreferences _prefs;

  Future<void> setLocale(AppLocale locale) async {
    state = locale;
    await _prefs.setLocale(locale);
  }
}

final localeProvider = StateNotifierProvider<LocaleNotifier, AppLocale>((ref) {
  final prefs = ref.watch(settingsLocalPreferencesProvider);
  final saved = prefs.locale;
  final deviceCode = PlatformDispatcher.instance.locale.languageCode;
  final initial = saved ?? AppLocaleMeta.fromLanguageCode(deviceCode) ?? AppLocale.en;
  return LocaleNotifier(prefs, initial);
});

/// Gate for `GestureRecognitionController` — real target for the
/// spec's "enable/disable gesture recognition" setting. When `false`,
/// `SmartCameraPage` still runs the camera and pose detection, it just
/// stops forwarding poses into gesture classification, so turning this
/// off is a genuine "stop gestures from doing anything," not a fake
/// toggle.
class GestureSettingsNotifier extends StateNotifier<bool> {
  GestureSettingsNotifier(this._prefs) : super(_prefs.gestureRecognitionEnabled);

  final SettingsLocalPreferences _prefs;

  Future<void> setEnabled(bool value) async {
    state = value;
    await _prefs.setGestureRecognitionEnabled(value);
  }
}

final gestureSettingsProvider =
    StateNotifierProvider<GestureSettingsNotifier, bool>((ref) {
  return GestureSettingsNotifier(ref.watch(settingsLocalPreferencesProvider));
});

/// Gate for whether `VoiceAssistantController` speaks its responses back
/// via TTS, vs. only showing the transcript banner silently.
class VoiceSettingsNotifier extends StateNotifier<bool> {
  VoiceSettingsNotifier(this._prefs) : super(_prefs.voiceConfirmationEnabled);

  final SettingsLocalPreferences _prefs;

  Future<void> setEnabled(bool value) async {
    state = value;
    await _prefs.setVoiceConfirmationEnabled(value);
  }
}

final voiceSettingsProvider = StateNotifierProvider<VoiceSettingsNotifier, bool>((ref) {
  return VoiceSettingsNotifier(ref.watch(settingsLocalPreferencesProvider));
});

/// Which camera lens `SmartCameraPage` opens with by default.
class CameraSettingsNotifier extends StateNotifier<PreferredCameraLens> {
  CameraSettingsNotifier(this._prefs) : super(_prefs.preferredCameraLens);

  final SettingsLocalPreferences _prefs;

  Future<void> setLens(PreferredCameraLens lens) async {
    state = lens;
    await _prefs.setPreferredCameraLens(lens);
  }
}

final cameraSettingsProvider =
    StateNotifierProvider<CameraSettingsNotifier, PreferredCameraLens>((ref) {
  return CameraSettingsNotifier(ref.watch(settingsLocalPreferencesProvider));
});
