import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/l10n/app_locale.dart';

enum PreferredCameraLens { front, back }

/// Thin wrapper around `SharedPreferences` for every Module 11 setting —
/// theme, language, and the Smart Mirror toggles — following
/// `AuthLocalPreferences`'s pattern (Module 2) of one small class per
/// feature's local state rather than scattering raw preference keys
/// across providers.
class SettingsLocalPreferences {
  SettingsLocalPreferences(this._prefs);

  final SharedPreferences _prefs;

  static const _themeModeKey = 'settings_theme_mode';
  static const _localeKey = 'settings_locale';
  static const _gestureEnabledKey = 'settings_gesture_enabled';
  static const _voiceConfirmationKey = 'settings_voice_confirmation_enabled';
  static const _cameraLensKey = 'settings_default_camera_lens';

  ThemeMode get themeMode => switch (_prefs.getString(_themeModeKey)) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      };

  Future<void> setThemeMode(ThemeMode mode) {
    final value = switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    };
    return _prefs.setString(_themeModeKey, value);
  }

  /// `null` means "not set yet" — `LocaleNotifier` falls back to the
  /// device locale in that case rather than always defaulting to English.
  AppLocale? get locale => AppLocaleMeta.fromLanguageCode(_prefs.getString(_localeKey));

  Future<void> setLocale(AppLocale locale) => _prefs.setString(_localeKey, locale.name);

  bool get gestureRecognitionEnabled => _prefs.getBool(_gestureEnabledKey) ?? true;

  Future<void> setGestureRecognitionEnabled(bool value) =>
      _prefs.setBool(_gestureEnabledKey, value);

  bool get voiceConfirmationEnabled => _prefs.getBool(_voiceConfirmationKey) ?? true;

  Future<void> setVoiceConfirmationEnabled(bool value) =>
      _prefs.setBool(_voiceConfirmationKey, value);

  PreferredCameraLens get preferredCameraLens =>
      _prefs.getString(_cameraLensKey) == 'back'
          ? PreferredCameraLens.back
          : PreferredCameraLens.front;

  Future<void> setPreferredCameraLens(PreferredCameraLens lens) =>
      _prefs.setString(_cameraLensKey, lens.name);
}
