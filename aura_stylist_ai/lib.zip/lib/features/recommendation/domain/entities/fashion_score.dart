/// The spec's "AI FASHION SCORE" section: "Calculate: Overall Score,
/// Color Match, Occasion Match, Body Match, Professional Score, Style
/// Score. Display charts and textual explanation."
///
/// All scores are 0-100. These are heuristic, rule-based scores (see
/// `FashionScoreCalculator`'s doc comment) — a genuine best-effort
/// stylist model, not a machine-learned or clinically validated one.
class FashionScore {
  const FashionScore({
    required this.overallScore,
    required this.colorMatchScore,
    required this.occasionMatchScore,
    required this.bodyMatchScore,
    required this.professionalScore,
    required this.styleScore,
    required this.explanation,
  });

  final int overallScore;
  final int colorMatchScore;
  final int occasionMatchScore;
  final int bodyMatchScore;
  final int professionalScore;
  final int styleScore;

  /// Generated textual explanation ("Display... textual explanation" per
  /// the spec) — a short, tiered summary of the scores above.
  final String explanation;
}
