import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/clothing_layer.dart';
import 'fashion_score.dart';

/// The result of `RecommendationEngine.recommend()` — the spec's "AI
/// RECOMMENDATION ENGINE" output: "Best Outfit, Matching Colors, Matching
/// Accessories, Matching Shoes, Style Tips." Matching accessories/shoes
/// fall out naturally here since [items] already includes whatever the
/// engine picked for the accessories/shoes layers, if the catalog has any.
class OutfitRecommendation {
  const OutfitRecommendation({
    required this.items,
    required this.matchingColors,
    required this.styleTips,
    required this.fashionScore,
  });

  /// The best item chosen per layer.
  final Map<ClothingLayer, ClothingItem> items;

  /// Recommended color names for the user's skin tone (from Module 5's
  /// `SkinTone.recommendedColors`), shown alongside the outfit as general
  /// palette guidance beyond just the specific items picked.
  final List<String> matchingColors;

  final List<String> styleTips;
  final FashionScore fashionScore;
}
