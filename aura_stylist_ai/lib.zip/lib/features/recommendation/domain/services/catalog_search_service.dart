import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/clothing_layer.dart';
import '../../../tryon/domain/entities/occasion.dart';
import 'color_matching_service.dart';

/// Filters the clothing catalog by color and/or category — the real
/// target for the spec's "Show blue shirts" / "Show casual" voice
/// commands (`VoiceCommandType.showItems`).
class CatalogSearchService {
  const CatalogSearchService({this.colorMatchingService = const ColorMatchingService()});

  final ColorMatchingService colorMatchingService;

  List<ClothingItem> filter(
    List<ClothingItem> catalog, {
    String? color,
    String? category,
  }) {
    return catalog.where((item) {
      final colorMatches = color == null ||
          colorMatchingService.nameFor(item.color).toLowerCase().contains(color.toLowerCase());
      final categoryMatches = category == null || _matchesCategory(item, category);
      return colorMatches && categoryMatches;
    }).toList();
  }

  bool _matchesCategory(ClothingItem item, String category) {
    final normalized = category.toLowerCase();
    if (item.layer.label.toLowerCase().contains(normalized)) return true;
    if (item.name.toLowerCase().contains(normalized)) return true;
    return item.suitableOccasions.any(
      (occasion) =>
          occasion.name.toLowerCase() == normalized ||
          occasion.label.toLowerCase() == normalized,
    );
  }
}
