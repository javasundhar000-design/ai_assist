import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../../vision/domain/entities/body_metrics.dart';
import '../../../vision/domain/entities/skin_tone.dart';
import '../entities/fashion_score.dart';
import 'body_match_service.dart';
import 'color_matching_service.dart';

/// Computes the spec's six-metric "AI FASHION SCORE" for a set of items.
///
/// **How each score is derived** (documented since these are genuine
/// design decisions, not arbitrary numbers):
///  - **Color Match**: average of each item's `ColorMatchingService`
///    score against the user's `SkinTone.recommendedColors`.
///  - **Occasion Match**: each item scores 100 if [occasion] is in its
///    `suitableOccasions`, else 40 (partial credit — real garments aren't
///    strictly single-occasion, so a mismatch isn't treated as a hard
///    zero).
///  - **Body Match**: average of each item's `BodyMatchService` score
///    against the user's `BodyType`.
///  - **Professional Score**: a *separate* metric from Occasion Match —
///    it measures general office/interview/formal suitability regardless
///    of which occasion was actually requested, so "recommend a wedding
///    outfit" can still report how professional the result would look.
///  - **Style Score**: color-match average, penalized if the outfit uses
///    more than 3 distinct named colors (a simple coherence heuristic —
///    too many competing colors reads as less put-together).
///  - **Overall Score**: the unweighted average of the five scores above,
///    matching how the spec lists "Overall Score" alongside (not clearly
///    subordinate to) the other five.
///
/// This is a rule-based heuristic scorer, not a trained model — see the
/// module README for the full honesty notes. Pure Dart, fully
/// unit-testable.
class FashionScoreCalculator {
  const FashionScoreCalculator({
    this.colorMatchingService = const ColorMatchingService(),
    this.bodyMatchService = const BodyMatchService(),
  });

  final ColorMatchingService colorMatchingService;
  final BodyMatchService bodyMatchService;

  static const _professionalOccasions = {
    Occasion.office,
    Occasion.interview,
    Occasion.formal,
  };

  FashionScore calculate({
    required List<ClothingItem> items,
    required Occasion occasion,
    SkinTone? skinTone,
    BodyType? bodyType,
  }) {
    if (items.isEmpty) {
      return const FashionScore(
        overallScore: 0,
        colorMatchScore: 0,
        occasionMatchScore: 0,
        bodyMatchScore: 0,
        professionalScore: 0,
        styleScore: 0,
        explanation: 'No items selected yet — try something on to see your score.',
      );
    }

    final recommendedColors = skinTone?.recommendedColors ?? const <String>[];

    final colorMatch = _average(
      items.map((item) => colorMatchingService.scoreFor(item.color, recommendedColors)),
    );

    final occasionMatch = _average(
      items.map((item) => item.suitableOccasions.contains(occasion) ? 100 : 40),
    );

    final bodyMatch = _average(
      items.map(
        (item) => bodyType == null ? 70 : bodyMatchService.scoreFor(bodyType, item.fit),
      ),
    );

    final professional = _average(
      items.map(
        (item) => item.suitableOccasions.any(_professionalOccasions.contains) ? 100 : 35,
      ),
    );

    final distinctColorNames =
        items.map((item) => colorMatchingService.nameFor(item.color)).toSet();
    final coherencePenalty =
        distinctColorNames.length > 3 ? (distinctColorNames.length - 3) * 10 : 0;
    final style = (colorMatch - coherencePenalty).clamp(0, 100);

    final overall = _average([colorMatch, occasionMatch, bodyMatch, professional, style]);

    return FashionScore(
      overallScore: overall,
      colorMatchScore: colorMatch,
      occasionMatchScore: occasionMatch,
      bodyMatchScore: bodyMatch,
      professionalScore: professional,
      styleScore: style,
      explanation: _buildExplanation(
        overall: overall,
        colorMatch: colorMatch,
        occasionMatch: occasionMatch,
        occasion: occasion,
        skinTone: skinTone,
        bodyType: bodyType,
      ),
    );
  }

  int _average(Iterable<num> values) {
    final list = values.toList();
    if (list.isEmpty) return 0;
    return (list.reduce((a, b) => a + b) / list.length).round();
  }

  String _buildExplanation({
    required int overall,
    required int colorMatch,
    required int occasionMatch,
    required Occasion occasion,
    SkinTone? skinTone,
    BodyType? bodyType,
  }) {
    final tier = overall >= 85
        ? 'a great look'
        : overall >= 70
            ? 'a solid look'
            : overall >= 50
                ? 'a decent starting point'
                : 'a look that could use some adjustments';

    final buffer = StringBuffer('This is $tier for ${occasion.label.toLowerCase()}.');

    if (skinTone != null) {
      buffer.write(
        colorMatch >= 70
            ? ' The colors work well with your ${skinTone.label.toLowerCase()} skin tone.'
            : ' Consider colors closer to your recommended palette for your '
                '${skinTone.label.toLowerCase()} skin tone.',
      );
    }

    if (bodyType != null) {
      buffer.write(' Fit is tuned for a ${bodyType.label.toLowerCase()} build.');
    }

    if (occasionMatch < 70) {
      buffer.write(
        " A few pieces here aren't typically worn for ${occasion.label.toLowerCase()} occasions.",
      );
    }

    return buffer.toString();
  }
}
