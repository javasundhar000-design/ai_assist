import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/clothing_layer.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../../vision/domain/entities/body_metrics.dart';
import '../../../vision/domain/entities/skin_tone.dart';
import '../entities/outfit_recommendation.dart';
import 'body_match_service.dart';
import 'color_matching_service.dart';
import 'fashion_score_calculator.dart';

/// The spec's "AI RECOMMENDATION ENGINE": picks the best catalog item for
/// every layer, given occasion + skin tone + body type, and packages the
/// result with matching colors, style tips, and a fashion score.
///
/// Per-item scoring weights occasion and color equally (0.4 each) with
/// body match weighted lower (0.2) — occasion-appropriateness and color
/// suitability are the two factors the spec calls out most prominently,
/// while body match is a refinement on top of an already-appropriate
/// choice rather than the primary filter.
class RecommendationEngine {
  const RecommendationEngine({
    this.colorMatchingService = const ColorMatchingService(),
    this.bodyMatchService = const BodyMatchService(),
    this.fashionScoreCalculator = const FashionScoreCalculator(),
  });

  final ColorMatchingService colorMatchingService;
  final BodyMatchService bodyMatchService;
  final FashionScoreCalculator fashionScoreCalculator;

  OutfitRecommendation recommend({
    required List<ClothingItem> catalog,
    required Occasion occasion,
    SkinTone? skinTone,
    BodyType? bodyType,
  }) {
    final recommendedColors = skinTone?.recommendedColors ?? const <String>[];
    final selected = <ClothingLayer, ClothingItem>{};

    for (final layer in ClothingLayer.values) {
      // Whole-outfit images are a manual, opt-in "preview mode" (see
      // `TryOnSessionController`'s mutual-exclusivity logic) — not
      // meant to be auto-combined with independently-recommended
      // shirt/jacket/pant/shoes picks, which would overlap it visually.
      if (layer == ClothingLayer.outfit) continue;

      final candidates = catalog.where((item) => item.layer == layer).toList();
      if (candidates.isEmpty) continue;

      candidates.sort(
        (a, b) => _itemScore(b, occasion, recommendedColors, bodyType)
            .compareTo(_itemScore(a, occasion, recommendedColors, bodyType)),
      );
      selected[layer] = candidates.first;
    }

    final score = fashionScoreCalculator.calculate(
      items: selected.values.toList(),
      occasion: occasion,
      skinTone: skinTone,
      bodyType: bodyType,
    );

    return OutfitRecommendation(
      items: selected,
      matchingColors: recommendedColors,
      styleTips: _buildStyleTips(occasion: occasion, skinTone: skinTone, bodyType: bodyType),
      fashionScore: score,
    );
  }

  double _itemScore(
    ClothingItem item,
    Occasion occasion,
    List<String> recommendedColors,
    BodyType? bodyType,
  ) {
    final colorScore = colorMatchingService.scoreFor(item.color, recommendedColors);
    final occasionScore = item.suitableOccasions.contains(occasion) ? 100 : 40;
    final bodyScore = bodyType == null ? 70 : bodyMatchService.scoreFor(bodyType, item.fit);
    return colorScore * 0.4 + occasionScore * 0.4 + bodyScore * 0.2;
  }

  List<String> _buildStyleTips({
    required Occasion occasion,
    SkinTone? skinTone,
    BodyType? bodyType,
  }) {
    final tips = <String>[];

    if (skinTone != null) {
      final colors = skinTone.recommendedColors.take(3).join(', ');
      tips.add('Lean into $colors for your ${skinTone.label.toLowerCase()} skin tone.');
    } else {
      tips.add("Try the Smart Mirror's skin-tone analysis for a more tailored palette.");
    }

    if (bodyType != null) {
      final fitTip = switch (bodyType) {
        BodyType.slim => 'Fitted and slim cuts will accentuate your frame.',
        BodyType.athletic => 'Structured, tailored pieces suit your build well.',
        BodyType.average => 'Most regular fits will work well for you.',
        BodyType.broad => 'Relaxed, well-proportioned cuts tend to flatter most.',
      };
      tips.add(fitTip);
    }

    final occasionTip = switch (occasion) {
      Occasion.interview => 'Keep accessories minimal and colors conservative for interviews.',
      Occasion.wedding => 'This is a good occasion to lean into your best formalwear.',
      Occasion.college => 'Comfort and personal style both matter here — have fun with it.',
      Occasion.party => 'A statement accessory can elevate the whole look.',
      Occasion.office => 'Stick to polished, professional pieces.',
      Occasion.casual => 'Comfort-first, but a coordinated color palette still helps.',
      Occasion.formal => 'Structured pieces and classic colors read as more formal.',
      Occasion.traditional => 'Traditional pieces pair well with minimal modern accessories.',
    };
    tips.add(occasionTip);

    return tips;
  }
}
