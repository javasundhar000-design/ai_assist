import '../../../tryon/domain/entities/fit_type.dart';
import '../../../vision/domain/entities/body_metrics.dart';

/// Scores how well a garment's cut ([FitType]) suits a [BodyType].
///
/// This is a genuine best-effort stylist heuristic — common styling
/// advice (e.g. structured/tailored cuts read as more athletic-flattering,
/// relaxed cuts are generally more forgiving/flattering on a broader
/// frame) — not a scientifically validated model. Same honesty pattern as
/// Module 5's `FaceShapeEstimator`/`BodyTypeEstimator`: treat this as a
/// reasonable starting point, not a guarantee, and it's swappable for a
/// more sophisticated implementation later without touching any caller.
class BodyMatchService {
  const BodyMatchService();

  static const Map<BodyType, Map<FitType, int>> _compatibility = {
    BodyType.slim: {
      FitType.slim: 90,
      FitType.regular: 80,
      FitType.relaxed: 75,
      FitType.structured: 65,
    },
    BodyType.athletic: {
      FitType.structured: 90,
      FitType.slim: 85,
      FitType.regular: 80,
      FitType.relaxed: 70,
    },
    BodyType.average: {
      FitType.regular: 90,
      FitType.structured: 80,
      FitType.slim: 75,
      FitType.relaxed: 75,
    },
    BodyType.broad: {
      FitType.relaxed: 90,
      FitType.structured: 80,
      FitType.regular: 75,
      FitType.slim: 55,
    },
  };

  int scoreFor(BodyType bodyType, FitType fit) {
    return _compatibility[bodyType]?[fit] ?? 70;
  }
}
