import 'dart:math' as math;
import 'dart:ui';

/// Names swatches and scores color compatibility for the recommendation
/// engine.
///
/// Deliberately simpler than Module 5's `ColorScience` (which does full
/// LAB-space conversion for skin-tone classification, where perceptual
/// accuracy genuinely matters): here we just need "which named color is
/// this swatch closest to", which a plain RGB Euclidean nearest-neighbor
/// answers well enough for a small, fixed palette. Pure Dart, fully
/// unit-testable.
class ColorMatchingService {
  const ColorMatchingService();

  /// Every color name referenced anywhere in the app: all 24 unique names
  /// across `SkinTone.recommendedColors` (Module 5), plus a few generic
  /// ones needed to name the demo catalog's own swatches.
  static const Map<String, Color> _palette = {
    'Navy': Color(0xFF1B2A4A),
    'Emerald': Color(0xFF2E8B57),
    'Burgundy': Color(0xFF800020),
    'Cool Gray': Color(0xFF8C92AC),
    'Soft Pink': Color(0xFFF4C2C2),
    'Periwinkle': Color(0xFFCCCCFF),
    'Sage Green': Color(0xFF9CAF88),
    'Charcoal': Color(0xFF36454F),
    'Coral': Color(0xFFFF7F50),
    'Teal': Color(0xFF008080),
    'Mustard': Color(0xFFE1AD01),
    'Warm Brown': Color(0xFF964B00),
    'Olive Green': Color(0xFF708238),
    'Terracotta': Color(0xFFE2725B),
    'Cream': Color(0xFFFFFDD0),
    'Deep Purple': Color(0xFF4B0082),
    'Amber': Color(0xFFFFBF00),
    'Royal Blue': Color(0xFF4169E1),
    'Ivory': Color(0xFFFFFFF0),
    'Rust': Color(0xFFB7410E),
    'Bright White': Color(0xFFFFFFFF),
    'Fuchsia': Color(0xFFFF00FF),
    'Cobalt Blue': Color(0xFF0047AB),
    'Gold': Color(0xFFD4AF37),
    'Black': Color(0xFF1A1A1A),
    'White': Color(0xFFF5F5F5),
    'Denim Blue': Color(0xFF3B5B92),
  };

  static const double _maxRgbDistance = 441.7; // sqrt(255^2 * 3)

  /// The closest named color to [color] by RGB distance.
  String nameFor(Color color) {
    var bestName = _palette.keys.first;
    var bestDistance = double.infinity;
    for (final entry in _palette.entries) {
      final distance = _distance(color, entry.value);
      if (distance < bestDistance) {
        bestDistance = distance;
        bestName = entry.key;
      }
    }
    return bestName;
  }

  /// 0-100 score for how well [itemColor] suits [recommendedColors] (a
  /// `SkinTone.recommendedColors` list). An exact named match scores 100;
  /// otherwise the score scales down smoothly with RGB distance to the
  /// *nearest* recommended color (floored at 20) rather than dropping
  /// straight to zero for "close but not exact" — a color one shade off
  /// from "Navy" should still read as a reasonable choice.
  int scoreFor(Color itemColor, List<String> recommendedColors) {
    if (recommendedColors.isEmpty) return 50; // no skin-tone data — neutral score

    final name = nameFor(itemColor);
    if (recommendedColors.contains(name)) return 100;

    var bestDistance = double.infinity;
    for (final recommendedName in recommendedColors) {
      final recommendedColor = _palette[recommendedName];
      if (recommendedColor == null) continue;
      final distance = _distance(itemColor, recommendedColor);
      if (distance < bestDistance) bestDistance = distance;
    }
    if (bestDistance == double.infinity) return 50;

    final similarity = (1 - (bestDistance / _maxRgbDistance)).clamp(0.0, 1.0);
    return (20 + similarity * 80).round();
  }

  double _distance(Color a, Color b) {
    final dr = a.red - b.red;
    final dg = a.green - b.green;
    final db = a.blue - b.blue;
    return math.sqrt((dr * dr + dg * dg + db * db).toDouble());
  }
}
