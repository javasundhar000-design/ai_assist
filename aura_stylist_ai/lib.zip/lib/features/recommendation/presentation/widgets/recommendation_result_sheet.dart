import 'package:flutter/material.dart';

import '../../../../core/theme/app_tokens.dart';
import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/clothing_layer.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../domain/entities/outfit_recommendation.dart';
import 'fashion_score_card.dart';

/// Shown after "Recommend [occasion] outfit" — the real target for that
/// voice command. "Wear This" hands every recommended layer straight to
/// `TryOnSessionController.selectItem`, so the recommendation immediately
/// renders live on the Smart Mirror.
class RecommendationResultSheet extends StatelessWidget {
  const RecommendationResultSheet({
    super.key,
    required this.recommendation,
    required this.occasion,
    required this.onWearThis,
  });

  final OutfitRecommendation recommendation;
  final Occasion occasion;
  final VoidCallback onWearThis;

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      minChildSize: 0.4,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return ListView(
          controller: scrollController,
          padding: const EdgeInsets.all(AppSpacing.md),
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: AppSpacing.md),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Text(
              '${occasion.label} Outfit',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: AppSpacing.md),
            _OutfitRow(items: recommendation.items),
            const SizedBox(height: AppSpacing.lg),
            if (recommendation.matchingColors.isNotEmpty) ...[
              Text('Matching Colors', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: AppSpacing.sm),
              Wrap(
                spacing: AppSpacing.sm,
                runSpacing: AppSpacing.sm,
                children: [
                  for (final color in recommendation.matchingColors)
                    Chip(label: Text(color)),
                ],
              ),
              const SizedBox(height: AppSpacing.lg),
            ],
            Text('Style Tips', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: AppSpacing.sm),
            for (final tip in recommendation.styleTips)
              Padding(
                padding: const EdgeInsets.only(bottom: AppSpacing.xs),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.auto_awesome, size: 16),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(child: Text(tip)),
                  ],
                ),
              ),
            const SizedBox(height: AppSpacing.lg),
            Text('Fashion Score', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: AppSpacing.sm),
            FashionScoreCard(score: recommendation.fashionScore),
            const SizedBox(height: AppSpacing.lg),
            FilledButton.icon(
              onPressed: onWearThis,
              icon: const Icon(Icons.checkroom_rounded),
              label: const Text('Wear This'),
            ),
            const SizedBox(height: AppSpacing.md),
          ],
        );
      },
    );
  }
}

class _OutfitRow extends StatelessWidget {
  const _OutfitRow({required this.items});

  final Map<ClothingLayer, ClothingItem> items;

  @override
  Widget build(BuildContext context) {
    final entries = items.entries.toList();
    return SizedBox(
      height: 84,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: entries.length,
        separatorBuilder: (context, index) => const SizedBox(width: AppSpacing.sm),
        itemBuilder: (context, index) {
          final layer = entries[index].key;
          final item = entries[index].value;
          return Column(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(color: item.color, shape: BoxShape.circle),
              ),
              const SizedBox(height: 4),
              SizedBox(
                width: 64,
                child: Text(
                  layer.label,
                  style: Theme.of(context).textTheme.labelSmall,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
