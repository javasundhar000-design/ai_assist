import 'package:flutter/material.dart';

import '../../../../core/theme/app_tokens.dart';
import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/clothing_layer.dart';

/// Real target for the "Show blue shirts" / "Show casual" voice command
/// (`VoiceCommandType.showItems`) — shows whatever `CatalogSearchService`
/// matched, with a tap-to-try action wired straight to
/// `TryOnSessionController.selectItem`.
class CatalogSearchResultsSheet extends StatelessWidget {
  const CatalogSearchResultsSheet({
    super.key,
    required this.results,
    required this.query,
    required this.onSelect,
  });

  final List<ClothingItem> results;
  final String query;
  final void Function(ClothingItem item) onSelect;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: AppSpacing.md),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Text(
            query.trim().isEmpty ? 'Results' : 'Showing "$query"',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: AppSpacing.md),
          if (results.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: AppSpacing.lg),
              child: Text(
                'Nothing in the demo catalog matches that yet — try a different color or category.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            )
          else
            for (final item in results)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(color: item.color, shape: BoxShape.circle),
                ),
                title: Text(item.name),
                subtitle: Text(item.layer.label),
                trailing: FilledButton.tonal(
                  onPressed: () => onSelect(item),
                  child: const Text('Try it'),
                ),
              ),
        ],
      ),
    );
  }
}
