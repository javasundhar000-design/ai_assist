import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../domain/entities/fashion_score.dart';

/// Renders the spec's "AI FASHION SCORE" as simple horizontal bars (no
/// external charting package needed) plus the generated textual
/// explanation — "Display charts and textual explanation" per the spec.
class FashionScoreCard extends StatelessWidget {
  const FashionScoreCard({super.key, required this.score});

  final FashionScore score;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _OverallScoreBadge(value: score.overallScore),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        _ScoreBar(label: 'Color Match', value: score.colorMatchScore),
        _ScoreBar(label: 'Occasion Match', value: score.occasionMatchScore),
        _ScoreBar(label: 'Body Match', value: score.bodyMatchScore),
        _ScoreBar(label: 'Professional', value: score.professionalScore),
        _ScoreBar(label: 'Style', value: score.styleScore),
        const SizedBox(height: AppSpacing.md),
        Text(
          score.explanation,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      ],
    );
  }
}

class _OverallScoreBadge extends StatelessWidget {
  const _OverallScoreBadge({required this.value});

  final int value;

  @override
  Widget build(BuildContext context) {
    final color = _colorFor(value);
    return Container(
      width: 96,
      height: 96,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: color, width: 4),
      ),
      alignment: Alignment.center,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '$value',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: color,
                ),
          ),
          Text('/ 100', style: Theme.of(context).textTheme.labelSmall),
        ],
      ),
    );
  }
}

class _ScoreBar extends StatelessWidget {
  const _ScoreBar({required this.label, required this.value});

  final String label;
  final int value;

  @override
  Widget build(BuildContext context) {
    final color = _colorFor(value);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: Text(label, style: Theme.of(context).textTheme.bodySmall),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.pill),
              child: LinearProgressIndicator(
                value: value / 100,
                minHeight: 8,
                backgroundColor:
                    Theme.of(context).colorScheme.onSurface.withOpacity(0.08),
                valueColor: AlwaysStoppedAnimation(color),
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          SizedBox(
            width: 32,
            child: Text(
              '$value',
              textAlign: TextAlign.right,
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ),
        ],
      ),
    );
  }
}

Color _colorFor(int value) {
  if (value >= 85) return AppColors.success;
  if (value >= 60) return AppColors.info;
  if (value >= 40) return AppColors.warning;
  return AppColors.error;
}
