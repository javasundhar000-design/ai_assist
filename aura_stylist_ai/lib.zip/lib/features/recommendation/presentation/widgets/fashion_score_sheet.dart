import 'package:flutter/material.dart';

import '../../../../core/theme/app_tokens.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../domain/entities/fashion_score.dart';
import 'fashion_score_card.dart';

/// Real target for the "Score My Look" action — scores whatever the user
/// currently has selected in `TryOnSessionController` against [occasion]
/// (defaults to Casual unless a "recommend [occasion] outfit" request set
/// a more specific context earlier — see `SmartCameraPage`).
class FashionScoreSheet extends StatelessWidget {
  const FashionScoreSheet({super.key, required this.score, required this.occasion});

  final FashionScore score;
  final Occasion occasion;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: AppSpacing.md),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Text(
            'Scored for ${occasion.label}',
            style: Theme.of(context).textTheme.titleLarge,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: AppSpacing.md),
          FashionScoreCard(score: score),
        ],
      ),
    );
  }
}
