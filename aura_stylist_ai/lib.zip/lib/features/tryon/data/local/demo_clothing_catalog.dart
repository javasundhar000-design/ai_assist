import 'dart:ui';

import '../../domain/entities/clothing_anchor_config.dart';
import '../../domain/entities/clothing_item.dart';
import '../../domain/entities/clothing_layer.dart';
import '../../domain/entities/fit_type.dart';
import '../../domain/entities/occasion.dart';

/// A small, hand-picked demo catalog — enough items per layer to exercise
/// every `AnchorReference` case and every `Occasion`/`FitType` combination
/// Module 9's recommendation engine scores against. Items ship with a
/// `color` fallback out of the box; set `imagePath` on any item once you
/// have a real transparent-PNG garment cutout to make it render as an
/// actual photo instead of a silhouette — nothing else needs to change,
/// the anchor/tracking system already treats both identically. See
/// `ClothingItem`'s doc comment for asset requirements, and Module 10
/// (Wardrobe) for where a real, Firebase-backed catalog belongs.
const List<ClothingItem> demoClothingCatalog = [
  ClothingItem(
    id: 'shirt-navy',
    name: 'Navy Shirt',
    layer: ClothingLayer.shirt,
    color: Color(0xFF223A5E),
    imagePath: 'assets/clothing/shirt_navy.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.neckToChest,
      verticalOffsetFraction: 2.6,
      widthScale: 1.15,
      aspectRatio: 0.85,
    ),
    fit: FitType.regular,
    suitableOccasions: [Occasion.office, Occasion.interview, Occasion.casual],
  ),
  ClothingItem(
    id: 'shirt-white',
    name: 'White Shirt',
    layer: ClothingLayer.shirt,
    color: Color(0xFFF5F5F5),
    imagePath: 'assets/clothing/shirt_white.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.neckToChest,
      verticalOffsetFraction: 2.6,
      widthScale: 1.15,
      aspectRatio: 0.85,
    ),
    fit: FitType.regular,
    suitableOccasions: [Occasion.office, Occasion.interview, Occasion.formal, Occasion.wedding],
  ),
  ClothingItem(
    id: 'jacket-black',
    name: 'Black Jacket',
    layer: ClothingLayer.jacket,
    color: Color(0xFF1A1A1A),
    imagePath: 'assets/clothing/jacket_black.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.neckToChest,
      verticalOffsetFraction: 2.8,
      widthScale: 1.3,
      aspectRatio: 0.8,
    ),
    fit: FitType.structured,
    suitableOccasions: [Occasion.interview, Occasion.formal, Occasion.wedding, Occasion.office],
  ),
  ClothingItem(
    id: 'pant-denim',
    name: 'Denim Jeans',
    layer: ClothingLayer.pant,
    color: Color(0xFF3B5B92),
    imagePath: 'assets/clothing/pant_denim.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.hipToBelow,
      verticalOffsetFraction: 2.2,
      widthScale: 1.05,
      aspectRatio: 0.55,
    ),
    fit: FitType.relaxed,
    suitableOccasions: [Occasion.casual, Occasion.college, Occasion.party],
  ),
  ClothingItem(
    id: 'shoes-white',
    name: 'White Sneakers',
    layer: ClothingLayer.shoes,
    color: Color(0xFFEFEFEF),
    imagePath: 'assets/clothing/shoes_white.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.ankles,
      aspectRatio: 2.2,
    ),
    fit: FitType.regular,
    suitableOccasions: [Occasion.casual, Occasion.college, Occasion.party],
  ),
  ClothingItem(
    id: 'hat-black',
    name: 'Black Cap',
    layer: ClothingLayer.hat,
    color: Color(0xFF111111),
    imagePath: 'assets/clothing/hat_black.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.headTop,
      aspectRatio: 1.6,
    ),
    fit: FitType.relaxed,
    suitableOccasions: [Occasion.casual, Occasion.college],
  ),
  ClothingItem(
    id: 'glasses-classic',
    name: 'Classic Glasses',
    layer: ClothingLayer.glasses,
    color: Color(0xFF2B2B2B),
    imagePath: 'assets/clothing/glasses_classic.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.eyesLevel,
      aspectRatio: 3.2,
    ),
    fit: FitType.regular,
    suitableOccasions: [
      Occasion.office,
      Occasion.interview,
      Occasion.formal,
      Occasion.casual,
    ],
  ),
  ClothingItem(
    id: 'hair-short-brown',
    name: 'Short Brown Hair',
    layer: ClothingLayer.hair,
    color: Color(0xFF5B3A29),
    imagePath: 'assets/clothing/hair_short_brown.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.headTop,
      widthScale: 1.15,
      aspectRatio: 1.1,
    ),
    fit: FitType.regular,
    // Hair is worn regardless of occasion — tagged universally rather
    // than left empty, since an empty list would read as "suits nothing"
    // to the scoring logic.
    suitableOccasions: Occasion.values,
  ),
  ClothingItem(
    id: 'accessory-pendant',
    name: 'Gold Pendant',
    layer: ClothingLayer.accessories,
    color: Color(0xFFD4AF37),
    imagePath: 'assets/clothing/accessory_pendant.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.chestPendant,
    ),
    fit: FitType.slim,
    suitableOccasions: [Occasion.party, Occasion.wedding, Occasion.casual],
  ),
  ClothingItem(
    id: 'outfit-tan-suit',
    name: 'Tan Suit (Full Outfit)',
    layer: ClothingLayer.outfit,
    color: Color(0xFFB29263),
    imagePath: 'assets/clothing/outfit_tan_suit.png',
    anchorConfig: ClothingAnchorConfig(
      reference: AnchorReference.fullBody,
      // aspectRatio = image's own width / height (420 / 980) — see
      // `_fullBodyTransform`'s doc comment for why this direction is
      // reversed from every other layer's config.
      aspectRatio: 420 / 980,
      widthScale: 1.0,
    ),
    fit: FitType.regular,
    suitableOccasions: [Occasion.interview, Occasion.office, Occasion.wedding],
  ),
];
