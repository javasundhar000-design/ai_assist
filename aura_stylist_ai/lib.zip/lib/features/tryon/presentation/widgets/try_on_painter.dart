import 'dart:ui';
import 'dart:ui' as ui show Image;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart' show Colors;
import 'package:flutter/rendering.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../../vision/presentation/painters/coordinate_translator.dart';
import '../../domain/entities/clothing_layer.dart';
import '../../domain/entities/layer_transform.dart';

typedef _TryOnEntry = ({
  ClothingLayer layer,
  Color color,
  LayerTransform transform,
  ui.Image? image,
});

/// Renders every selected clothing layer, either as a real garment image
/// (when `ClothingItem.imagePath` resolves to a loaded `ui.Image`) or,
/// failing that, a simple procedural silhouette so positioning is still
/// visible/verifiable even before real assets are added. Either way the
/// *positioning* — center, size, rotation, all driven by live body
/// tracking — is identical; only the drawing call at the bottom changes.
class TryOnPainter extends CustomPainter {
  TryOnPainter({
    required this.entries,
    required this.rotation,
    required this.lensDirection,
    required this.imageSize,
  });

  final List<_TryOnEntry> entries;
  final InputImageRotation rotation;
  final CameraLensDirection lensDirection;
  final Size imageSize;

  @override
  void paint(Canvas canvas, Size size) {
    final sorted = [...entries]..sort((a, b) => a.layer.zIndex.compareTo(b.layer.zIndex));
    final scaleX = CoordinateTranslator.scaleX(rotation, size, imageSize);
    final scaleY = CoordinateTranslator.scaleY(rotation, size, imageSize);

    for (final entry in sorted) {
      final center = CoordinateTranslator.translate(
        entry.transform.center,
        rotation,
        size,
        imageSize,
        lensDirection,
      );
      final width = entry.transform.width * scaleX;
      final height = entry.transform.height * scaleY;

      // The preview texture is mirrored for the front camera (see
      // `MirroredCameraPreview`) but rotation angles computed in raw
      // sensor space aren't automatically mirrored by that — flip the
      // sign so clothing tilts the same direction the user visually
      // leans, matching the same mirroring correction Module 6's swipe
      // detection applies to on-screen movement direction.
      final visualRotation = lensDirection == CameraLensDirection.front
          ? -entry.transform.rotationRadians
          : entry.transform.rotationRadians;

      canvas.save();
      canvas.translate(center.dx, center.dy);
      canvas.rotate(visualRotation);
      if (entry.image != null) {
        _drawImage(canvas, entry.image!, width, height);
      } else {
        _drawLayer(canvas, entry.layer, width, height, entry.color);
      }
      canvas.restore();
    }
  }

  /// Draws the real garment image centered on the already-positioned
  /// origin, scaled to the same `width`/`height` the silhouette fallback
  /// uses — so swapping in a real asset for an item never changes its
  /// size or placement on the body, only what's actually drawn.
  void _drawImage(Canvas canvas, ui.Image image, double w, double h) {
    final src = Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble());
    final dst = Rect.fromCenter(center: Offset.zero, width: w, height: h);
    canvas.drawImageRect(image, src, dst, Paint()..filterQuality = FilterQuality.medium);
  }

  void _drawLayer(Canvas canvas, ClothingLayer layer, double w, double h, Color color) {
    switch (layer) {
      case ClothingLayer.shirt:
      case ClothingLayer.jacket:
        _drawTorso(canvas, w, h, color);
        break;
      case ClothingLayer.pant:
        _drawPants(canvas, w, h, color);
        break;
      case ClothingLayer.hat:
        _drawHat(canvas, w, h, color);
        break;
      case ClothingLayer.glasses:
        _drawGlasses(canvas, w, h, color);
        break;
      case ClothingLayer.hair:
        _drawHair(canvas, w, h, color);
        break;
      case ClothingLayer.shoes:
        _drawShoes(canvas, w, h, color);
        break;
      case ClothingLayer.accessories:
        _drawAccessory(canvas, w, h, color);
        break;
      case ClothingLayer.outfit:
        _drawOutfit(canvas, w, h, color);
        break;
    }
  }

  void _drawTorso(Canvas canvas, double w, double h, Color color) {
    final fill = Paint()..color = color.withOpacity(0.85);
    final outline = Paint()
      ..color = Colors.white.withOpacity(0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final path = Path()
      ..moveTo(-w / 2, -h / 2)
      ..lineTo(-w / 2 * 1.25, -h / 2 + h * 0.18)
      ..lineTo(-w / 2 * 1.05, -h / 2 + h * 0.5)
      ..lineTo(-w * 0.35, -h / 2 + h * 0.35)
      ..lineTo(-w * 0.35, h / 2)
      ..lineTo(w * 0.35, h / 2)
      ..lineTo(w * 0.35, -h / 2 + h * 0.35)
      ..lineTo(w / 2 * 1.05, -h / 2 + h * 0.5)
      ..lineTo(w / 2 * 1.25, -h / 2 + h * 0.18)
      ..lineTo(w / 2, -h / 2)
      ..close();
    canvas.drawPath(path, fill);
    canvas.drawPath(path, outline);
  }

  void _drawPants(Canvas canvas, double w, double h, Color color) {
    final fill = Paint()..color = color.withOpacity(0.85);
    final legGap = w * 0.08;
    final legWidth = (w - legGap) / 2;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(-w / 2, -h / 2, legWidth, h),
        const Radius.circular(6),
      ),
      fill,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(legGap / 2, -h / 2, legWidth, h),
        const Radius.circular(6),
      ),
      fill,
    );
  }

  void _drawHat(Canvas canvas, double w, double h, Color color) {
    final fill = Paint()..color = color.withOpacity(0.92);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(0, -h * 0.15), width: w * 0.85, height: h * 0.75),
      fill,
    );
    canvas.drawOval(
      Rect.fromCenter(center: Offset(0, h * 0.25), width: w, height: h * 0.28),
      fill,
    );
  }

  void _drawGlasses(Canvas canvas, double w, double h, Color color) {
    final stroke = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = h * 0.18;
    final lensWidth = w * 0.36;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(-w * 0.28, 0), width: lensWidth, height: h),
        Radius.circular(h * 0.3),
      ),
      stroke,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(w * 0.28, 0), width: lensWidth, height: h),
        Radius.circular(h * 0.3),
      ),
      stroke,
    );
    canvas.drawLine(Offset(-w * 0.08, 0), Offset(w * 0.08, 0), stroke);
  }

  void _drawHair(Canvas canvas, double w, double h, Color color) {
    final fill = Paint()..color = color.withOpacity(0.95);
    final rrect = RRect.fromRectAndCorners(
      Rect.fromCenter(center: Offset.zero, width: w, height: h),
      topLeft: Radius.circular(w * 0.5),
      topRight: Radius.circular(w * 0.5),
      bottomLeft: Radius.circular(w * 0.15),
      bottomRight: Radius.circular(w * 0.15),
    );
    canvas.drawRRect(rrect, fill);
  }

  void _drawShoes(Canvas canvas, double w, double h, Color color) {
    final fill = Paint()..color = color.withOpacity(0.9);
    canvas.drawOval(Rect.fromCenter(center: Offset(-w * 0.28, 0), width: w * 0.4, height: h), fill);
    canvas.drawOval(Rect.fromCenter(center: Offset(w * 0.28, 0), width: w * 0.4, height: h), fill);
  }

  void _drawAccessory(Canvas canvas, double w, double h, Color color) {
    final stroke = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawLine(Offset(0, -h * 0.6), Offset(0, -h * 0.1), stroke);
    canvas.drawCircle(Offset(0, h * 0.2), w * 0.35, Paint()..color = color);
  }

  /// Fallback used only when a whole-outfit item has no image loaded yet
  /// — a rough torso-plus-legs block so the full neck-to-ankle span is
  /// at least visible, rather than nothing, while the real image loads.
  void _drawOutfit(Canvas canvas, double w, double h, Color color) {
    final fill = Paint()..color = color.withOpacity(0.85);
    final outline = Paint()
      ..color = Colors.white.withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final torsoH = h * 0.42;
    final path = Path()
      ..moveTo(-w * 0.30, -h / 2)
      ..lineTo(-w * 0.46, -h / 2 + torsoH * 0.20)
      ..lineTo(-w * 0.34, -h / 2 + torsoH * 0.55)
      ..lineTo(-w * 0.30, -h / 2 + torsoH * 0.40)
      ..lineTo(-w * 0.30, -h / 2 + torsoH)
      ..lineTo(w * 0.30, -h / 2 + torsoH)
      ..lineTo(w * 0.30, -h / 2 + torsoH * 0.40)
      ..lineTo(w * 0.34, -h / 2 + torsoH * 0.55)
      ..lineTo(w * 0.46, -h / 2 + torsoH * 0.20)
      ..lineTo(w * 0.30, -h / 2)
      ..close();
    canvas.drawPath(path, fill);
    canvas.drawPath(path, outline);
    final legGap = w * 0.06;
    final legWidth = (w * 0.6 - legGap) / 2;
    final legTop = -h / 2 + torsoH;
    canvas.drawRect(Rect.fromLTWH(-w * 0.30, legTop, legWidth, h - torsoH), fill);
    canvas.drawRect(Rect.fromLTWH(legGap / 2 - w * 0.0, legTop, legWidth, h - torsoH), fill);
  }

  @override
  bool shouldRepaint(covariant TryOnPainter oldDelegate) => true;
}
