import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_tokens.dart';
import '../../domain/entities/clothing_item.dart';
import '../../domain/entities/clothing_layer.dart';
import '../providers/clothing_catalog_provider.dart';
import '../providers/try_on_session_controller.dart';

/// The "Wardrobe" sheet for this module's demo catalog — real target for
/// the spec's Open/Close Wardrobe voice commands. Tapping a swatch selects
/// it for that layer; tapping the already-selected swatch removes it.
class ClothingPickerSheet extends ConsumerWidget {
  const ClothingPickerSheet({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(tryOnSessionControllerProvider);
    final catalog = ref.watch(clothingCatalogProvider);

    final byLayer = <ClothingLayer, List<ClothingItem>>{};
    for (final item in catalog) {
      byLayer.putIfAbsent(item.layer, () => []).add(item);
    }

    return DraggableScrollableSheet(
      initialChildSize: 0.55,
      minChildSize: 0.3,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) {
        return Column(
          children: [
            const SizedBox(height: AppSpacing.sm),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Try On', style: Theme.of(context).textTheme.titleLarge),
                  TextButton(
                    onPressed: state.selectedItems.isEmpty
                        ? null
                        : () => ref.read(tryOnSessionControllerProvider.notifier).reset(),
                    child: const Text('Reset All'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                controller: scrollController,
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
                children: [
                  for (final layer in ClothingLayer.values)
                    if (byLayer[layer]?.isNotEmpty == true)
                      _LayerSection(
                        layer: layer,
                        items: byLayer[layer]!,
                        selected: state.selectedItems[layer],
                      ),
                  const SizedBox(height: AppSpacing.lg),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _LayerSection extends ConsumerWidget {
  const _LayerSection({required this.layer, required this.items, required this.selected});

  final ClothingLayer layer;
  final List<ClothingItem> items;
  final ClothingItem? selected;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(layer.label, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: AppSpacing.sm),
          SizedBox(
            height: 84,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: items.length,
              separatorBuilder: (context, index) => const SizedBox(width: AppSpacing.sm),
              itemBuilder: (context, index) {
                final item = items[index];
                final isSelected = selected?.id == item.id;
                return GestureDetector(
                  onTap: () {
                    final notifier = ref.read(tryOnSessionControllerProvider.notifier);
                    if (isSelected) {
                      notifier.removeLayer(layer);
                    } else {
                      notifier.selectItem(item);
                    }
                  },
                  child: Column(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: item.color,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isSelected
                                ? Theme.of(context).colorScheme.primary
                                : Colors.transparent,
                            width: 3,
                          ),
                        ),
                        child: isSelected
                            ? const Icon(Icons.check_rounded, color: Colors.white)
                            : null,
                      ),
                      const SizedBox(height: 4),
                      SizedBox(
                        width: 64,
                        child: Text(
                          item.name,
                          style: Theme.of(context).textTheme.labelSmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
