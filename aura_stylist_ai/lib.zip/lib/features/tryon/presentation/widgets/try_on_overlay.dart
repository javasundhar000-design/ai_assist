import 'package:camera/camera.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'dart:ui' as ui;

import '../../../vision/data/utils/input_image_converter.dart';
import '../providers/clothing_image_cache_provider.dart';
import '../providers/try_on_session_controller.dart';
import 'try_on_painter.dart';

/// Layers the current try-on selection on top of the camera preview.
/// Must be sized identically to the `CameraPreview` texture — see
/// `SmartCameraPage`, which wraps this and `MirroredCameraPreview` (and
/// Module 5's `VisionOverlay`) in the same `AspectRatio` box so all three
/// share one coordinate space.
class TryOnOverlay extends ConsumerWidget {
  const TryOnOverlay({super.key, required this.controller, required this.state});

  final CameraController controller;
  final TryOnState state;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final anchors = state.anchors;
    if (anchors == null || state.transforms.isEmpty) return const SizedBox.shrink();

    final rotation = InputImageConverter.rotationForSensor(
      sensorOrientation: controller.description.sensorOrientation,
      lensDirection: controller.description.lensDirection,
    );
    if (rotation == null) return const SizedBox.shrink();

    final imageCache = ref.read(clothingImageCacheProvider.notifier);
    final loadedImages = ref.watch(clothingImageCacheProvider);

    final entries = [
      for (final entry in state.transforms.entries)
        (
          layer: entry.key,
          color: state.selectedItems[entry.key]!.color,
          transform: entry.value,
          image: _resolveImage(
            state.selectedItems[entry.key]!.imagePath,
            loadedImages,
            imageCache,
          ),
        ),
    ];

    return IgnorePointer(
      child: CustomPaint(
        painter: TryOnPainter(
          entries: entries,
          rotation: rotation,
          lensDirection: controller.description.lensDirection,
          imageSize: anchors.imageSize,
        ),
      ),
    );
  }

  /// Returns the already-decoded image for `imagePath` if it's ready,
  /// kicking off a load for next frame if it isn't yet — so the very
  /// first frame after selecting a new item still falls back to the
  /// silhouette (no flash of a blank layer) and then swaps to the real
  /// image within a frame or two once decoding finishes.
  ui.Image? _resolveImage(
    String? imagePath,
    Map<String, ui.Image> loadedImages,
    ClothingImageCache cache,
  ) {
    if (imagePath == null) return null;
    final cached = loadedImages[imagePath];
    if (cached == null) cache.ensureLoaded(imagePath);
    return cached;
  }
}
