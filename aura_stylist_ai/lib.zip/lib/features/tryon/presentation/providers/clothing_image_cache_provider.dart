import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Decodes and caches real clothing-image assets as `ui.Image`.
///
/// `CustomPainter.paint()` runs synchronously every frame and can't
/// `await` an asset load, so images are decoded once up front (the first
/// time any item referencing them is selected) and handed to
/// `TryOnPainter` as plain, already-decoded `ui.Image`s from then on.
/// This mirrors `ClothingItem.imagePath` being optional: only assets
/// that are actually referenced by the catalog get loaded, so adding
/// items with no image yet costs nothing.
class ClothingImageCache extends StateNotifier<Map<String, ui.Image>> {
  ClothingImageCache() : super(const {});

  final _loading = <String>{};

  /// Kicks off a load for `assetPath` if it isn't already cached or in
  /// flight. Safe to call every build — cheap no-op once loaded.
  void ensureLoaded(String assetPath) {
    if (state.containsKey(assetPath) || _loading.contains(assetPath)) return;
    _loading.add(assetPath);
    unawaited(_load(assetPath));
  }

  Future<void> _load(String assetPath) async {
    try {
      final data = await rootBundle.load(assetPath);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final frame = await codec.getNextFrame();
      if (!mounted) return;
      state = {...state, assetPath: frame.image};
    } catch (_) {
      // Missing/broken asset: leave it out of the cache. TryOnPainter
      // falls back to the flat-color silhouette for any layer whose
      // image never resolves, so a bad asset path degrades gracefully
      // instead of crashing the try-on overlay.
    } finally {
      _loading.remove(assetPath);
    }
  }
}

final clothingImageCacheProvider =
    StateNotifierProvider<ClothingImageCache, Map<String, ui.Image>>(
  (ref) => ClothingImageCache(),
);
