import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/local/demo_clothing_catalog.dart';
import '../../domain/entities/clothing_item.dart';

final clothingCatalogProvider = Provider<List<ClothingItem>>((ref) => demoClothingCatalog);
