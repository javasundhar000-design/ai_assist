import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../vision/domain/entities/face_analysis.dart';
import '../../../vision/domain/entities/pose_analysis.dart';
import '../../../vision/presentation/providers/vision_pipeline_controller.dart';
import '../../domain/entities/body_anchor_points.dart';
import '../../domain/entities/clothing_item.dart';
import '../../domain/entities/clothing_layer.dart';
import '../../domain/entities/layer_transform.dart';
import '../../domain/services/body_anchor_calculator.dart';
import '../../domain/services/clothing_transform_calculator.dart';

class TryOnState {
  const TryOnState({
    this.selectedItems = const {},
    this.transforms = const {},
    this.anchors,
  });

  final Map<ClothingLayer, ClothingItem> selectedItems;
  final Map<ClothingLayer, LayerTransform> transforms;
  final BodyAnchorPoints? anchors;

  TryOnState copyWith({
    Map<ClothingLayer, ClothingItem>? selectedItems,
    Map<ClothingLayer, LayerTransform>? transforms,
    BodyAnchorPoints? anchors,
  }) {
    return TryOnState(
      selectedItems: selectedItems ?? this.selectedItems,
      transforms: transforms ?? this.transforms,
      anchors: anchors ?? this.anchors,
    );
  }
}

/// Manages which item is selected per layer and keeps their on-screen
/// transforms in sync with live body movement.
///
/// Deliberately holds no `Ref` and runs no detection of its own — exactly
/// Module 6's `PoseGestureClassifier`/`GestureRecognitionController`
/// split: this class is pure and directly testable, while the provider
/// below wires it to Module 5's existing pose stream via `ref.listen` (no
/// extra ML inference cost, same reasoning as gestures).
class TryOnSessionController extends StateNotifier<TryOnState> {
  TryOnSessionController() : super(const TryOnState());

  static const _anchorCalculator = BodyAnchorCalculator();
  static const _transformCalculator = ClothingTransformCalculator();

  /// The four layers a whole-outfit image visually replaces — selecting
  /// `outfit` while any of these is active (or vice versa) would draw
  /// two overlapping garments in the same place, so the two selection
  /// modes are kept mutually exclusive here rather than relying on the
  /// UI to prevent it.
  static const _outfitConflictLayers = {
    ClothingLayer.shirt,
    ClothingLayer.jacket,
    ClothingLayer.pant,
    ClothingLayer.shoes,
  };

  void selectItem(ClothingItem item) {
    final updated = Map<ClothingLayer, ClothingItem>.from(state.selectedItems);
    if (item.layer == ClothingLayer.outfit) {
      for (final layer in _outfitConflictLayers) {
        updated.remove(layer);
      }
    } else if (_outfitConflictLayers.contains(item.layer)) {
      updated.remove(ClothingLayer.outfit);
    }
    updated[item.layer] = item;
    state = state.copyWith(selectedItems: updated);
    _recomputeTransforms();
  }

  void removeLayer(ClothingLayer layer) {
    final items = Map<ClothingLayer, ClothingItem>.from(state.selectedItems)..remove(layer);
    final transforms = Map<ClothingLayer, LayerTransform>.from(state.transforms)..remove(layer);
    state = state.copyWith(selectedItems: items, transforms: transforms);
  }

  /// Real target for `GestureAction.resetTryOn` (both-hands-up) and
  /// `VoiceCommandType.reset` ("reset").
  void reset() {
    state = const TryOnState();
  }

  /// Called once per new pose frame (via the provider's `ref.listen`
  /// below). Recomputes anchor points and every selected layer's
  /// transform together so they stay visually in sync frame to frame.
  void onPoseUpdate(PoseAnalysis pose, FaceAnalysis? face) {
    final anchors = _anchorCalculator.calculate(pose);
    if (anchors == null) {
      // Keep the last known anchors/transforms rather than flicker to
      // nothing for a single bad frame — same reasoning as Module 5's
      // "no flicker" choice for face/pose results.
      return;
    }

    final transforms = <ClothingLayer, LayerTransform>{};
    for (final entry in state.selectedItems.entries) {
      final transform = _transformCalculator.calculate(
        entry.value.anchorConfig,
        anchors,
        face: face,
      );
      if (transform != null) transforms[entry.key] = transform;
    }

    state = state.copyWith(anchors: anchors, transforms: transforms);
  }

  void _recomputeTransforms() {
    final anchors = state.anchors;
    if (anchors == null) return;

    final transforms = <ClothingLayer, LayerTransform>{};
    for (final entry in state.selectedItems.entries) {
      final transform = _transformCalculator.calculate(entry.value.anchorConfig, anchors);
      if (transform != null) transforms[entry.key] = transform;
    }
    state = state.copyWith(transforms: transforms);
  }
}

final tryOnSessionControllerProvider =
    StateNotifierProvider.autoDispose<TryOnSessionController, TryOnState>((ref) {
  final controller = TryOnSessionController();

  ref.listen<VisionAnalysisState>(visionPipelineControllerProvider, (previous, next) {
    final pose = next.pose;
    final updatedAt = next.lastUpdated;
    if (pose == null || updatedAt == null) return;
    if (updatedAt == previous?.lastUpdated) return; // no new frame since last time
    controller.onPoseUpdate(pose, next.face);
  });

  return controller;
});
