/// Occasions a clothing item can be tagged suitable for, and that the
/// recommendation engine (Module 9) matches against. Lives in `tryon`
/// rather than `recommendation` deliberately: "which occasions does this
/// item suit" is a property of the clothing catalog itself, so this stays
/// a one-way dependency (recommendation depends on tryon, not the other
/// way around) — the same "later module depends on earlier module"
/// direction used throughout this build.
enum Occasion { interview, wedding, college, party, office, casual, formal, traditional }

extension OccasionMeta on Occasion {
  String get label => switch (this) {
        Occasion.interview => 'Interview',
        Occasion.wedding => 'Wedding',
        Occasion.college => 'College',
        Occasion.party => 'Party',
        Occasion.office => 'Office',
        Occasion.casual => 'Casual',
        Occasion.formal => 'Formal',
        Occasion.traditional => 'Traditional',
      };

  /// Matches a free-text keyword (e.g. from `VoiceCommandParser`'s
  /// extracted occasion string) to an `Occasion`, case-insensitively.
  /// Returns `null` for anything unrecognized (e.g. "brunch") — callers
  /// decide the fallback (this build defaults to `Occasion.casual`).
  static Occasion? fromKeyword(String keyword) {
    final normalized = keyword.toLowerCase().trim();
    for (final occasion in Occasion.values) {
      if (occasion.name == normalized || occasion.label.toLowerCase() == normalized) {
        return occasion;
      }
    }
    return null;
  }
}
