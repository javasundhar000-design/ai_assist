import 'dart:ui';

/// The result of positioning one clothing layer for the current frame:
/// where to center it, how big to draw it, and how much to rotate it —
/// everything `TryOnPainter` needs, all in image-pixel space (mapped to
/// screen space at paint time via `CoordinateTranslator`, the same helper
/// Module 5's overlays use).
class LayerTransform {
  const LayerTransform({
    required this.center,
    required this.width,
    required this.height,
    required this.rotationRadians,
  });

  final Offset center;
  final double width;
  final double height;
  final double rotationRadians;
}
