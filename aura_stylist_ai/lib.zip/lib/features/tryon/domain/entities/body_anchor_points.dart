import 'dart:ui';

/// The body anchor points from the spec's "VIRTUAL CLOTHING ENGINE"
/// section (Neck, Left Shoulder, Right Shoulder, Chest Center, Waist,
/// Hip), plus a few practical derived values every layer's transform
/// needs: `hipCenter` (the actual anchor for pants), `shoulderWidth`/
/// `hipWidth`/`torsoHeight` (scale references — there's no calibrated
/// real-world unit from a single 2D frame, so every clothing item is
/// sized *relative* to these), and `bodyRotationRadians` (shoulder-line
/// tilt, so clothing tilts with the body rather than staying axis-aligned
/// while the person leans).
///
/// `leftAnkle`/`rightAnkle` are optional extras beyond the spec's core
/// list — pose data has them, and shoe placement is meaningfully better
/// with them, but they're frequently out of frame in a typical phone
/// "smart mirror" setup (which usually only captures waist-up), so shoes
/// are the one layer that gracefully renders nothing rather than guessing.
class BodyAnchorPoints {
  const BodyAnchorPoints({
    required this.neck,
    required this.leftShoulder,
    required this.rightShoulder,
    required this.chestCenter,
    required this.waist,
    required this.leftHip,
    required this.rightHip,
    required this.hipCenter,
    required this.shoulderWidth,
    required this.hipWidth,
    required this.torsoHeight,
    required this.bodyRotationRadians,
    required this.imageSize,
    this.leftAnkle,
    this.rightAnkle,
  });

  final Offset neck;
  final Offset leftShoulder;
  final Offset rightShoulder;
  final Offset chestCenter;
  final Offset waist;
  final Offset leftHip;
  final Offset rightHip;
  final Offset hipCenter;

  final double shoulderWidth;
  final double hipWidth;
  final double torsoHeight;

  /// Roll angle of the shoulder line, in radians — used to rotate
  /// clothing to match the body's tilt (not full 3D pose; see the module
  /// README for why 2D-only is the deliberate choice here).
  final double bodyRotationRadians;

  /// The camera-frame size these points were computed against, needed to
  /// map them onto the preview widget (same role as `FaceAnalysis.
  /// imageSize`/`PoseAnalysis.imageSize` from Module 5).
  final Size imageSize;

  final Offset? leftAnkle;
  final Offset? rightAnkle;
}
