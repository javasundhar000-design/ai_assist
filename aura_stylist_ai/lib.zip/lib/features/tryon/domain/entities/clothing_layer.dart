/// The eight clothing layers from the spec's "MULTI-LAYER VIRTUAL TRY-ON"
/// section, plus `outfit` — a ninth, opt-in layer added for whole-outfit
/// images (a single photo covering shirt+jacket+pants+shoes together,
/// like a full-body product shot) instead of four independently-tracked
/// pieces. See `AnchorReference.fullBody`'s doc comment for the tracking
/// trade-off this makes.
enum ClothingLayer { hair, pant, shoes, outfit, shirt, jacket, accessories, hat, glasses }

extension ClothingLayerMeta on ClothingLayer {
  String get label => switch (this) {
        ClothingLayer.hair => 'Hair',
        ClothingLayer.pant => 'Pants',
        ClothingLayer.shirt => 'Shirt',
        ClothingLayer.jacket => 'Jacket',
        ClothingLayer.shoes => 'Shoes',
        ClothingLayer.accessories => 'Accessories',
        ClothingLayer.hat => 'Hat',
        ClothingLayer.glasses => 'Glasses',
        ClothingLayer.outfit => 'Full Outfit',
      };

  /// Rendering order — lower draws first (further back). Roughly follows
  /// physical layering: legwear and shoes render before the torso, torso
  /// layers before things worn on top of them, and head items last so a
  /// hat correctly covers hair rather than the other way around.
  /// `outfit` sits between shoes and shirt — it's meant to be worn
  /// *instead of* pant/shoes/shirt/jacket (see
  /// `TryOnSessionController.selectItem`), not layered with them, so its
  /// exact position barely matters in practice.
  int get zIndex => switch (this) {
        ClothingLayer.pant => 0,
        ClothingLayer.shoes => 1,
        ClothingLayer.outfit => 2,
        ClothingLayer.shirt => 3,
        ClothingLayer.jacket => 4,
        ClothingLayer.accessories => 5,
        ClothingLayer.hair => 6,
        ClothingLayer.hat => 7,
        ClothingLayer.glasses => 8,
      };
}
