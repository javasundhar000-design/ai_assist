/// A garment's cut/silhouette — used by Module 9's body-match scoring
/// against `BodyType`. Lives in `tryon` alongside `Occasion` for the same
/// reason: it's a property of the catalog item itself.
enum FitType { slim, regular, relaxed, structured }

extension FitTypeMeta on FitType {
  String get label => switch (this) {
        FitType.slim => 'Slim',
        FitType.regular => 'Regular',
        FitType.relaxed => 'Relaxed',
        FitType.structured => 'Structured',
      };
}
