import 'dart:ui';

import 'clothing_anchor_config.dart';
import 'clothing_layer.dart';
import 'fit_type.dart';
import 'occasion.dart';

/// One item in the clothing catalog.
///
/// `imagePath` is an asset path to a transparent-background garment
/// cutout (a PNG photographed/edited so the garment is isolated from its
/// background) — this is what actually renders on the body once set. If
/// it's null, `TryOnPainter` falls back to a flat-`color` procedural
/// silhouette instead, so existing demo items keep working with no
/// changes. See the module README for why real garment photography can't
/// be generated as source code — you supply the images, the app supplies
/// everything else: the layer system, the anchor configuration, and the
/// live tracking that keeps the image locked to the body as it moves.
///
/// `fit` and `suitableOccasions` (added in Module 9) are what the
/// recommendation engine matches against — a garment's cut affects how
/// well it suits a body type, and which occasions it's tagged for
/// determines whether it gets picked for e.g. "recommend interview
/// outfit".
class ClothingItem {
  const ClothingItem({
    required this.id,
    required this.name,
    required this.layer,
    required this.color,
    required this.anchorConfig,
    required this.fit,
    required this.suitableOccasions,
    this.imagePath,
  });

  final String id;
  final String name;
  final ClothingLayer layer;
  final Color color;
  final ClothingAnchorConfig anchorConfig;
  final FitType fit;
  final List<Occasion> suitableOccasions;

  /// Asset path to a real garment image, e.g. `'assets/clothing/shirt_navy.png'`.
  /// Must be a transparent PNG (or WebP) so only the garment itself
  /// shows — a rectangular photo with a background will render as a
  /// rectangle stuck to the body. Null means "no real image yet, use the
  /// `color` fallback silhouette".
  final String? imagePath;
}

