/// Which body region a clothing item's transform is computed relative to.
/// This is the data-driven piece that lets `ClothingTransformCalculator`
/// stay generic — new catalog items just need the right config, not new
/// positioning code.
enum AnchorReference {
  /// Shirts, jackets — spans from the neck down toward the chest/waist.
  neckToChest,

  /// Hats, hair — sits above the neck, roughly where a head would be.
  headTop,

  /// Glasses — centered at eye level. Uses Module 5's face landmarks
  /// (`FaceAnalysis.landmarks[leftEye]`/`[rightEye]`) when a face was
  /// detected this frame for much better accuracy than pose alone;
  /// falls back to a pose-only estimate otherwise.
  eyesLevel,

  /// Pants — spans from the hip downward.
  hipToBelow,

  /// Shoes — spans between the two ankles. Returns no transform if either
  /// ankle isn't visible (common in a waist-up "smart mirror" framing).
  ankles,

  /// Accessories (necklace/pendant) — small, centered at the chest.
  chestPendant,

  /// Whole-outfit images (see `ClothingLayer.outfit`) — spans the full
  /// neck-to-ankle height of the body as one rigid block, rather than
  /// tracking shoulders/hips/ankles independently like the per-garment
  /// references above. This is a deliberate accuracy trade-off: a single
  /// baked-pose photo (arms/legs already fixed in one position) can't
  /// bend at the elbow or knee as the person moves, so it will look
  /// "pasted on" during motion in a way the per-layer system doesn't.
  /// It's the right trade for a quick outfit preview; for anything more,
  /// per-layer garment images are the better fit.
  fullBody,
}

/// Per-item configuration describing how a `ClothingItem` attaches to and
/// scales from its `AnchorReference` point. All of this is tunable data,
/// not code — see `demo_clothing_catalog.dart` for real values.
class ClothingAnchorConfig {
  const ClothingAnchorConfig({
    required this.reference,
    this.verticalOffsetFraction = 0.0,
    this.widthScale = 1.0,
    this.aspectRatio = 1.0,
  });

  final AnchorReference reference;

  /// How far to shift along the body's local vertical axis, as a
  /// multiple of `BodyAnchorPoints.torsoHeight`, starting from the
  /// reference origin. Not used by `eyesLevel`/`ankles`/`chestPendant`,
  /// which have their own fixed small-scale positioning.
  final double verticalOffsetFraction;

  /// Multiplier applied to the reference width (e.g. shoulder width for
  /// a shirt, inter-eye distance for glasses) to get the rendered width.
  final double widthScale;

  /// Rendered width / rendered height.
  final double aspectRatio;
}
