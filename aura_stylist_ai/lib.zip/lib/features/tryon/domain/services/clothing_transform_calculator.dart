import 'dart:ui';

import '../../../vision/domain/entities/face_analysis.dart';
import '../entities/body_anchor_points.dart';
import '../entities/clothing_anchor_config.dart';
import '../entities/layer_transform.dart';

/// Computes where/how big/how rotated to draw one clothing layer for the
/// current frame — the spec's "VIRTUAL CLOTHING ENGINE": "Automatically:
/// Resize, Rotate, Scale, Translate, Align... Follow shoulders... Follow
/// body movement."
///
/// Every case is driven entirely by [ClothingAnchorConfig] data plus the
/// current [BodyAnchorPoints] — no per-item special-casing, so adding a
/// new catalog item never requires touching this class. Pure Dart, fully
/// unit-testable with synthetic anchor points.
class ClothingTransformCalculator {
  const ClothingTransformCalculator();

  LayerTransform? calculate(
    ClothingAnchorConfig config,
    BodyAnchorPoints anchors, {
    FaceAnalysis? face,
  }) {
    switch (config.reference) {
      case AnchorReference.neckToChest:
        return _torsoTransform(
          origin: anchors.neck,
          verticalStep: anchors.chestCenter - anchors.neck,
          referenceWidth: anchors.shoulderWidth,
          config: config,
          anchors: anchors,
        );

      case AnchorReference.hipToBelow:
        return _torsoTransform(
          origin: anchors.hipCenter,
          verticalStep: anchors.hipCenter - anchors.waist,
          referenceWidth: anchors.hipWidth,
          config: config,
          anchors: anchors,
        );

      case AnchorReference.headTop:
        final upward = anchors.neck - anchors.chestCenter; // points away from torso ("up")
        final upwardLength = upward.distance == 0 ? 1.0 : upward.distance;
        final unitUp = upward / upwardLength;
        final headTop = anchors.neck + unitUp * anchors.shoulderWidth * 0.55;
        return _torsoTransform(
          origin: headTop,
          verticalStep: unitUp * -anchors.shoulderWidth * 0.3,
          referenceWidth: anchors.shoulderWidth * 0.6,
          config: config,
          anchors: anchors,
        );

      case AnchorReference.eyesLevel:
        final leftEye = face?.landmarks[FaceLandmarkKind.leftEye];
        final rightEye = face?.landmarks[FaceLandmarkKind.rightEye];
        final Offset origin;
        final double referenceWidth;
        if (leftEye != null && rightEye != null) {
          origin = Offset((leftEye.dx + rightEye.dx) / 2, (leftEye.dy + rightEye.dy) / 2);
          referenceWidth = (rightEye - leftEye).distance * 2.4;
        } else {
          // No face detected this frame — fall back to a pose-only estimate
          // rather than rendering nothing.
          origin = anchors.neck;
          referenceWidth = anchors.shoulderWidth * 0.5;
        }
        final width = referenceWidth * config.widthScale;
        return LayerTransform(
          center: origin,
          width: width,
          height: width / config.aspectRatio,
          rotationRadians: anchors.bodyRotationRadians,
        );

      case AnchorReference.ankles:
        final leftAnkle = anchors.leftAnkle;
        final rightAnkle = anchors.rightAnkle;
        if (leftAnkle == null || rightAnkle == null) return null;
        final center = Offset(
          (leftAnkle.dx + rightAnkle.dx) / 2,
          (leftAnkle.dy + rightAnkle.dy) / 2,
        );
        final width =
            ((rightAnkle - leftAnkle).distance + anchors.hipWidth * 0.3) * config.widthScale;
        return LayerTransform(
          center: center,
          width: width,
          height: width / config.aspectRatio,
          rotationRadians: anchors.bodyRotationRadians,
        );

      case AnchorReference.chestPendant:
        final width = anchors.shoulderWidth * 0.25 * config.widthScale;
        return LayerTransform(
          center: anchors.chestCenter,
          width: width,
          height: width / config.aspectRatio,
          rotationRadians: anchors.bodyRotationRadians,
        );

      case AnchorReference.fullBody:
        return _fullBodyTransform(config: config, anchors: anchors);
    }
  }

  /// Spans neck-to-ankle as a single block. Uses real ankle landmarks
  /// when they're in frame; otherwise estimates leg length as roughly
  /// one torso-height below the hip (a typical human proportion) rather
  /// than rendering nothing just because a waist-up framing cut the feet
  /// off — same reasoning as every other layer's "degrade gracefully"
  /// choice, just with an estimate instead of a hard cutoff, since a
  /// whole-outfit image genuinely needs *some* leg length to size itself
  /// against.
  LayerTransform _fullBodyTransform({
    required ClothingAnchorConfig config,
    required BodyAnchorPoints anchors,
  }) {
    final top = anchors.neck;
    final Offset bottom;
    final leftAnkle = anchors.leftAnkle;
    final rightAnkle = anchors.rightAnkle;
    if (leftAnkle != null && rightAnkle != null) {
      bottom = Offset((leftAnkle.dx + rightAnkle.dx) / 2, (leftAnkle.dy + rightAnkle.dy) / 2);
    } else {
      final down = anchors.hipCenter - anchors.neck;
      final downLength = down.distance == 0 ? 1.0 : down.distance;
      final unitDown = down / downLength;
      bottom = anchors.hipCenter + unitDown * anchors.torsoHeight * 1.05;
    }
    final height = (bottom - top).distance;
    // Unlike the other references (width first, height derived), height
    // here comes from real body geometry, so aspectRatio derives width
    // from it instead — keeps a whole-outfit image's own proportions
    // intact rather than stretching it to match shoulder width.
    final width = height * config.aspectRatio * config.widthScale;
    final center = Offset((top.dx + bottom.dx) / 2, (top.dy + bottom.dy) / 2);
    return LayerTransform(
      center: center,
      width: width,
      height: height,
      rotationRadians: anchors.bodyRotationRadians,
    );
  }

  /// Shared math for the "follows the torso axis" layers (shirt, jacket,
  /// pants, hat/hair): starts at [origin], steps further along
  /// [verticalStep] scaled by the config's offset fraction, and sizes the
  /// shape from [referenceWidth].
  LayerTransform _torsoTransform({
    required Offset origin,
    required Offset verticalStep,
    required double referenceWidth,
    required ClothingAnchorConfig config,
    required BodyAnchorPoints anchors,
  }) {
    final width = referenceWidth * config.widthScale;
    final height = width / config.aspectRatio;
    final center = origin + verticalStep * config.verticalOffsetFraction;
    return LayerTransform(
      center: center,
      width: width,
      height: height,
      rotationRadians: anchors.bodyRotationRadians,
    );
  }
}
