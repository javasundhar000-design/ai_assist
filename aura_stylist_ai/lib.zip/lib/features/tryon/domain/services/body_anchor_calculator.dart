import 'dart:math' as math;
import 'dart:ui';

import '../../../vision/domain/entities/pose_analysis.dart';
import '../entities/body_anchor_points.dart';

/// Derives `BodyAnchorPoints` from a `PoseAnalysis` frame.
///
/// ML Kit's pose model has no direct "neck", "chest", or "waist"
/// landmarks — only joints (shoulders, hips, etc). These are computed as
/// documented approximations from what pose detection actually gives us:
///
///  - **Neck**: extrapolated a short distance from the shoulder midpoint
///    toward the nose (when visible), or nudged slightly above the
///    shoulder line otherwise.
///  - **Chest Center**: partway from the shoulder midpoint toward the hip
///    midpoint.
///  - **Waist**: most of the way from the shoulder midpoint toward the
///    hip midpoint (waist sits close to, but slightly above, the hips).
///  - **Body rotation**: the shoulder line's tilt angle — used to rotate
///    clothing so it follows the body leaning, not just moving.
///
/// Pure Dart, no plugin dependencies beyond the already-mapped
/// `PoseAnalysis` — fully unit-testable.
class BodyAnchorCalculator {
  const BodyAnchorCalculator();

  static const _minLikelihood = 0.5;

  BodyAnchorPoints? calculate(PoseAnalysis pose) {
    final leftShoulderPoint = pose[PoseLandmarkKind.leftShoulder];
    final rightShoulderPoint = pose[PoseLandmarkKind.rightShoulder];
    final leftHipPoint = pose[PoseLandmarkKind.leftHip];
    final rightHipPoint = pose[PoseLandmarkKind.rightHip];

    final required = [leftShoulderPoint, rightShoulderPoint, leftHipPoint, rightHipPoint];
    if (required.any((p) => p == null || p.likelihood < _minLikelihood)) {
      return null;
    }

    final leftShoulder = leftShoulderPoint!.offset;
    final rightShoulder = rightShoulderPoint!.offset;
    final leftHip = leftHipPoint!.offset;
    final rightHip = rightHipPoint!.offset;

    final shoulderMid = Offset(
      (leftShoulder.dx + rightShoulder.dx) / 2,
      (leftShoulder.dy + rightShoulder.dy) / 2,
    );
    final hipMid = Offset(
      (leftHip.dx + rightHip.dx) / 2,
      (leftHip.dy + rightHip.dy) / 2,
    );

    final torsoHeight = (hipMid.dy - shoulderMid.dy).abs();

    final nosePoint = pose[PoseLandmarkKind.nose];
    final Offset neck;
    if (nosePoint != null && nosePoint.likelihood >= _minLikelihood) {
      final nose = nosePoint.offset;
      neck = Offset(
        shoulderMid.dx + (nose.dx - shoulderMid.dx) * 0.35,
        shoulderMid.dy + (nose.dy - shoulderMid.dy) * 0.35,
      );
    } else {
      neck = Offset(shoulderMid.dx, shoulderMid.dy - torsoHeight * 0.08);
    }

    final chestCenter = Offset(
      shoulderMid.dx + (hipMid.dx - shoulderMid.dx) * 0.22,
      shoulderMid.dy + (hipMid.dy - shoulderMid.dy) * 0.22,
    );

    final waist = Offset(
      shoulderMid.dx + (hipMid.dx - shoulderMid.dx) * 0.85,
      shoulderMid.dy + (hipMid.dy - shoulderMid.dy) * 0.85,
    );

    final shoulderWidth = (rightShoulder - leftShoulder).distance;
    final hipWidth = (rightHip - leftHip).distance;
    final bodyRotationRadians = math.atan2(
      rightShoulder.dy - leftShoulder.dy,
      rightShoulder.dx - leftShoulder.dx,
    );

    final leftAnklePoint = pose[PoseLandmarkKind.leftAnkle];
    final rightAnklePoint = pose[PoseLandmarkKind.rightAnkle];
    final leftAnkle = (leftAnklePoint != null && leftAnklePoint.likelihood >= _minLikelihood)
        ? leftAnklePoint.offset
        : null;
    final rightAnkle = (rightAnklePoint != null && rightAnklePoint.likelihood >= _minLikelihood)
        ? rightAnklePoint.offset
        : null;

    return BodyAnchorPoints(
      neck: neck,
      leftShoulder: leftShoulder,
      rightShoulder: rightShoulder,
      chestCenter: chestCenter,
      waist: waist,
      leftHip: leftHip,
      rightHip: rightHip,
      hipCenter: hipMid,
      shoulderWidth: shoulderWidth,
      hipWidth: hipWidth,
      torsoHeight: torsoHeight,
      bodyRotationRadians: bodyRotationRadians,
      imageSize: pose.imageSize,
      leftAnkle: leftAnkle,
      rightAnkle: rightAnkle,
    );
  }
}
