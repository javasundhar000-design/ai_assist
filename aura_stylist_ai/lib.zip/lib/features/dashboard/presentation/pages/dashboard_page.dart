import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/l10n/app_localizations.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../core/theme/theme_provider.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../profile/presentation/providers/profile_providers.dart';
import '../../../profile/presentation/widgets/profile_avatar.dart';
import '../widgets/dashboard_nav_card.dart';

/// The real Module 3 dashboard: home shell + navigation + a profile-aware
/// header backed by Realtime Database.
///
/// On first entry after signup, `_ensureProfile()` writes the user's
/// default profile document if one doesn't exist yet (see
/// `ProfileRepository.ensureProfileExists`) — after that,
/// `currentUserProfileProvider` keeps this screen in sync with RTDB in
/// real time, from any device.
class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _ensureProfile());
  }

  Future<void> _ensureProfile() async {
    final user = ref.read(authRepositoryProvider).currentUser;
    if (user == null) return;
    await ref.read(profileRepositoryProvider).ensureProfileExists(
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
        );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final authUser = ref.watch(authStateChangesProvider).valueOrNull;
    final profileAsync = ref.watch(currentUserProfileProvider);
    final profile = profileAsync.valueOrNull;

    final displayName = profile?.name ?? authUser?.label ?? 'Stylist';

    return Scaffold(
      appBar: AppBar(
        title: const Text('AURA STYLIST AI'),
        actions: [
          IconButton(
            tooltip: 'Toggle theme',
            icon: const Icon(Icons.brightness_6_outlined),
            onPressed: () => ref.read(themeModeProvider.notifier).toggle(),
          ),
          Padding(
            padding: const EdgeInsets.only(right: AppSpacing.md),
            child: ProfileAvatar(
              photoUrl: profile?.photoUrl,
              label: displayName,
              radius: 16,
              onTap: () => context.push(AppRoutes.profile),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _ensureProfile,
          child: ListView(
            padding: const EdgeInsets.all(AppSpacing.lg),
            children: [
              Text(
                'Welcome back, $displayName!',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                authUser?.isGuest == true
                    ? l10n.t(AppL10nKeys.dashboardSubtitleGuest)
                    : l10n.t(AppL10nKeys.dashboardSubtitleReady),
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context)
                          .colorScheme
                          .onSurface
                          .withOpacity(0.65),
                    ),
              ),
              const SizedBox(height: AppSpacing.xl),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: AppSpacing.md,
                crossAxisSpacing: AppSpacing.md,
                childAspectRatio: 1.1,
                children: [
                  DashboardNavCard(
                    icon: Icons.camera_front_rounded,
                    label: 'Smart Mirror',
                    badge: 'M5 AI',
                    onTap: () => context.push(AppRoutes.smartMirror),
                  ),
                  DashboardNavCard(
                    icon: Icons.auto_awesome_rounded,
                    label: l10n.t(AppL10nKeys.navAiRecommendations),
                    badge: 'M9',
                    onTap: () => context.push(AppRoutes.smartMirror),
                  ),
                  DashboardNavCard(
                    icon: Icons.checkroom_rounded,
                    label: l10n.t(AppL10nKeys.navWardrobe),
                    badge: 'M10',
                    onTap: () => context.push(AppRoutes.wardrobe),
                  ),
                  DashboardNavCard(
                    icon: Icons.favorite_border_rounded,
                    label: l10n.t(AppL10nKeys.navFavorites),
                    badge: 'M10',
                    onTap: () => context.push(AppRoutes.wardrobe),
                  ),
                  DashboardNavCard(
                    icon: Icons.history_rounded,
                    label: l10n.t(AppL10nKeys.navOutfitHistory),
                    badge: 'M10',
                    onTap: () => context.push(AppRoutes.wardrobe),
                  ),
                  DashboardNavCard(
                    icon: Icons.settings_outlined,
                    label: l10n.t(AppL10nKeys.navSettings),
                    badge: 'M11',
                    onTap: () => context.push(AppRoutes.settings),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.xl),
              OutlinedButton.icon(
                onPressed: () => ref.read(authRepositoryProvider).signOut(),
                icon: const Icon(Icons.logout_rounded),
                label: Text(l10n.t(AppL10nKeys.logout)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
