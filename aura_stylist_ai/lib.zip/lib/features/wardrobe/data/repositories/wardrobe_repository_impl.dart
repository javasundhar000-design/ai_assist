import 'dart:async';

import 'package:firebase_core/firebase_core.dart' show FirebaseException;

import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/saved_outfit.dart';
import '../../domain/repositories/wardrobe_repository.dart';
import '../datasources/wardrobe_local_datasource.dart';
import '../datasources/wardrobe_realtime_datasource.dart';

/// Local-first, Firebase-mirrored wardrobe storage.
///
/// Every write goes to `WardrobeLocalDataSource` first — so `watchOutfits`
/// emits immediately, `saveOutfit`/`toggleFavorite`/`deleteOutfit` all
/// succeed instantly even with no network, and the Smart Mirror's "Save"
/// gesture/voice command never has to wait on a round trip. The Firebase
/// write happens right after, best-effort: if it fails (offline, RTDB
/// error), the local copy is still correct and the next successful write
/// will carry it up — same reasoning as `ProfileRepositoryImpl` not
/// existing for offline profile edits, applied one step further here
/// since outfits are saved far more often than profile fields.
///
/// One thing this deliberately does *not* do: pull down another device's
/// changes into the local cache automatically. `watchOutfits` streams the
/// local cache, not a live RTDB listener — merging concurrent edits from
/// two devices well needs conflict resolution this build doesn't attempt.
/// `refreshFromRemote` (called once, on `WardrobeController` startup) is
/// the one point where remote data is pulled down, overwriting the local
/// cache — good enough for "I saved a look on my phone, now I open the
/// app on my tablet," not for simultaneous multi-device editing.
class WardrobeRepositoryImpl implements WardrobeRepository {
  WardrobeRepositoryImpl(this._local, this._remote);

  final WardrobeLocalDataSource _local;
  final WardrobeRealtimeDataSource _remote;

  final _controllers = <String, StreamController<List<SavedOutfit>>>{};

  StreamController<List<SavedOutfit>> _controllerFor(String uid) {
    return _controllers.putIfAbsent(uid, () {
      final controller = StreamController<List<SavedOutfit>>.broadcast(
        onListen: () {},
      );
      // Seed the first listener with whatever's already cached.
      scheduleMicrotask(() {
        if (controller.hasListener) controller.add(_local.readAll(uid));
      });
      return controller;
    });
  }

  void _emit(String uid) {
    _controllerFor(uid).add(_local.readAll(uid));
  }

  @override
  Stream<List<SavedOutfit>> watchOutfits(String uid) => _controllerFor(uid).stream;

  /// Pulls the Firebase copy down into the local cache once. Best-effort:
  /// silently keeps the local cache as-is on failure (offline, brand-new
  /// account with nothing remote yet) rather than surfacing an error for
  /// what's meant to be a background refresh.
  @override
  Future<void> refreshFromRemote(String uid) async {
    try {
      final raw = await _remote.getAllOnce(uid);
      if (raw == null) return;

      final remoteOutfits = raw.entries
          .map((entry) => SavedOutfit.fromMap(entry.key as String, entry.value as Map<Object?, Object?>))
          .toList();

      // Merge by id, remote wins on conflict (simplest reasonable rule
      // for the "second device catches up" case this method exists for).
      final merged = {for (final o in _local.readAll(uid)) o.id: o};
      for (final outfit in remoteOutfits) {
        merged[outfit.id] = outfit;
      }
      await _local.writeAll(uid, merged.values.toList());
      _emit(uid);
    } catch (_) {
      // Offline or no remote data yet — local cache is still valid.
    }
  }

  @override
  Future<Result<SavedOutfit>> saveOutfit(String uid, SavedOutfit outfit) async {
    final current = _local.readAll(uid);
    final updated = [
      ...current.where((o) => o.id != outfit.id),
      outfit,
    ];
    await _local.writeAll(uid, updated);
    _emit(uid);

    try {
      await _remote.setOutfit(uid, outfit.id, outfit.toMap());
    } on FirebaseException catch (_) {
      // Local save already succeeded — this is best-effort, see class doc.
    } catch (_) {}

    return Success(outfit);
  }

  @override
  Future<Result<SavedOutfit>> toggleFavorite(String uid, String outfitId) async {
    final current = _local.readAll(uid);
    final index = current.indexWhere((o) => o.id == outfitId);
    if (index == -1) {
      return const Err(UnknownFailure('That outfit no longer exists.'));
    }

    final toggled = current[index].copyWith(isFavorite: !current[index].isFavorite);
    final updated = [...current]..[index] = toggled;
    await _local.writeAll(uid, updated);
    _emit(uid);

    try {
      await _remote.setOutfit(uid, toggled.id, toggled.toMap());
    } catch (_) {}

    return Success(toggled);
  }

  @override
  Future<Result<void>> deleteOutfit(String uid, String outfitId) async {
    final current = _local.readAll(uid);
    final updated = current.where((o) => o.id != outfitId).toList();
    await _local.writeAll(uid, updated);
    _emit(uid);

    try {
      await _remote.deleteOutfit(uid, outfitId);
    } catch (_) {}

    return const Success(null);
  }
}
