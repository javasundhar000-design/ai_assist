import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../domain/entities/saved_outfit.dart';

/// Local cache of one user's saved outfits, keyed by uid, stored as a
/// single JSON-encoded list under `shared_preferences`.
///
/// Deliberate simplification vs. a real embedded database (`sqflite`/
/// `hive`, as the pubspec's Module 10 roadmap note originally floated):
/// `shared_preferences` is already a dependency (Module 2), a saved-outfit
/// collection is small (a handful to a few dozen entries, not thousands of
/// rows), and reading/writing "the whole list" on every change is simpler
/// and just as fast at this scale. If the wardrobe ever needs to hold
/// thousands of items with complex querying, that's the point to
/// introduce a real embedded DB — not before.
///
/// Keyed by uid (Firebase anonymous/guest sessions have a real uid too,
/// same as `ProfileRepository`), so this also doubles as the offline
/// cache read on every app start before the Firebase mirror catches up —
/// see `WardrobeRepositoryImpl`'s doc comment.
class WardrobeLocalDataSource {
  WardrobeLocalDataSource(this._prefs);

  final SharedPreferences _prefs;

  String _key(String uid) => 'wardrobe_outfits_$uid';

  List<SavedOutfit> readAll(String uid) {
    final raw = _prefs.getString(_key(uid));
    if (raw == null || raw.isEmpty) return const [];

    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map((entry) {
            final map = entry as Map<String, dynamic>;
            final id = map['id'] as String;
            return SavedOutfit.fromMap(id, map);
          })
          .toList();
    } catch (_) {
      // Corrupt/older-shape cache entry — treat as empty rather than crash.
      return const [];
    }
  }

  Future<void> writeAll(String uid, List<SavedOutfit> outfits) {
    final encoded = jsonEncode(
      outfits.map((o) => {'id': o.id, ...o.toMap()}).toList(),
    );
    return _prefs.setString(_key(uid), encoded);
  }
}
