import 'package:firebase_database/firebase_database.dart';

/// Raw Realtime Database access for `users/{uid}/wardrobe`. Kept "dumb" —
/// no domain types, just maps in/out — matching `ProfileRealtimeDataSource`'s
/// pattern from Module 3.
class WardrobeRealtimeDataSource {
  WardrobeRealtimeDataSource(this._db);

  final FirebaseDatabase _db;

  DatabaseReference _wardrobeRef(String uid) => _db.ref('users/$uid/wardrobe');

  Future<void> setOutfit(String uid, String outfitId, Map<String, dynamic> data) {
    return _wardrobeRef(uid).child(outfitId).set(data);
  }

  Future<void> deleteOutfit(String uid, String outfitId) {
    return _wardrobeRef(uid).child(outfitId).remove();
  }

  Future<Map<Object?, Object?>?> getAllOnce(String uid) async {
    final snapshot = await _wardrobeRef(uid).get();
    if (!snapshot.exists || snapshot.value == null) return null;
    return snapshot.value as Map<Object?, Object?>;
  }
}
