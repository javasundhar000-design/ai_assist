import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../core/l10n/app_localizations.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../../tryon/presentation/providers/clothing_catalog_provider.dart';
import '../../../tryon/presentation/providers/try_on_session_controller.dart';
import '../../domain/entities/saved_outfit.dart';
import '../../domain/entities/wardrobe_sort.dart';
import '../providers/wardrobe_controller.dart';
import '../widgets/empty_wardrobe_state.dart';
import '../widgets/outfit_card.dart';

/// The real Module 10 screen: Wardrobe (all saved outfits, searchable and
/// filterable), Favorites, and History — three views over the same
/// `WardrobeController` collection (see its class doc comment).
class WardrobePage extends ConsumerWidget {
  const WardrobePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final user = ref.watch(authStateChangesProvider).valueOrNull;

    if (user == null) {
      // Router guards make this unreachable in practice (signed-out users
      // are redirected to /login before this route can build), but a
      // direct guard keeps this page safe to construct in isolation too
      // (e.g. from a test) without a null uid.
      return const Scaffold(body: Center(child: Text('Sign in to view your wardrobe.')));
    }

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(l10n.t(AppL10nKeys.wardrobeTitle)),
          bottom: TabBar(tabs: [
            Tab(text: l10n.t(AppL10nKeys.wardrobeTabAll)),
            Tab(text: l10n.t(AppL10nKeys.wardrobeTabFavorites)),
            Tab(text: l10n.t(AppL10nKeys.wardrobeTabHistory)),
          ]),
        ),
        body: TabBarView(
          children: [
            _AllOutfitsTab(uid: user.uid),
            _FavoritesTab(uid: user.uid),
            _HistoryTab(uid: user.uid),
          ],
        ),
      ),
    );
  }
}

class _AllOutfitsTab extends ConsumerWidget {
  const _AllOutfitsTab({required this.uid});

  final String uid;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final wardrobeState = ref.watch(wardrobeControllerProvider(uid));
    final notifier = ref.read(wardrobeControllerProvider(uid).notifier);
    final catalog = ref.watch(clothingCatalogProvider);
    final visible = wardrobeState.visibleOutfits();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.md,
            AppSpacing.sm,
            AppSpacing.md,
            AppSpacing.sm,
          ),
          child: Column(
            children: [
              TextField(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search_rounded),
                  hintText: l10n.t(AppL10nKeys.wardrobeSearchHint),
                  border: const OutlineInputBorder(),
                  isDense: true,
                ),
                onChanged: notifier.setSearchQuery,
              ),
              const SizedBox(height: AppSpacing.sm),
              Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<Occasion?>(
                      value: wardrobeState.occasionFilter,
                      isExpanded: true,
                      decoration: InputDecoration(
                        isDense: true,
                        labelText: l10n.t(AppL10nKeys.wardrobeOccasionLabel),
                        border: const OutlineInputBorder(),
                      ),
                      items: [
                        DropdownMenuItem(
                          value: null,
                          child: Text(l10n.t(AppL10nKeys.wardrobeOccasionAll)),
                        ),
                        for (final occasion in Occasion.values)
                          DropdownMenuItem(value: occasion, child: Text(occasion.label)),
                      ],
                      onChanged: notifier.setOccasionFilter,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: DropdownButtonFormField<WardrobeSort>(
                      value: wardrobeState.sort,
                      isExpanded: true,
                      decoration: InputDecoration(
                        isDense: true,
                        labelText: l10n.t(AppL10nKeys.wardrobeSortLabel),
                        border: const OutlineInputBorder(),
                      ),
                      items: [
                        for (final sort in WardrobeSort.values)
                          DropdownMenuItem(value: sort, child: Text(sort.label)),
                      ],
                      onChanged: (sort) {
                        if (sort != null) notifier.setSort(sort);
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: visible.isEmpty
              ? EmptyWardrobeState(message: l10n.t(AppL10nKeys.wardrobeEmptyAll))
              : GridView.builder(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: AppSpacing.sm,
                    crossAxisSpacing: AppSpacing.sm,
                    childAspectRatio: 0.85,
                  ),
                  itemCount: visible.length,
                  itemBuilder: (context, index) {
                    final outfit = visible[index];
                    return OutfitCard(
                      outfit: outfit,
                      resolvedItems: notifier.resolveItems(outfit, catalog),
                      onTap: () => _showOutfitDetails(context, ref, outfit, catalog, uid),
                      onToggleFavorite: () => notifier.toggleFavorite(outfit.id),
                      onDelete: () => notifier.deleteOutfit(outfit.id),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _FavoritesTab extends ConsumerWidget {
  const _FavoritesTab({required this.uid});

  final String uid;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final wardrobeState = ref.watch(wardrobeControllerProvider(uid));
    final notifier = ref.read(wardrobeControllerProvider(uid).notifier);
    final catalog = ref.watch(clothingCatalogProvider);
    final favorites = wardrobeState.favorites;

    if (favorites.isEmpty) {
      return EmptyWardrobeState(message: l10n.t(AppL10nKeys.wardrobeEmptyFavorites));
    }

    return GridView.builder(
      padding: const EdgeInsets.all(AppSpacing.md),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: AppSpacing.sm,
        crossAxisSpacing: AppSpacing.sm,
        childAspectRatio: 0.85,
      ),
      itemCount: favorites.length,
      itemBuilder: (context, index) {
        final outfit = favorites[index];
        return OutfitCard(
          outfit: outfit,
          resolvedItems: notifier.resolveItems(outfit, catalog),
          onTap: () => _showOutfitDetails(context, ref, outfit, catalog, uid),
          onToggleFavorite: () => notifier.toggleFavorite(outfit.id),
          onDelete: () => notifier.deleteOutfit(outfit.id),
        );
      },
    );
  }
}

/// Read-only chronological log ("History") — always newest-first,
/// regardless of the All tab's sort setting, since a history log stops
/// meaning much once it's reorderable.
class _HistoryTab extends ConsumerWidget {
  const _HistoryTab({required this.uid});

  final String uid;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final wardrobeState = ref.watch(wardrobeControllerProvider(uid));
    final catalog = ref.watch(clothingCatalogProvider);
    final notifier = ref.read(wardrobeControllerProvider(uid).notifier);

    final history = [...wardrobeState.outfits]
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    if (history.isEmpty) {
      return EmptyWardrobeState(message: l10n.t(AppL10nKeys.wardrobeEmptyHistory));
    }

    final dateFormat = DateFormat('MMM d, yyyy · h:mm a');

    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.md),
      itemCount: history.length,
      separatorBuilder: (context, index) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final outfit = history[index];
        final resolved = notifier.resolveItems(outfit, catalog);
        return ListTile(
          leading: SizedBox(
            width: 40,
            height: 40,
            child: Stack(
              children: [
                for (final item in resolved.values.take(3))
                  Positioned(
                    left: resolved.values.toList().indexOf(item) * 8.0,
                    child: CircleAvatar(radius: 12, backgroundColor: item.color),
                  ),
              ],
            ),
          ),
          title: Text(outfit.name),
          subtitle: Text(dateFormat.format(outfit.createdAt)),
          trailing: outfit.fashionScore != null ? Text('${outfit.fashionScore}') : null,
          onTap: () => _showOutfitDetails(context, ref, outfit, catalog, uid),
        );
      },
    );
  }
}

void _showOutfitDetails(
  BuildContext context,
  WidgetRef ref,
  SavedOutfit outfit,
  List<ClothingItem> catalog,
  String uid,
) {
  final notifier = ref.read(wardrobeControllerProvider(uid).notifier);
  final resolved = notifier.resolveItems(outfit, catalog);

  showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        AppSpacing.sm,
        AppSpacing.lg,
        AppSpacing.xl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(outfit.name, style: Theme.of(sheetContext).textTheme.titleLarge),
          const SizedBox(height: AppSpacing.sm),
          Wrap(
            spacing: AppSpacing.sm,
            children: [
              for (final item in resolved.values)
                Chip(
                  avatar: CircleAvatar(backgroundColor: item.color),
                  label: Text(item.name),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          FilledButton.icon(
            icon: const Icon(Icons.checkroom_rounded),
            label: Text(AppLocalizations.of(sheetContext).t(AppL10nKeys.wearThisButton)),
            onPressed: () {
              final tryOnNotifier = ref.read(tryOnSessionControllerProvider.notifier);
              for (final item in resolved.values) {
                tryOnNotifier.selectItem(item);
              }
              Navigator.of(sheetContext).pop();
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    ),
  );
}
