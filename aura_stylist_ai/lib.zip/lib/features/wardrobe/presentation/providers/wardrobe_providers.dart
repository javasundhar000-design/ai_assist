import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../profile/presentation/providers/profile_providers.dart';
import '../../data/datasources/wardrobe_local_datasource.dart';
import '../../data/datasources/wardrobe_realtime_datasource.dart';
import '../../data/repositories/wardrobe_repository_impl.dart';
import '../../domain/repositories/wardrobe_repository.dart';

final wardrobeLocalDataSourceProvider = Provider<WardrobeLocalDataSource>((ref) {
  return WardrobeLocalDataSource(ref.watch(sharedPreferencesProvider));
});

final wardrobeRealtimeDataSourceProvider = Provider<WardrobeRealtimeDataSource>((ref) {
  return WardrobeRealtimeDataSource(ref.watch(firebaseDatabaseProvider));
});

/// Typed as the abstract `WardrobeRepository` so tests can override this
/// provider with `FakeWardrobeRepository`.
final wardrobeRepositoryProvider = Provider<WardrobeRepository>((ref) {
  return WardrobeRepositoryImpl(
    ref.watch(wardrobeLocalDataSourceProvider),
    ref.watch(wardrobeRealtimeDataSourceProvider),
  );
});
