import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/clothing_layer.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../domain/entities/saved_outfit.dart';
import '../../domain/entities/wardrobe_sort.dart';
import '../../domain/repositories/wardrobe_repository.dart';
import 'wardrobe_providers.dart';

class WardrobeState {
  const WardrobeState({
    this.outfits = const [],
    this.sort = WardrobeSort.newestFirst,
    this.occasionFilter,
    this.searchQuery = '',
    this.browseIndex = 0,
  });

  final List<SavedOutfit> outfits;
  final WardrobeSort sort;
  final Occasion? occasionFilter;
  final String searchQuery;

  /// Index into `visibleOutfits` (sorted+filtered) that gesture/voice
  /// "next"/"previous" is currently on — real target for
  /// `GestureAction.nextOutfit`/`previousOutfit` and
  /// `VoiceCommandType.next`/`previous` (see `SmartCameraPage`).
  final int browseIndex;

  List<SavedOutfit> get favorites => outfits.where((o) => o.isFavorite).toList();

  /// Sorted + filtered view — what `WardrobePage`'s "All" tab and the
  /// gesture/voice browse cycle both use, so "next" always means "next
  /// visible outfit," not "next outfit in arbitrary storage order."
  List<SavedOutfit> visibleOutfits() {
    var list = outfits.where((o) {
      if (occasionFilter != null && o.occasion != occasionFilter) return false;
      if (searchQuery.trim().isEmpty) return true;
      return o.name.toLowerCase().contains(searchQuery.trim().toLowerCase());
    }).toList();

    list.sort((a, b) => switch (sort) {
          WardrobeSort.newestFirst => b.createdAt.compareTo(a.createdAt),
          WardrobeSort.oldestFirst => a.createdAt.compareTo(b.createdAt),
          WardrobeSort.highestScore =>
            (b.fashionScore ?? -1).compareTo(a.fashionScore ?? -1),
        });
    return list;
  }

  WardrobeState copyWith({
    List<SavedOutfit>? outfits,
    WardrobeSort? sort,
    Occasion? Function()? occasionFilter,
    String? searchQuery,
    int? browseIndex,
  }) {
    return WardrobeState(
      outfits: outfits ?? this.outfits,
      sort: sort ?? this.sort,
      occasionFilter: occasionFilter != null ? occasionFilter() : this.occasionFilter,
      searchQuery: searchQuery ?? this.searchQuery,
      browseIndex: browseIndex ?? this.browseIndex,
    );
  }
}

/// Owns the current user's saved-outfit collection: loads it (local-first,
/// then `refreshFromRemote` once), exposes save/favorite/delete, and
/// tracks a "browse index" so gesture swipes and "next"/"previous" voice
/// commands can cycle through it — the real target the spec's Module 6/7
/// docs point to (`GestureAction.previousOutfit`/`nextOutfit`,
/// `VoiceCommandType.next`/`previous`, `GestureAction.saveFavorite`,
/// `VoiceCommandType.save`).
class WardrobeController extends StateNotifier<WardrobeState> {
  WardrobeController(this._ref, this._uid) : super(const WardrobeState()) {
    _subscribe();
    _ref.read(wardrobeRepositoryProvider).refreshFromRemote(_uid);
  }

  final Ref _ref;
  final String _uid;

  WardrobeRepository get _repository => _ref.read(wardrobeRepositoryProvider);

  void _subscribe() {
    _repository.watchOutfits(_uid).listen((outfits) {
      if (mounted) state = state.copyWith(outfits: outfits);
    });
  }

  void setSort(WardrobeSort sort) => state = state.copyWith(sort: sort);

  void setOccasionFilter(Occasion? occasion) =>
      state = state.copyWith(occasionFilter: () => occasion);

  void setSearchQuery(String query) => state = state.copyWith(searchQuery: query);

  /// Real target for the "Save" gesture (thumbs up) and voice command:
  /// snapshots whatever's currently selected in the try-on session as a
  /// new favorite. `name` defaults to a timestamp-based label if the
  /// caller doesn't prompt for one (voice/gesture saves skip the prompt
  /// for a fast, hands-free flow — `SaveOutfitSheet` is what lets a
  /// manual tap-to-save give it a real name).
  Future<SavedOutfit> saveCurrentOutfit({
    required Map<ClothingLayer, ClothingItem> selectedItems,
    String? name,
    Occasion? occasion,
    int? fashionScore,
    bool isFavorite = true,
  }) async {
    final now = DateTime.now();
    final outfit = SavedOutfit(
      id: 'outfit-${now.microsecondsSinceEpoch}',
      name: name ?? _defaultName(now),
      itemIdsByLayer: selectedItems.map((layer, item) => MapEntry(layer, item.id)),
      createdAt: now,
      occasion: occasion,
      fashionScore: fashionScore,
      isFavorite: isFavorite,
    );

    final result = await _repository.saveOutfit(_uid, outfit);
    return result.when(success: (o) => o, failure: (_) => outfit);
  }

  Future<void> toggleFavorite(String outfitId) =>
      _repository.toggleFavorite(_uid, outfitId);

  Future<void> deleteOutfit(String outfitId) => _repository.deleteOutfit(_uid, outfitId);

  /// Resolves a saved outfit's stored item ids back to real
  /// `ClothingItem`s against the current catalog — see `SavedOutfit`'s
  /// doc comment for why ids are stored rather than items directly. Items
  /// no longer in the catalog are silently dropped rather than throwing,
  /// since a demo catalog could in principle change between app updates.
  Map<ClothingLayer, ClothingItem> resolveItems(
    SavedOutfit outfit,
    List<ClothingItem> catalog,
  ) {
    final byId = {for (final item in catalog) item.id: item};
    final resolved = <ClothingLayer, ClothingItem>{};
    for (final entry in outfit.itemIdsByLayer.entries) {
      final item = byId[entry.value];
      if (item != null) resolved[entry.key] = item;
    }
    return resolved;
  }

  /// Real target for `GestureAction.nextOutfit`/`VoiceCommandType.next`.
  /// Returns the outfit to apply, or `null` if there's nothing saved yet.
  SavedOutfit? next() => _cycle(1);

  /// Real target for `GestureAction.previousOutfit`/`VoiceCommandType.previous`.
  SavedOutfit? previous() => _cycle(-1);

  SavedOutfit? _cycle(int direction) {
    final visible = state.visibleOutfits();
    if (visible.isEmpty) return null;

    final nextIndex = (state.browseIndex + direction) % visible.length;
    final normalized = nextIndex < 0 ? nextIndex + visible.length : nextIndex;
    state = state.copyWith(browseIndex: normalized);
    return visible[normalized];
  }

  String _defaultName(DateTime at) {
    final hour = at.hour % 12 == 0 ? 12 : at.hour % 12;
    final minute = at.minute.toString().padLeft(2, '0');
    final period = at.hour >= 12 ? 'PM' : 'AM';
    return 'Look — $hour:$minute $period';
  }
}

/// Auto-disposes per signed-in uid, same reasoning as
/// `tryOnSessionControllerProvider` — nothing to keep alive once the
/// Smart Mirror / Wardrobe screens aren't visible.
final wardrobeControllerProvider = StateNotifierProvider.autoDispose
    .family<WardrobeController, WardrobeState, String>((ref, uid) {
  return WardrobeController(ref, uid);
});

/// Convenience provider bound to whoever's currently signed in — `null`
/// while signed out (mirrors `currentUserProfileProvider`'s shape).
final currentUserWardrobeProvider =
    Provider.autoDispose<WardrobeState?>((ref) {
  final user = ref.watch(authStateChangesProvider).valueOrNull;
  if (user == null) return null;
  return ref.watch(wardrobeControllerProvider(user.uid));
});
