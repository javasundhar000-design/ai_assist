import 'package:flutter/material.dart';

import '../../../../core/theme/app_tokens.dart';

/// Prompts for a name before saving the current try-on selection to the
/// wardrobe — the manual-tap counterpart to the gesture/voice "Save,"
/// which skips this prompt for a hands-free flow (see
/// `WardrobeController.saveCurrentOutfit`'s doc comment).
class SaveOutfitSheet extends StatefulWidget {
  const SaveOutfitSheet({super.key, required this.suggestedName});

  final String suggestedName;

  @override
  State<SaveOutfitSheet> createState() => _SaveOutfitSheetState();
}

class _SaveOutfitSheetState extends State<SaveOutfitSheet> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.suggestedName);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: AppSpacing.lg,
        right: AppSpacing.lg,
        top: AppSpacing.lg,
        bottom: MediaQuery.of(context).viewInsets.bottom + AppSpacing.lg,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Save this look', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: AppSpacing.md),
          TextField(
            controller: _controller,
            autofocus: true,
            decoration: const InputDecoration(
              labelText: 'Name',
              border: OutlineInputBorder(),
            ),
            onSubmitted: (_) => Navigator.of(context).pop(_controller.text),
          ),
          const SizedBox(height: AppSpacing.lg),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: FilledButton(
                  onPressed: () => Navigator.of(context).pop(
                    _controller.text.trim().isEmpty
                        ? widget.suggestedName
                        : _controller.text.trim(),
                  ),
                  child: const Text('Save'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
