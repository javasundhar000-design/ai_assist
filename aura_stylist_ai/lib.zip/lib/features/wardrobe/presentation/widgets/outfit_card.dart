import 'package:flutter/material.dart';

import '../../../../core/theme/app_tokens.dart';
import '../../../tryon/domain/entities/clothing_item.dart';
import '../../../tryon/domain/entities/clothing_layer.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../domain/entities/saved_outfit.dart';

/// One saved outfit in `WardrobePage`'s grid. Shows a stack of color
/// swatches (one per resolved layer) rather than a garment photo — same
/// honesty pattern as `ClothingPickerSheet` and `TryOnPainter`: there's
/// no real garment artwork in this build, so the swatch stack is the
/// truthful stand-in for "what's in this outfit," not a placeholder
/// pretending otherwise.
class OutfitCard extends StatelessWidget {
  const OutfitCard({
    super.key,
    required this.outfit,
    required this.resolvedItems,
    required this.onTap,
    required this.onToggleFavorite,
    required this.onDelete,
  });

  final SavedOutfit outfit;
  final Map<ClothingLayer, ClothingItem> resolvedItems;
  final VoidCallback onTap;
  final VoidCallback onToggleFavorite;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final items = resolvedItems.values.toList()
      ..sort((a, b) => a.layer.zIndex.compareTo(b.layer.zIndex));

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.sm),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Center(
                      child: SizedBox(
                        width: 72,
                        height: 72,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            for (var i = 0; i < items.length; i++)
                              Positioned(
                                left: (i % 3) * 14.0,
                                top: (i ~/ 3) * 14.0,
                                child: Container(
                                  width: 34,
                                  height: 34,
                                  decoration: BoxDecoration(
                                    color: items[i].color,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: theme.colorScheme.surface,
                                      width: 2,
                                    ),
                                  ),
                                ),
                              ),
                            if (items.isEmpty)
                              Icon(
                                Icons.checkroom_outlined,
                                color: theme.colorScheme.onSurface.withOpacity(0.3),
                                size: 32,
                              ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 0,
                      right: 0,
                      child: IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: Icon(
                          outfit.isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: outfit.isFavorite ? theme.colorScheme.error : null,
                          size: 20,
                        ),
                        onPressed: onToggleFavorite,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                outfit.name,
                style: theme.textTheme.labelLarge,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Row(
                children: [
                  if (outfit.occasion != null)
                    Flexible(
                      child: Text(
                        outfit.occasion!.label,
                        style: theme.textTheme.labelSmall
                            ?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.6)),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  const Spacer(),
                  if (outfit.fashionScore != null)
                    Text(
                      '${outfit.fashionScore}',
                      style: theme.textTheme.labelSmall
                          ?.copyWith(color: theme.colorScheme.primary, fontWeight: FontWeight.bold),
                    ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.delete_outline_rounded, size: 18),
                    onPressed: onDelete,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
