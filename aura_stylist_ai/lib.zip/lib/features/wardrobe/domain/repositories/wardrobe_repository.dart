import '../../../../core/utils/result.dart';
import '../entities/saved_outfit.dart';

/// Contract for reading/writing a user's saved outfits ("Wardrobe" /
/// "Favorites" / "History" are three views over the same collection —
/// see `WardrobePage`'s tabs). Presentation-layer code depends only on
/// this interface — see `FakeWardrobeRepository` in tests.
abstract class WardrobeRepository {
  /// Live updates for [uid]'s saved outfits, newest-write-wins per id.
  /// Always backed by local storage (works offline and for guests);
  /// mirrored to Firebase in the background for real (non-guest)
  /// accounts — see `WardrobeRepositoryImpl`'s doc comment.
  Stream<List<SavedOutfit>> watchOutfits(String uid);

  Future<Result<SavedOutfit>> saveOutfit(String uid, SavedOutfit outfit);

  Future<Result<SavedOutfit>> toggleFavorite(String uid, String outfitId);

  Future<Result<void>> deleteOutfit(String uid, String outfitId);

  /// Pulls remote (Firebase) outfits into the local cache once, so a
  /// second device's saved outfits show up here too. Called once by
  /// `WardrobeController` on startup — see `WardrobeRepositoryImpl`'s doc
  /// comment for exactly what this does and doesn't handle. A no-op is a
  /// perfectly valid implementation for tests (`FakeWardrobeRepository`
  /// doesn't have a "remote" to refresh from).
  Future<void> refreshFromRemote(String uid);
}
