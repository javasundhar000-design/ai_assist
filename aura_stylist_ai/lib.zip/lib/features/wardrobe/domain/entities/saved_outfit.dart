import 'package:equatable/equatable.dart';

import '../../../tryon/domain/entities/clothing_layer.dart';
import '../../../tryon/domain/entities/occasion.dart';

/// A snapshot of one try-on session's selection, saved by the user — the
/// spec's "Wardrobe / Favorites / History" feature.
///
/// This stores catalog *item ids* per layer (`itemIdsByLayer`), not
/// `ClothingItem`s themselves — the demo catalog (`demoClothingCatalog`,
/// Module 8) is the single source of truth for what an item actually
/// looks like, so a saved outfit just remembers *which* items were worn.
/// `WardrobeController.resolveItems` re-hydrates ids back to real
/// `ClothingItem`s at read time. If a real, growable catalog ever replaces
/// the demo one (see Module 9's honest limitations), old saved outfits
/// keep working as long as item ids are stable.
class SavedOutfit extends Equatable {
  const SavedOutfit({
    required this.id,
    required this.name,
    required this.itemIdsByLayer,
    required this.createdAt,
    this.occasion,
    this.fashionScore,
    this.isFavorite = false,
  });

  final String id;
  final String name;

  /// Catalog item id per layer, e.g. `{shirt: 'shirt-navy', pant: 'pant-denim'}`.
  final Map<ClothingLayer, String> itemIdsByLayer;

  final DateTime createdAt;

  /// The occasion this outfit was scored/recommended for, if any — shown
  /// as a filter chip in `WardrobePage`.
  final Occasion? occasion;

  /// `FashionScore.overallScore` at the moment this outfit was saved (a
  /// snapshot, not recomputed later — skin tone/body type may have
  /// changed since).
  final int? fashionScore;

  final bool isFavorite;

  SavedOutfit copyWith({
    String? name,
    bool? isFavorite,
  }) {
    return SavedOutfit(
      id: id,
      name: name ?? this.name,
      itemIdsByLayer: itemIdsByLayer,
      createdAt: createdAt,
      occasion: occasion,
      fashionScore: fashionScore,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }

  factory SavedOutfit.fromMap(String id, Map<Object?, Object?> map) {
    final rawItems = (map['itemIdsByLayer'] as Map?) ?? const {};
    final itemIds = <ClothingLayer, String>{};
    for (final entry in rawItems.entries) {
      final layer = ClothingLayer.values
          .where((l) => l.name == entry.key as String?)
          .firstOrNull;
      if (layer != null && entry.value is String) {
        itemIds[layer] = entry.value as String;
      }
    }

    final createdAtRaw = map['createdAt'];
    final occasionName = map['occasion'] as String?;

    return SavedOutfit(
      id: id,
      name: map['name'] as String? ?? 'Saved Look',
      itemIdsByLayer: itemIds,
      createdAt: createdAtRaw is num
          ? DateTime.fromMillisecondsSinceEpoch(createdAtRaw.toInt())
          : DateTime.now(),
      occasion: occasionName == null
          ? null
          : Occasion.values.where((o) => o.name == occasionName).firstOrNull,
      fashionScore: (map['fashionScore'] as num?)?.toInt(),
      isFavorite: map['isFavorite'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'itemIdsByLayer': itemIdsByLayer.map((layer, id) => MapEntry(layer.name, id)),
      'createdAt': createdAt.millisecondsSinceEpoch,
      'occasion': occasion?.name,
      'fashionScore': fashionScore,
      'isFavorite': isFavorite,
    };
  }

  @override
  List<Object?> get props =>
      [id, name, itemIdsByLayer, createdAt, occasion, fashionScore, isFavorite];
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
