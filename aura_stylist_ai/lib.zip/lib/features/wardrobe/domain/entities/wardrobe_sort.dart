/// Sort options for `WardrobePage`'s outfit grid.
enum WardrobeSort { newestFirst, oldestFirst, highestScore }

extension WardrobeSortMeta on WardrobeSort {
  String get label => switch (this) {
        WardrobeSort.newestFirst => 'Newest first',
        WardrobeSort.oldestFirst => 'Oldest first',
        WardrobeSort.highestScore => 'Highest score',
      };
}
