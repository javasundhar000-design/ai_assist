import 'package:camera/camera.dart';

/// A single frame captured off the live camera stream, with the metadata
/// Module 5's ML Kit conversion will need alongside the raw pixel data:
/// sensor orientation and lens direction affect how a `CameraImage` must be
/// rotated/transformed into an `InputImage` for face/pose detection.
///
/// Deliberately not `Equatable` — frame identity/equality isn't a
/// meaningful concept here, and `CameraImage` holds large pixel buffers
/// that shouldn't be compared.
class CameraFrame {
  const CameraFrame({
    required this.image,
    required this.sensorOrientation,
    required this.lensDirection,
    required this.capturedAt,
  });

  final CameraImage image;
  final int sensorOrientation;
  final CameraLensDirection lensDirection;
  final DateTime capturedAt;
}
