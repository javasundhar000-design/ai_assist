import 'package:camera/camera.dart';

import '../../../../core/utils/result.dart';
import '../entities/camera_frame.dart';

/// Orchestrates the device camera for the Smart Mirror / virtual try-on
/// pipeline.
///
/// Pragmatic exception to strict Clean Architecture: this interface
/// exposes the `camera` plugin's own `CameraController` directly (via
/// [controller]) instead of hiding it behind a further abstraction.
/// `CameraController` is exactly what the `CameraPreview` widget needs,
/// there's no realistic alternate camera implementation this app would
/// ever swap in, and hiding it would mean re-implementing a large chunk of
/// the plugin's surface for no real benefit. Everything else here (frame
/// streaming, lens switching, error mapping) is still fully abstracted so
/// `FakeCameraRepository` can stand in for tests.
abstract class CameraRepository {
  CameraController? get controller;
  bool get isInitialized;
  List<CameraDescription> get cameras;

  /// Broadcast stream of frames while frame streaming is active. Module 5
  /// subscribes to this to run face/pose/skin-tone detection on each
  /// frame; Module 4 only proves the pipeline is alive (FPS counter).
  Stream<CameraFrame> get frameStream;

  Future<Result<void>> initialize({
    CameraLensDirection preferredLens = CameraLensDirection.front,
  });

  Future<Result<void>> startFrameStream();

  Future<Result<void>> stopFrameStream();

  /// Switches to the other available lens (front <-> back), preserving
  /// whether frame streaming was active.
  Future<Result<void>> switchLens();

  Future<void> dispose();
}
