import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart' show TargetPlatform, defaultTargetPlatform;

/// Raw access to the `camera` plugin. Kept "dumb" — `CameraRepositoryImpl`
/// owns the orchestration (which lens, streaming state, error mapping).
class CameraDataSource {
  Future<List<CameraDescription>> loadAvailableCameras() {
    return availableCameras();
  }

  /// Creates a controller at a resolution good enough for on-device
  /// face/pose detection without being wasteful of battery/CPU — Module 5
  /// runs ML Kit against these frames, not full-resolution photos.
  ///
  /// Image format differs by platform because that's what each platform's
  /// camera stack natively produces without an extra conversion pass:
  /// YUV420 on Android, BGRA8888 on iOS.
  CameraController createController(CameraDescription description) {
    return CameraController(
      description,
      ResolutionPreset.medium,
      enableAudio: false, // Never needed — this app never records audio via the camera.
      imageFormatGroup: defaultTargetPlatform == TargetPlatform.android
          ? ImageFormatGroup.yuv420
          : ImageFormatGroup.bgra8888,
    );
  }
}
