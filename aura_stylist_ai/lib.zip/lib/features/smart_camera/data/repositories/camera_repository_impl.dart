import 'dart:async';

import 'package:camera/camera.dart';

import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/camera_frame.dart';
import '../../domain/repositories/camera_repository.dart';
import '../datasources/camera_datasource.dart';

class CameraRepositoryImpl implements CameraRepository {
  CameraRepositoryImpl(this._dataSource);

  final CameraDataSource _dataSource;

  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  bool _isStreaming = false;

  // Broadcast, not closed on dispose() — the same repository instance is
  // reused across repeated visits to the Smart Mirror screen (see
  // `cameraRepositoryProvider`), so closing this would break re-subscription
  // on the next visit. It only ever closes when the whole app process ends.
  final _frameStreamController = StreamController<CameraFrame>.broadcast();

  @override
  CameraController? get controller => _controller;

  @override
  bool get isInitialized => _controller?.value.isInitialized ?? false;

  @override
  List<CameraDescription> get cameras => _cameras;

  @override
  Stream<CameraFrame> get frameStream => _frameStreamController.stream;

  @override
  Future<Result<void>> initialize({
    CameraLensDirection preferredLens = CameraLensDirection.front,
  }) async {
    try {
      _cameras = await _dataSource.loadAvailableCameras();
      if (_cameras.isEmpty) {
        return const Err(UnknownFailure('No cameras found on this device.'));
      }

      final description = _cameras.firstWhere(
        (c) => c.lensDirection == preferredLens,
        orElse: () => _cameras.first,
      );

      // Dispose any previous controller (e.g. re-initializing after a lens
      // switch or returning from the background) before creating a new one.
      await _controller?.dispose();
      _controller = _dataSource.createController(description);
      await _controller!.initialize();
      return const Success(null);
    } on CameraException catch (e) {
      return Err(UnknownFailure(e.description ?? 'Camera error (${e.code}).'));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> startFrameStream() async {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) {
      return const Err(UnknownFailure('Camera is not initialized.'));
    }
    if (_isStreaming) return const Success(null);

    try {
      await controller.startImageStream((image) {
        _frameStreamController.add(
          CameraFrame(
            image: image,
            sensorOrientation: controller.description.sensorOrientation,
            lensDirection: controller.description.lensDirection,
            capturedAt: DateTime.now(),
          ),
        );
      });
      _isStreaming = true;
      return const Success(null);
    } on CameraException catch (e) {
      return Err(UnknownFailure(e.description ?? 'Camera error (${e.code}).'));
    }
  }

  @override
  Future<Result<void>> stopFrameStream() async {
    final controller = _controller;
    if (controller == null || !_isStreaming) return const Success(null);

    try {
      await controller.stopImageStream();
      _isStreaming = false;
      return const Success(null);
    } on CameraException catch (e) {
      return Err(UnknownFailure(e.description ?? 'Camera error (${e.code}).'));
    }
  }

  @override
  Future<Result<void>> switchLens() async {
    if (_cameras.length < 2) {
      return const Err(UnknownFailure('Only one camera is available on this device.'));
    }

    final currentLens = _controller?.description.lensDirection;
    final next = _cameras.firstWhere(
      (c) => c.lensDirection != currentLens,
      orElse: () => _cameras.first,
    );

    final wasStreaming = _isStreaming;
    if (wasStreaming) await stopFrameStream();

    final result = await initialize(preferredLens: next.lensDirection);
    if (result.isSuccess && wasStreaming) {
      await startFrameStream();
    }
    return result;
  }

  @override
  Future<void> dispose() async {
    if (_isStreaming) {
      try {
        await _controller?.stopImageStream();
      } catch (_) {
        // Best-effort — the controller may already be in a bad state if
        // we're disposing because of an error.
      }
      _isStreaming = false;
    }
    await _controller?.dispose();
    _controller = null;
  }
}
