import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/camera_frame.dart';
import 'camera_providers.dart';

class FrameStreamState {
  const FrameStreamState({this.isStreaming = false, this.fps = 0});

  final bool isStreaming;
  final double fps;

  FrameStreamState copyWith({bool? isStreaming, double? fps}) {
    return FrameStreamState(
      isStreaming: isStreaming ?? this.isStreaming,
      fps: fps ?? this.fps,
    );
  }
}

/// Starts/stops the camera's frame stream and tracks a rolling FPS count
/// for the Smart Mirror HUD.
///
/// Module 5's face/pose detection (`VisionPipelineController`) subscribes
/// independently to the same underlying broadcast `frameStream` rather
/// than extending this class — see the note on `_onFrame` below. This
/// controller stays focused on proving frames are flowing end-to-end from
/// the camera hardware through to the UI (the FPS counter), without doing
/// any per-frame ML processing itself.
class FrameStreamController extends StateNotifier<FrameStreamState> {
  FrameStreamController(this._ref) : super(const FrameStreamState());

  final Ref _ref;
  StreamSubscription<CameraFrame>? _subscription;
  Timer? _fpsTimer;
  int _framesInWindow = 0;

  Future<void> start() async {
    if (state.isStreaming) return;

    final repository = _ref.read(cameraRepositoryProvider);
    final result = await repository.startFrameStream();

    result.when(
      success: (_) {
        state = state.copyWith(isStreaming: true);
        _subscription?.cancel();
        _subscription = repository.frameStream.listen(_onFrame);

        _fpsTimer?.cancel();
        _fpsTimer = Timer.periodic(const Duration(seconds: 1), (_) {
          // Guard against the timer firing in the gap between this
          // controller being disposed and the timer's own cancellation
          // actually taking effect -- `state =` on a disposed
          // StateNotifier throws.
          if (!mounted) return;
          state = state.copyWith(fps: _framesInWindow.toDouble());
          _framesInWindow = 0;
        });
      },
      // A failure here just means streaming didn't start — the page's
      // own initialize() error path is what surfaces this to the user;
      // this controller stays in its default (not-streaming) state.
      failure: (_) {},
    );
  }

  void _onFrame(CameraFrame frame) {
    _framesInWindow++;
    // Module 5's VisionPipelineController subscribes independently to this
    // same broadcast `frameStream` (via `cameraRepositoryProvider`) rather
    // than hooking into this method — `startFrameStream()` is idempotent
    // and the stream supports multiple listeners, so face/pose detection
    // runs alongside this FPS counter without either needing to know about
    // the other.
  }

  Future<void> stop() async {
    await _subscription?.cancel();
    _subscription = null;
    _fpsTimer?.cancel();
    _fpsTimer = null;
    _framesInWindow = 0;
    await _ref.read(cameraRepositoryProvider).stopFrameStream();
    if (mounted) state = state.copyWith(isStreaming: false, fps: 0);
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _fpsTimer?.cancel();
    super.dispose();
  }
}

final frameStreamControllerProvider =
    StateNotifierProvider.autoDispose<FrameStreamController, FrameStreamState>(
  (ref) => FrameStreamController(ref),
);
