import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/camera_datasource.dart';
import '../../data/repositories/camera_repository_impl.dart';
import '../../domain/repositories/camera_repository.dart';

final cameraDataSourceProvider = Provider<CameraDataSource>((ref) => CameraDataSource());

/// Typed as the abstract `CameraRepository` so tests can override this
/// with `FakeCameraRepository`. Kept as a plain (non-autoDispose) provider
/// so the same instance persists across rebuilds of the Smart Mirror
/// screen — `SmartCameraPage` explicitly calls `initialize()`/`dispose()`
/// on it as the screen enters/leaves rather than relying on provider
/// disposal to manage the camera hardware.
final cameraRepositoryProvider = Provider<CameraRepository>((ref) {
  return CameraRepositoryImpl(ref.watch(cameraDataSourceProvider));
});
