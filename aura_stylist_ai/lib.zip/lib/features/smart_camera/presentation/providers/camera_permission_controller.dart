import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/permissions/app_permission.dart';
import '../../../../core/permissions/permission_gateway.dart';
import '../../../../core/permissions/permission_providers.dart';

/// Reactive camera-permission state for the Smart Mirror screen. Checks
/// the current status on creation (so returning to the screen after a
/// user grants it in system Settings reflects reality), and exposes
/// `request()`/`openSettings()` for the permission-gate UI.
class CameraPermissionController extends StateNotifier<AppPermissionState> {
  CameraPermissionController(this._gateway) : super(AppPermissionState.unknown) {
    _check();
  }

  final PermissionGateway _gateway;

  Future<void> _check() async {
    state = await _gateway.checkStatus(AppPermission.camera);
  }

  Future<void> request() async {
    state = await _gateway.request(AppPermission.camera);
  }

  Future<void> openSettings() => _gateway.openSettings();

  /// Re-checks status — call when the app resumes from background in case
  /// the user changed the permission in system Settings.
  Future<void> refresh() => _check();
}

final cameraPermissionControllerProvider =
    StateNotifierProvider.autoDispose<CameraPermissionController, AppPermissionState>(
  (ref) => CameraPermissionController(ref.watch(permissionGatewayProvider)),
);
