import 'package:flutter/material.dart';

import '../../../../core/permissions/app_permission.dart';
import '../../../../core/theme/app_tokens.dart';

/// Shown instead of the camera preview until permission is granted.
/// Distinguishes "not asked yet / denied once" (offer to request again)
/// from "permanently denied" (must go to system Settings — re-requesting
/// won't show the OS dialog again on either platform).
class PermissionGate extends StatelessWidget {
  const PermissionGate({
    super.key,
    required this.state,
    required this.onRequest,
    required this.onOpenSettings,
  });

  final AppPermissionState state;
  final VoidCallback onRequest;
  final VoidCallback onOpenSettings;

  @override
  Widget build(BuildContext context) {
    final needsSettings = state == AppPermissionState.permanentlyDenied ||
        state == AppPermissionState.restricted;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.camera_alt_outlined, size: 56, color: Colors.white70),
            const SizedBox(height: AppSpacing.md),
            Text(
              'Camera access needed',
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(color: Colors.white),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              needsSettings
                  ? "Camera access was denied. You'll need to enable it from your "
                      'device Settings to use the Smart Mirror.'
                  : 'AURA uses your camera on-device to power the Smart Mirror and '
                      "virtual try-on — nothing is ever uploaded off your phone.",
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(color: Colors.white70),
            ),
            const SizedBox(height: AppSpacing.lg),
            FilledButton(
              onPressed: needsSettings ? onOpenSettings : onRequest,
              child: Text(needsSettings ? 'Open Settings' : 'Grant Camera Access'),
            ),
          ],
        ),
      ),
    );
  }
}
