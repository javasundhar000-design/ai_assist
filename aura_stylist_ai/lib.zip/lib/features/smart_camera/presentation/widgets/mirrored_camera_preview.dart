import 'dart:math' show pi;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

/// Front-facing cameras are mirrored the way a real mirror is (what's on
/// your left appears on your left in the preview) — but `CameraPreview`
/// renders the raw sensor image, which is left-right flipped relative to
/// that expectation. This widget flips it back for the front lens only;
/// the back lens is shown as-is.
class MirroredCameraPreview extends StatelessWidget {
  const MirroredCameraPreview({super.key, required this.controller});

  final CameraController controller;

  @override
  Widget build(BuildContext context) {
    final preview = CameraPreview(controller);

    if (controller.description.lensDirection != CameraLensDirection.front) {
      return preview;
    }

    return Transform(
      alignment: Alignment.center,
      transform: Matrix4.rotationY(pi),
      child: preview,
    );
  }
}
