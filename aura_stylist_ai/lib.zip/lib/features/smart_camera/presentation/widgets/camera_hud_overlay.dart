import 'package:flutter/material.dart';

import '../../../../core/permissions/app_permission.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../core/widgets/glass_container.dart';
import '../../../gestures/domain/entities/gesture_type.dart';
import '../../../gestures/presentation/providers/gesture_recognition_controller.dart';
import '../../../vision/domain/entities/body_metrics.dart';
import '../../../vision/domain/entities/face_shape.dart';
import '../../../vision/domain/entities/skin_tone.dart';
import '../../../vision/presentation/providers/vision_pipeline_controller.dart';
import '../../../voice/presentation/providers/voice_assistant_controller.dart';

/// The floating HUD from the "Smart Mirror Mode" spec (FPS, AI Status,
/// Skin Tone, Body Type, Voice Status, Gesture Status). As of Module 7,
/// every row is a real, live value — nothing left to mark "Offline".
class CameraHudOverlay extends StatelessWidget {
  const CameraHudOverlay({
    super.key,
    required this.fps,
    required this.isStreaming,
    required this.visionState,
    required this.gestureState,
    required this.voiceState,
  });

  final double fps;
  final bool isStreaming;
  final VisionAnalysisState visionState;
  final GestureRecognitionState gestureState;
  final VoiceAssistantState voiceState;

  @override
  Widget build(BuildContext context) {
    final aiStatus = !isStreaming
        ? 'Idle'
        : visionState.hasFace || visionState.hasPose
            ? 'Running'
            : 'Running · no person detected';

    final skinTone = visionState.skinToneSample?.tone.label ?? 'Detecting...';
    final bodyType = visionState.bodyType?.label ?? 'Detecting...';
    final faceShape = visionState.faceShape?.label;

    final lastGesture = gestureState.lastEvent;
    final gestureLabel = lastGesture == null
        ? 'No gesture yet'
        : '${lastGesture.type.label} · ${_secondsAgo(lastGesture.detectedAt)}s ago';

    final voiceLabel = voiceState.permissionState != AppPermissionState.granted
        ? 'Mic permission needed'
        : voiceState.isListening
            ? 'Listening...'
            : 'Idle';

    return Positioned(
      top: AppSpacing.md,
      left: AppSpacing.md,
      right: AppSpacing.md,
      child: GlassContainer(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.sm,
        ),
        blurSigma: 12,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _HudRow(label: 'FPS', value: isStreaming ? fps.toStringAsFixed(0) : '--'),
            _HudRow(label: 'AI Status', value: aiStatus),
            if (faceShape != null) _HudRow(label: 'Face Shape', value: faceShape),
            _HudRow(label: 'Skin Tone', value: skinTone),
            _HudRow(label: 'Body Type', value: bodyType),
            _HudRow(label: 'Gesture', value: gestureLabel),
            _HudRow(label: 'Voice', value: voiceLabel),
          ],
        ),
      ),
    );
  }

  int _secondsAgo(DateTime time) => DateTime.now().difference(time).inSeconds;
}

class _HudRow extends StatelessWidget {
  const _HudRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final labelStyle = Theme.of(context)
        .textTheme
        .labelSmall
        ?.copyWith(color: Colors.white70);
    final valueStyle = Theme.of(context).textTheme.labelSmall?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: labelStyle),
          Text(value, style: valueStyle),
        ],
      ),
    );
  }
}
