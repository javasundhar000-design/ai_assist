import 'dart:async';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/permissions/app_permission.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../auth/presentation/providers/auth_providers.dart';
import '../../../gestures/domain/entities/gesture_action.dart';
import '../../../gestures/domain/entities/gesture_type.dart';
import '../../../gestures/presentation/providers/gesture_recognition_controller.dart';
import '../../../profile/presentation/providers/profile_providers.dart';
import '../../../recommendation/domain/services/catalog_search_service.dart';
import '../../../recommendation/domain/services/fashion_score_calculator.dart';
import '../../../recommendation/domain/services/recommendation_engine.dart';
import '../../../recommendation/presentation/widgets/catalog_search_results_sheet.dart';
import '../../../recommendation/presentation/widgets/fashion_score_sheet.dart';
import '../../../recommendation/presentation/widgets/recommendation_result_sheet.dart';
import '../../../tryon/domain/entities/occasion.dart';
import '../../../tryon/presentation/providers/clothing_catalog_provider.dart';
import '../../../tryon/presentation/providers/try_on_session_controller.dart';
import '../../../tryon/presentation/widgets/clothing_picker_sheet.dart';
import '../../../tryon/presentation/widgets/try_on_overlay.dart';
import '../../../vision/domain/entities/body_metrics.dart';
import '../../../vision/domain/entities/face_shape.dart';
import '../../../vision/domain/entities/skin_tone.dart';
import '../../../vision/presentation/providers/vision_pipeline_controller.dart';
import '../../../vision/presentation/widgets/vision_overlay.dart';
import '../../../voice/domain/entities/voice_command.dart';
import '../../../voice/presentation/providers/voice_assistant_controller.dart';
import '../../../voice/presentation/widgets/voice_transcript_banner.dart';
import '../../../settings/data/settings_local_preferences.dart';
import '../../../settings/presentation/providers/settings_providers.dart';
import '../../../wardrobe/presentation/providers/wardrobe_controller.dart';
import '../../../wardrobe/presentation/widgets/save_outfit_sheet.dart';
import '../providers/camera_permission_controller.dart';
import '../providers/camera_providers.dart';
import '../../domain/repositories/camera_repository.dart';
import '../providers/frame_stream_controller.dart';
import '../widgets/camera_hud_overlay.dart';
import '../widgets/mirrored_camera_preview.dart';
import '../widgets/permission_gate.dart';

enum _LoadState { idle, initializing, ready, error }

/// The Smart Mirror screen: front-camera preview (mirrored like a real
/// mirror), a live FPS + AI-analysis HUD, lens switching, real face/pose
/// detection (Module 5), gesture recognition (Module 6), a full voice
/// assistant loop (Module 7), a live virtual try-on overlay (Module 8),
/// and — as of Module 9 — real outfit recommendations and fashion
/// scoring.
///
/// Camera hardware is released whenever the app is backgrounded
/// (`AppLifecycleState.paused`/`inactive`) and re-acquired on resume, which
/// is standard practice: holding the camera open while backgrounded wastes
/// battery and can crash on some Android OEM skins that kill backgrounded
/// camera sessions anyway. The vision pipeline follows the same lifecycle
/// as the frame stream — both start together once the camera is ready and
/// stop together when it isn't. Voice listening is stopped on background
/// too (no reason to keep the mic hot while the app isn't visible).
class SmartCameraPage extends ConsumerStatefulWidget {
  const SmartCameraPage({super.key});

  @override
  ConsumerState<SmartCameraPage> createState() => _SmartCameraPageState();
}

class _SmartCameraPageState extends ConsumerState<SmartCameraPage>
    with WidgetsBindingObserver {
  _LoadState _loadState = _LoadState.idle;
  String? _errorMessage;

  /// Whether the pose/face landmark overlay (dots, skeleton lines, face
  /// box) is visible. Defaults to hidden — it's a debug/verification
  /// visual from Module 5 for checking that tracking is working, not
  /// part of the intended "smart mirror" experience, so a fashion
  /// try-on session shouldn't show it unless explicitly turned on.
  bool _showTrackingOverlay = false;

  /// Set whenever a "recommend [occasion] outfit" request succeeds, and
  /// reused as the context for "Score My Look" until the user asks for a
  /// different occasion. Defaults to Casual, a reasonable general-purpose
  /// baseline.
  Occasion _lastOccasion = Occasion.casual;

  // Cached in initState() rather than read fresh in dispose(). This is a
  // real flutter_riverpod constraint, not a style choice: `ref` cannot be
  // used inside `State.dispose()` -- `ConsumerStatefulElement` marks
  // itself disposed before calling `State.dispose()`, so any
  // `ref.read()`/`ref.watch()` there throws "Cannot use ref after the
  // widget was disposed." Grabbing these once, up front, while `ref` is
  // still valid, and using the cached references at teardown is the only
  // reliable way to release camera/vision/voice resources when this page
  // is popped.
  late final FrameStreamController _frameStreamController;
  late final VisionPipelineController _visionPipelineController;
  late final VoiceAssistantController _voiceAssistantController;
  late final CameraRepository _cameraRepository;

  @override
  void initState() {
    super.initState();
    _frameStreamController = ref.read(frameStreamControllerProvider.notifier);
    _visionPipelineController = ref.read(visionPipelineControllerProvider.notifier);
    _voiceAssistantController = ref.read(voiceAssistantControllerProvider.notifier);
    _cameraRepository = ref.read(cameraRepositoryProvider);
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    final permissionState = ref.read(cameraPermissionControllerProvider);
    if (permissionState == AppPermissionState.granted) {
      await _initializeCamera();
    }
  }

  Future<void> _initializeCamera() async {
    if (!mounted) return;
    setState(() {
      _loadState = _LoadState.initializing;
      _errorMessage = null;
    });

    final preferredLens = ref.read(cameraSettingsProvider) == PreferredCameraLens.back
        ? CameraLensDirection.back
        : CameraLensDirection.front;
    final result = await ref
        .read(cameraRepositoryProvider)
        .initialize(preferredLens: preferredLens);

    await result.when(
      success: (_) async {
        try {
          await ref.read(frameStreamControllerProvider.notifier).start();
          await ref.read(visionPipelineControllerProvider.notifier).start();
          if (mounted) setState(() => _loadState = _LoadState.ready);
          // Hands-free smart mirror: start listening automatically as soon
          // as the camera/vision pipeline is up, instead of waiting for a
          // manual tap on the mic icon. The mic icon still works as a
          // manual on/off toggle after this.
          unawaited(_autoStartVoice());
        } catch (e) {
          // Frame streaming or vision pipeline startup failing here used
          // to leave `_loadState` stuck at `initializing` forever with no
          // visible error -- the camera preview itself never showed (only
          // the `ready` case renders it), the app bar's action icons
          // (all gated on `_loadState == ready`) never appeared, and
          // there was nothing on screen to explain why. Surfacing the
          // real error here at least gives something actionable instead
          // of an indefinite, silent hang.
          if (mounted) {
            setState(() {
              _loadState = _LoadState.error;
              _errorMessage = 'Camera started, but the vision pipeline failed to '
                  'start: $e';
            });
          }
        }
      },
      failure: (f) async {
        if (mounted) {
          setState(() {
            _loadState = _LoadState.error;
            _errorMessage = f.message;
          });
        }
      },
    );
  }

  Future<void> _switchCamera() async {
    await ref.read(frameStreamControllerProvider.notifier).stop();
    await ref.read(visionPipelineControllerProvider.notifier).stop();
    ref.read(gestureRecognitionControllerProvider.notifier).reset();
    final result = await ref.read(cameraRepositoryProvider).switchLens();

    if (!mounted) return;

    result.when(
      success: (_) {
        ref.read(frameStreamControllerProvider.notifier).start();
        ref.read(visionPipelineControllerProvider.notifier).start();
      },
      failure: (f) => ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(f.message))),
    );
    setState(() {}); // Refresh so the preview picks up the new controller.
  }

  Future<void> _saveAnalysisToProfile() async {
    final visionState = ref.read(visionPipelineControllerProvider);
    final user = ref.read(authRepositoryProvider).currentUser;
    final currentProfile = ref.read(currentUserProfileProvider).valueOrNull;

    if (user == null || currentProfile == null) return;
    if (visionState.faceShape == null &&
        visionState.skinToneSample == null &&
        visionState.bodyType == null) {
      return;
    }

    final updated = currentProfile.copyWith(
      faceShape: visionState.faceShape?.label ?? currentProfile.faceShape,
      skinTone: visionState.skinToneSample?.tone.label ?? currentProfile.skinTone,
      bodyType: visionState.bodyType?.label ?? currentProfile.bodyType,
    );

    final result = await ref.read(profileRepositoryProvider).updateProfile(updated);
    if (!mounted) return;

    result.when(
      success: (_) => ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Saved to your profile'))),
      failure: (f) => ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(f.message))),
    );
  }

  Future<void> _toggleVoice() async {
    final voiceController = ref.read(voiceAssistantControllerProvider.notifier);
    final voiceState = ref.read(voiceAssistantControllerProvider);

    if (voiceState.isListening) {
      await voiceController.stop();
      return;
    }

    if (voiceState.permissionState != AppPermissionState.granted) {
      await voiceController.requestPermission();
      if (!mounted) return;
      final updated = ref.read(voiceAssistantControllerProvider);

      if (updated.permissionState == AppPermissionState.permanentlyDenied ||
          updated.permissionState == AppPermissionState.restricted) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(
            content: const Text('Microphone access is needed for voice commands.'),
            action: SnackBarAction(
              label: 'Settings',
              onPressed: voiceController.openSettings,
            ),
          ));
        return;
      }
      if (updated.permissionState != AppPermissionState.granted) return;
    }

    await voiceController.start();
  }

  /// Same permission-aware start flow as the manual mic button, just
  /// triggered by a gesture instead of a tap.
  Future<void> _toggleVoiceOn() async {
    final voiceState = ref.read(voiceAssistantControllerProvider);
    if (voiceState.isListening) return;
    await _toggleVoice();
  }

  /// Called once, right after the camera/vision pipeline finishes
  /// starting, so voice mode is on by default instead of requiring a tap
  /// on the mic icon first. Requests mic permission automatically if it
  /// hasn't been granted yet; if the user denies it (or it's already
  /// permanently denied), this silently backs off rather than nagging —
  /// the mic icon is still there for a manual retry, and the settings
  /// snackbar in `_toggleVoice` covers the "I changed my mind" case.
  Future<void> _autoStartVoice() async {
    if (!mounted) return;
    final voiceController = ref.read(voiceAssistantControllerProvider.notifier);
    var voiceState = ref.read(voiceAssistantControllerProvider);

    if (voiceState.isListening) return;

    if (voiceState.permissionState != AppPermissionState.granted) {
      await voiceController.requestPermission();
      if (!mounted) return;
      voiceState = ref.read(voiceAssistantControllerProvider);
      if (voiceState.permissionState != AppPermissionState.granted) return;
    }

    await voiceController.start();
  }

  /// Real target for the spec's Open Wardrobe voice command and (once
  /// hand-shape detection exists) the Open Palm gesture — see
  /// `GestureAction.isImplemented`'s doc comment for why the gesture path
  /// is already wired even though it can't fire yet.
  void _openClothingPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      isScrollControlled: true,
      builder: (_) => const ClothingPickerSheet(),
    );
  }

  void _closeClothingPicker() {
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).maybePop();
    }
  }

  /// Best-available skin tone/body type for scoring: prefer this
  /// session's live detection (Module 5), fall back to whatever's saved
  /// on the profile (Module 3).
  (SkinTone?, BodyType?) _currentStyleContext() {
    final visionState = ref.read(visionPipelineControllerProvider);
    final profile = ref.read(currentUserProfileProvider).valueOrNull;

    final skinToneLabel = visionState.skinToneSample?.tone.label ?? profile?.skinTone;
    final bodyTypeLabel = visionState.bodyType?.label ?? profile?.bodyType;

    final skinTone = skinToneLabel == null ? null : SkinToneParsing.fromLabel(skinToneLabel);
    final bodyType = bodyTypeLabel == null ? null : BodyTypeParsing.fromLabel(bodyTypeLabel);
    return (skinTone, bodyType);
  }

  /// Real target for the "Recommend [occasion] outfit" voice command.
  void _showRecommendation(Occasion occasion) {
    final catalog = ref.read(clothingCatalogProvider);
    final (skinTone, bodyType) = _currentStyleContext();

    const engine = RecommendationEngine();
    final recommendation = engine.recommend(
      catalog: catalog,
      occasion: occasion,
      skinTone: skinTone,
      bodyType: bodyType,
    );

    _lastOccasion = occasion;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (sheetContext) => RecommendationResultSheet(
        recommendation: recommendation,
        occasion: occasion,
        onWearThis: () {
          final notifier = ref.read(tryOnSessionControllerProvider.notifier);
          for (final item in recommendation.items.values) {
            notifier.selectItem(item);
          }
          Navigator.of(sheetContext).pop();
        },
      ),
    );
  }

  /// Real target for the "Show [color] [category]" voice command.
  void _showCatalogSearch({String? color, String? category}) {
    final catalog = ref.read(clothingCatalogProvider);
    const searchService = CatalogSearchService();
    final results = searchService.filter(catalog, color: color, category: category);
    final query = [if (color != null) color, if (category != null) category].join(' ');

    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (sheetContext) => CatalogSearchResultsSheet(
        results: results,
        query: query,
        onSelect: (item) {
          ref.read(tryOnSessionControllerProvider.notifier).selectItem(item);
          Navigator.of(sheetContext).pop();
        },
      ),
    );
  }

  /// Real target for the "Score My Look" app-bar action — scores
  /// whatever's currently selected in the try-on session.
  void _showFashionScore() {
    const calculator = FashionScoreCalculator();
    final tryOnState = ref.read(tryOnSessionControllerProvider);
    final (skinTone, bodyType) = _currentStyleContext();

    final score = calculator.calculate(
      items: tryOnState.selectedItems.values.toList(),
      occasion: _lastOccasion,
      skinTone: skinTone,
      bodyType: bodyType,
    );

    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (_) => FashionScoreSheet(score: score, occasion: _lastOccasion),
    );
  }

  /// Real target for `GestureAction.saveFavorite` (thumbs up) and
  /// `VoiceCommandType.save` ("save") — snapshots the current try-on
  /// selection straight to the wardrobe, no naming prompt, so both stay
  /// hands-free. See `_saveOutfitWithPrompt` for the manual, named-save
  /// counterpart triggered from the app bar.
  Future<void> _saveCurrentOutfitHandsFree() async {
    final user = ref.read(authRepositoryProvider).currentUser;
    final tryOnState = ref.read(tryOnSessionControllerProvider);
    if (user == null || tryOnState.selectedItems.isEmpty) return;

    final score = _scoreCurrentSelection();
    await ref.read(wardrobeControllerProvider(user.uid).notifier).saveCurrentOutfit(
      selectedItems: tryOnState.selectedItems,
      occasion: _lastOccasion,
      fashionScore: score,
    );

    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(content: Text('Saved to your wardrobe')));
  }

  /// Real target for the app bar's "Save outfit" action — same save as
  /// above, but prompts for a name first.
  Future<void> _saveOutfitWithPrompt() async {
    final user = ref.read(authRepositoryProvider).currentUser;
    final tryOnState = ref.read(tryOnSessionControllerProvider);
    if (user == null || tryOnState.selectedItems.isEmpty) return;

    final suggestedName = 'Look ${DateFormat('MMM d, h:mm a').format(DateTime.now())}';
    final name = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (_) => SaveOutfitSheet(suggestedName: suggestedName),
    );
    if (name == null || !mounted) return;

    final score = _scoreCurrentSelection();
    await ref.read(wardrobeControllerProvider(user.uid).notifier).saveCurrentOutfit(
      selectedItems: tryOnState.selectedItems,
      name: name,
      occasion: _lastOccasion,
      fashionScore: score,
    );

    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('Saved "$name" to your wardrobe')));
  }

  int? _scoreCurrentSelection() {
    final tryOnState = ref.read(tryOnSessionControllerProvider);
    if (tryOnState.selectedItems.isEmpty) return null;
    const calculator = FashionScoreCalculator();
    final (skinTone, bodyType) = _currentStyleContext();
    return calculator
        .calculate(
      items: tryOnState.selectedItems.values.toList(),
      occasion: _lastOccasion,
      skinTone: skinTone,
      bodyType: bodyType,
    )
        .overallScore;
  }

  /// Real target for `GestureAction.previousOutfit`/`nextOutfit` and
  /// `VoiceCommandType.previous`/`next` — cycles through the signed-in
  /// user's saved wardrobe and applies whichever outfit comes up to the
  /// live try-on session, same as `RecommendationResultSheet`'s "Wear
  /// This."
  void _cycleWardrobeOutfit({required bool forward}) {
    final user = ref.read(authRepositoryProvider).currentUser;
    if (user == null) return;

    final wardrobeNotifier = ref.read(wardrobeControllerProvider(user.uid).notifier);
    final outfit = forward ? wardrobeNotifier.next() : wardrobeNotifier.previous();

    if (outfit == null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(
          content: Text('No saved outfits yet — save one first.'),
        ));
      return;
    }

    final catalog = ref.read(clothingCatalogProvider);
    final resolved = wardrobeNotifier.resolveItems(outfit, catalog);
    final tryOnNotifier = ref.read(tryOnSessionControllerProvider.notifier);
    tryOnNotifier.reset();
    for (final item in resolved.values) {
      tryOnNotifier.selectItem(item);
    }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('Wearing "${outfit.name}"')));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState appState) {
    if (appState == AppLifecycleState.inactive ||
        appState == AppLifecycleState.paused) {
      if (_loadState == _LoadState.ready) {
        ref.read(frameStreamControllerProvider.notifier).stop();
        ref.read(visionPipelineControllerProvider.notifier).stop();
        ref.read(voiceAssistantControllerProvider.notifier).stop();
        ref.read(cameraRepositoryProvider).dispose();
        _loadState = _LoadState.idle;
      }
    } else if (appState == AppLifecycleState.resumed) {
      ref.read(cameraPermissionControllerProvider.notifier).refresh();
      if (_loadState == _LoadState.idle) {
        _bootstrap();
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    // Cached references (see field doc comments above) -- `ref` itself
    // is no longer safe to touch by the time dispose() runs.
    _frameStreamController.stop();
    _visionPipelineController.stop();
    _voiceAssistantController.stop();
    _cameraRepository.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final permissionState = ref.watch(cameraPermissionControllerProvider);
    final frameState = ref.watch(frameStreamControllerProvider);
    final visionState = ref.watch(visionPipelineControllerProvider);
    final gestureState = ref.watch(gestureRecognitionControllerProvider);
    final voiceState = ref.watch(voiceAssistantControllerProvider);
    final tryOnState = ref.watch(tryOnSessionControllerProvider);

    ref.listen<AppPermissionState>(cameraPermissionControllerProvider,
            (previous, next) {
          if (next == AppPermissionState.granted &&
              previous != AppPermissionState.granted) {
            _initializeCamera();
          }
        });

    // Gestures drive real actions where one exists: Raised Right/Left Hand
    // start/stop voice mode (Module 7); Both Hands Up resets the try-on
    // session, and Open Palm/Closed Fist would open/close the clothing
    // picker if that gesture pair were detectable (Module 8) — see
    // `GestureAction.isImplemented`'s doc comment.
    ref.listen<GestureRecognitionState>(gestureRecognitionControllerProvider,
            (previous, next) {
          final event = next.lastEvent;
          if (event == null || event == previous?.lastEvent) return;
          final action = next.lastAction;

          switch (action) {
            case GestureAction.startVoiceMode:
              _toggleVoiceOn();
              break;
            case GestureAction.stopVoiceMode:
              ref.read(voiceAssistantControllerProvider.notifier).stop();
              break;
            case GestureAction.resetTryOn:
              ref.read(tryOnSessionControllerProvider.notifier).reset();
              break;
            case GestureAction.openMenu:
              _openClothingPicker();
              break;
            case GestureAction.closeMenu:
              _closeClothingPicker();
              break;
            case GestureAction.saveFavorite:
              _saveCurrentOutfitHandsFree();
              break;
            case GestureAction.nextOutfit:
              _cycleWardrobeOutfit(forward: true);
              break;
            case GestureAction.previousOutfit:
              _cycleWardrobeOutfit(forward: false);
              break;
            default:
              break;
          }

          final message = action == null
              ? 'Gesture: ${event.type.label}'
              : action.isImplemented
              ? 'Gesture: ${event.type.label} → ${action.label}'
              : 'Gesture: ${event.type.label} → ${action.label} '
              '(${action.owningModule})';
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(SnackBar(
              content: Text(message),
              duration: const Duration(seconds: 2),
            ));
        });

    // "Exit", "Open Wardrobe", "Close Wardrobe", "Show X", and "Recommend
    // X outfit" all need a BuildContext (navigation / showing a bottom
    // sheet) — handled here rather than inside VoiceAssistantController,
    // same reasoning as the gesture dispatch above. Dark Mode/Light
    // Mode/Reset are applied directly inside the controller since they
    // don't need one.
    ref.listen<VoiceAssistantState>(voiceAssistantControllerProvider,
            (previous, next) {
          final command = next.lastCommand;
          if (command == null || command == previous?.lastCommand) return;

          switch (command.type) {
            case VoiceCommandType.exit:
              if (context.canPop()) {
                context.pop();
              } else {
                context.go(AppRoutes.dashboard);
              }
              break;
            case VoiceCommandType.openWardrobe:
              _openClothingPicker();
              break;
            case VoiceCommandType.closeWardrobe:
              _closeClothingPicker();
              break;
            case VoiceCommandType.recommendOutfit:
              final occasion = command.occasion == null
                  ? null
                  : OccasionMeta.fromKeyword(command.occasion!);
              _showRecommendation(occasion ?? Occasion.casual);
              break;
            case VoiceCommandType.showItems:
              _showCatalogSearch(color: command.color, category: command.category);
              break;
            case VoiceCommandType.save:
              _saveCurrentOutfitHandsFree();
              break;
            case VoiceCommandType.next:
              _cycleWardrobeOutfit(forward: true);
              break;
            case VoiceCommandType.previous:
              _cycleWardrobeOutfit(forward: false);
              break;
            default:
              break;
          }
        });

    final canSaveToProfile = _loadState == _LoadState.ready &&
        (visionState.faceShape != null ||
            visionState.skinToneSample != null ||
            visionState.bodyType != null);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: const Text('Smart Mirror'),
        actions: [
          if (tryOnState.selectedItems.isNotEmpty)
            IconButton(
              tooltip: 'Score my look',
              icon: const Icon(Icons.auto_awesome_rounded),
              onPressed: _showFashionScore,
            ),
          if (tryOnState.selectedItems.isNotEmpty)
            IconButton(
              tooltip: 'Save outfit to wardrobe',
              icon: const Icon(Icons.favorite_border_rounded),
              onPressed: _saveOutfitWithPrompt,
            ),
          if (_loadState == _LoadState.ready)
            IconButton(
              tooltip: 'Try on clothes',
              icon: const Icon(Icons.checkroom_outlined),
              onPressed: _openClothingPicker,
            ),
          if (_loadState == _LoadState.ready)
            IconButton(
              tooltip: voiceState.isListening
                  ? 'Stop voice assistant'
                  : 'Start voice assistant',
              icon: Icon(
                voiceState.isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
              ),
              onPressed: _toggleVoice,
            ),
          if (canSaveToProfile)
            IconButton(
              tooltip: 'Save analysis to profile',
              icon: const Icon(Icons.bookmark_add_outlined),
              onPressed: _saveAnalysisToProfile,
            ),
          if (_loadState == _LoadState.ready)
            IconButton(
              tooltip: _showTrackingOverlay ? 'Hide tracking overlay' : 'Show tracking overlay',
              icon: Icon(
                _showTrackingOverlay
                    ? Icons.visibility_rounded
                    : Icons.visibility_off_outlined,
              ),
              onPressed: () =>
                  setState(() => _showTrackingOverlay = !_showTrackingOverlay),
            ),
          if (_loadState == _LoadState.ready)
            IconButton(
              tooltip: 'Switch camera',
              icon: const Icon(Icons.cameraswitch_rounded),
              onPressed: _switchCamera,
            ),
        ],
      ),
      body: permissionState != AppPermissionState.granted
          ? PermissionGate(
        state: permissionState,
        onRequest: () =>
            ref.read(cameraPermissionControllerProvider.notifier).request(),
        onOpenSettings: () => ref
            .read(cameraPermissionControllerProvider.notifier)
            .openSettings(),
      )
          : _CameraBody(
        loadState: _loadState,
        errorMessage: _errorMessage,
        frameState: frameState,
        visionState: visionState,
        gestureState: gestureState,
        voiceState: voiceState,
        tryOnState: tryOnState,
        showTrackingOverlay: _showTrackingOverlay,
        onRetry: _initializeCamera,
      ),
    );
  }
}

class _CameraBody extends ConsumerWidget {
  const _CameraBody({
    required this.loadState,
    required this.errorMessage,
    required this.frameState,
    required this.visionState,
    required this.gestureState,
    required this.voiceState,
    required this.tryOnState,
    required this.showTrackingOverlay,
    required this.onRetry,
  });

  final _LoadState loadState;
  final String? errorMessage;
  final FrameStreamState frameState;
  final VisionAnalysisState visionState;
  final GestureRecognitionState gestureState;
  final VoiceAssistantState voiceState;
  final TryOnState tryOnState;
  final bool showTrackingOverlay;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    switch (loadState) {
      case _LoadState.idle:
      case _LoadState.initializing:
        return const Center(
          child: CircularProgressIndicator(color: Colors.white),
        );

      case _LoadState.error:
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: AppColors.error, size: 40),
                const SizedBox(height: AppSpacing.sm),
                Text(
                  errorMessage ?? 'Something went wrong starting the camera.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: AppSpacing.md),
                FilledButton(onPressed: onRetry, child: const Text('Retry')),
              ],
            ),
          ),
        );

      case _LoadState.ready:
        final CameraController? controller =
            ref.watch(cameraRepositoryProvider).controller;
        if (controller == null || !controller.value.isInitialized) {
          return const Center(
            child: CircularProgressIndicator(color: Colors.white),
          );
        }
        return Stack(
          fit: StackFit.expand,
          children: [
            // Preview and every overlay share this exact same local
            // coordinate space (a fixed-size box at the camera's native
            // aspect ratio) so image-space coordinates (mapped via
            // CoordinateTranslator in both Module 5's VisionOverlay and
            // Module 8's TryOnOverlay) line up with what's actually
            // rendered. `FittedBox(fit: BoxFit.cover)` then scales that
            // whole box up to fill the screen -- cropping whatever
            // doesn't fit, the same way a real mirror doesn't letterbox
            // -- rather than `AspectRatio` centering a smaller box with
            // black bars. The overlays' own coordinate math is untouched
            // by this: FittedBox only changes how the already-laid-out
            // box is displayed, not the local coordinate space the
            // overlays paint into.
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: 1000,
                  height: 1000 / controller.value.aspectRatio,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      MirroredCameraPreview(controller: controller),
                      TryOnOverlay(controller: controller, state: tryOnState),
                      if (showTrackingOverlay)
                        VisionOverlay(controller: controller, state: visionState),
                    ],
                  ),
                ),
              ),
            ),
            CameraHudOverlay(
              fps: frameState.fps,
              isStreaming: frameState.isStreaming,
              visionState: visionState,
              gestureState: gestureState,
              voiceState: voiceState,
            ),
            VoiceTranscriptBanner(
              isListening: voiceState.isListening,
              partialText: voiceState.partialText,
            ),
          ],
        );
    }
  }
}