import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/flutter_tts_datasource.dart';
import '../../data/datasources/speech_to_text_datasource.dart';
import '../../data/repositories/speech_recognition_repository_impl.dart';
import '../../data/repositories/text_to_speech_repository_impl.dart';
import '../../domain/repositories/speech_recognition_repository.dart';
import '../../domain/repositories/text_to_speech_repository.dart';

final speechToTextDataSourceProvider =
    Provider<SpeechToTextDataSource>((ref) => SpeechToTextDataSource());

final flutterTtsDataSourceProvider =
    Provider<FlutterTtsDataSource>((ref) => FlutterTtsDataSource());

final speechRecognitionRepositoryProvider = Provider<SpeechRecognitionRepository>((ref) {
  return SpeechRecognitionRepositoryImpl(ref.watch(speechToTextDataSourceProvider));
});

final textToSpeechRepositoryProvider = Provider<TextToSpeechRepository>((ref) {
  return TextToSpeechRepositoryImpl(ref.watch(flutterTtsDataSourceProvider));
});
