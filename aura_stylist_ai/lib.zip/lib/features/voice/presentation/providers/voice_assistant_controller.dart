import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/permissions/app_permission.dart';
import '../../../../core/permissions/permission_providers.dart';
import '../../../../core/theme/theme_provider.dart';
import '../../../settings/presentation/providers/settings_providers.dart';
import '../../../tryon/presentation/providers/try_on_session_controller.dart';
import '../../domain/entities/speech_recognition_event.dart';
import '../../domain/entities/voice_command.dart';
import '../../domain/services/voice_command_parser.dart';
import 'voice_providers.dart';

class VoiceAssistantState {
  const VoiceAssistantState({
    this.permissionState = AppPermissionState.unknown,
    this.isListening = false,
    this.isInitializing = false,
    this.partialText = '',
    this.lastCommand,
    this.lastResponse,
    this.errorMessage,
  });

  final AppPermissionState permissionState;
  final bool isListening;
  final bool isInitializing;
  final String partialText;
  final VoiceCommand? lastCommand;
  final String? lastResponse;
  final String? errorMessage;

  VoiceAssistantState copyWith({
    AppPermissionState? permissionState,
    bool? isListening,
    bool? isInitializing,
    String? partialText,
    VoiceCommand? lastCommand,
    String? lastResponse,
    String? errorMessage,
  }) {
    return VoiceAssistantState(
      permissionState: permissionState ?? this.permissionState,
      isListening: isListening ?? this.isListening,
      isInitializing: isInitializing ?? this.isInitializing,
      partialText: partialText ?? this.partialText,
      lastCommand: lastCommand ?? this.lastCommand,
      lastResponse: lastResponse ?? this.lastResponse,
      errorMessage: errorMessage,
    );
  }
}

/// Orchestrates the full voice loop: mic permission -> listen -> parse ->
/// (real action, where one exists) -> spoken confirmation via TTS -> keep
/// listening. See `_applyRealAction` for which commands get real
/// behavior directly here vs. at the UI layer.
class VoiceAssistantController extends StateNotifier<VoiceAssistantState> {
  VoiceAssistantController(this._ref) : super(const VoiceAssistantState()) {
    _checkPermission();
  }

  final Ref _ref;
  StreamSubscription<SpeechRecognitionEvent>? _subscription;
  static const _parser = VoiceCommandParser();

  Future<void> _checkPermission() async {
    final status =
        await _ref.read(permissionGatewayProvider).checkStatus(AppPermission.microphone);
    if (mounted) state = state.copyWith(permissionState: status);
  }

  Future<void> requestPermission() async {
    final status =
        await _ref.read(permissionGatewayProvider).request(AppPermission.microphone);
    if (mounted) state = state.copyWith(permissionState: status);
  }

  Future<void> openSettings() => _ref.read(permissionGatewayProvider).openSettings();

  Future<void> start() async {
    if (state.permissionState != AppPermissionState.granted) return;
    if (state.isListening || state.isInitializing) return;

    state = state.copyWith(isInitializing: true, errorMessage: null);

    final speechRepo = _ref.read(speechRecognitionRepositoryProvider);
    final ttsRepo = _ref.read(textToSpeechRepositoryProvider);

    final speechInit = await speechRepo.initialize();
    final ttsInit = await ttsRepo.initialize();

    if (speechInit.isFailure || ttsInit.isFailure) {
      final message = speechInit.when(
        success: (_) => ttsInit.when(success: (_) => null, failure: (f) => f.message),
        failure: (f) => f.message,
      );
      if (mounted) {
        state = state.copyWith(isInitializing: false, errorMessage: message);
      }
      return;
    }

    if (speechInit.valueOrNull == false) {
      if (mounted) {
        state = state.copyWith(
          isInitializing: false,
          errorMessage: 'Speech recognition is not available on this device.',
        );
      }
      return;
    }

    _subscription?.cancel();
    _subscription = speechRepo.events.listen(_onSpeechEvent);

    final listenResult = await speechRepo.startListening();
    if (!mounted) return;

    state = listenResult.when(
      success: (_) => state.copyWith(isInitializing: false, isListening: true),
      failure: (f) => state.copyWith(isInitializing: false, errorMessage: f.message),
    );
  }

  Future<void> stop() async {
    await _subscription?.cancel();
    _subscription = null;
    await _ref.read(speechRecognitionRepositoryProvider).stopListening();
    if (mounted) {
      state = state.copyWith(isListening: false, isInitializing: false, partialText: '');
    }
  }

  void _onSpeechEvent(SpeechRecognitionEvent event) {
    if (!mounted) return;

    if (!event.isFinal) {
      state = state.copyWith(partialText: event.recognizedText);
      return;
    }

    final command = _parser.parse(event.recognizedText);
    final response = _buildResponse(command);
    state = state.copyWith(
      partialText: '',
      lastCommand: command,
      lastResponse: response,
    );

    _applyRealAction(command);
    if (_ref.read(voiceSettingsProvider)) {
      _ref.read(textToSpeechRepositoryProvider).speak(response);
    }

    // Most speech_to_text configurations stop listening once a final
    // result comes in — restart automatically so the assistant keeps
    // listening continuously until the user (or a gesture) explicitly
    // stops it, rather than requiring a fresh tap per command.
    if (state.isListening) {
      _ref.read(speechRecognitionRepositoryProvider).startListening();
    }
  }

  String _buildResponse(VoiceCommand command) {
    if (command.type == VoiceCommandType.unknown) {
      return "Sorry, I didn't catch a command in that.";
    }
    if (command.type.isImplemented) {
      return 'Okay, ${command.type.label.toLowerCase()}.';
    }
    return '${command.type.label} recognized. That arrives in ${command.type.owningModule}.';
  }

  /// Dark Mode and Light Mode are applied directly here since they're
  /// simple, global, and don't need a `BuildContext` — same for Reset,
  /// which just clears Module 8's try-on session state. "Exit", "Open
  /// Wardrobe", and "Close Wardrobe" are deliberately **not** handled
  /// here — they need a `BuildContext`/router (navigation, showing a
  /// bottom sheet), so `SmartCameraPage` listens for those command types
  /// and handles them at the UI layer, the same pattern used for
  /// gesture-driven actions.
  void _applyRealAction(VoiceCommand command) {
    switch (command.type) {
      case VoiceCommandType.darkMode:
        _ref.read(themeModeProvider.notifier).setDark();
        break;
      case VoiceCommandType.lightMode:
        _ref.read(themeModeProvider.notifier).setLight();
        break;
      case VoiceCommandType.reset:
        _ref.read(tryOnSessionControllerProvider.notifier).reset();
        break;
      default:
        break; // handled by the UI layer, or has no target module yet
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}

final voiceAssistantControllerProvider =
    StateNotifierProvider.autoDispose<VoiceAssistantController, VoiceAssistantState>(
  (ref) => VoiceAssistantController(ref),
);
