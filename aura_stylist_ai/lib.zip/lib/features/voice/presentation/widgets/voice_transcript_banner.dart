import 'package:flutter/material.dart';

import '../../../../core/theme/app_tokens.dart';
import '../../../../core/widgets/glass_container.dart';

/// Shown at the bottom of the Smart Mirror screen while the voice
/// assistant is actively listening, echoing back the partial transcript
/// so the user can see what's being heard in real time.
class VoiceTranscriptBanner extends StatelessWidget {
  const VoiceTranscriptBanner({
    super.key,
    required this.isListening,
    required this.partialText,
  });

  final bool isListening;
  final String partialText;

  @override
  Widget build(BuildContext context) {
    if (!isListening) return const SizedBox.shrink();

    return Positioned(
      left: AppSpacing.md,
      right: AppSpacing.md,
      bottom: AppSpacing.lg,
      child: GlassContainer(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.sm,
        ),
        blurSigma: 12,
        child: Row(
          children: [
            const Icon(Icons.mic_rounded, size: 18, color: Colors.white),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              child: Text(
                partialText.isEmpty ? 'Listening...' : partialText,
                style: const TextStyle(color: Colors.white),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
