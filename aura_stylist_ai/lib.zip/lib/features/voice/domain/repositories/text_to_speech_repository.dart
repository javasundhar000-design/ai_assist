import '../../../../core/utils/result.dart';

abstract class TextToSpeechRepository {
  Future<Result<void>> initialize();
  Future<Result<void>> speak(String text);
  Future<Result<void>> stop();
}
