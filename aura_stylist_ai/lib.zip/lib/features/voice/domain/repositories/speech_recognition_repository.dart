import '../../../../core/utils/result.dart';
import '../entities/speech_recognition_event.dart';

abstract class SpeechRecognitionRepository {
  /// Partial and final transcript updates while listening.
  Stream<SpeechRecognitionEvent> get events;

  bool get isListening;

  /// Checks device support and prepares the recognizer. `Success(true)`
  /// means speech recognition is available on this device; `Success(false)`
  /// means the plugin initialized without error but the device/OS doesn't
  /// actually support it (e.g. no recognition service installed).
  Future<Result<bool>> initialize();

  Future<Result<void>> startListening({String localeId = 'en_US'});

  Future<Result<void>> stopListening();

  Future<void> dispose();
}
