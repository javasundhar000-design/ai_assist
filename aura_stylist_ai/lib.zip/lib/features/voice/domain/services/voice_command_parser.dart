import '../entities/voice_command.dart';

/// Parses a raw speech-to-text transcript into a `VoiceCommand`.
///
/// Pure keyword/phrase matching — no NLP model, no plugin dependencies.
/// Speech-to-text transcripts are noisy and rarely exact, so matching is
/// deliberately loose (substring `contains`, not exact equality) rather
/// than requiring the user say a phrase perfectly. This is a heuristic
/// parser, not a trained intent classifier — see the module README for
/// where it's likely to misfire (e.g. a category name that happens to
/// contain another keyword).
class VoiceCommandParser {
  const VoiceCommandParser();

  static const _colors = [
    'blue', 'black', 'red', 'green', 'white', 'pink', 'yellow', 'brown',
    'grey', 'gray', 'navy', 'beige', 'maroon', 'purple', 'orange', 'teal',
    'olive', 'gold', 'silver',
  ];

  static const _categories = [
    'shirts', 'shirt', 'jackets', 'jacket', 'blazers', 'blazer', 'kurtas',
    'kurta', 'sarees', 'saree', 'lehengas', 'lehenga', 'dresses', 'dress',
    'jeans', 'pants', 'shoes', 'glasses', 'hats', 'hat', 'hoodies', 'hoodie',
    't-shirts', 't-shirt', 'tshirts', 'tshirt', 'accessories', 'casual',
    'formal', 'traditional',
  ];

  static const _occasionKeywords = [
    'interview', 'wedding', 'college', 'party', 'office', 'casual', 'formal',
  ];

  VoiceCommand parse(String rawText) {
    final text = rawText.toLowerCase().trim();
    if (text.isEmpty) {
      return VoiceCommand(type: VoiceCommandType.unknown, rawText: rawText);
    }

    // Fixed short commands, checked before the open-ended "show"/
    // "recommend" patterns so e.g. "reset" can't accidentally be
    // swallowed by a looser match.
    if (_matches(text, const ['dark mode'])) {
      return VoiceCommand(type: VoiceCommandType.darkMode, rawText: rawText);
    }
    if (_matches(text, const ['light mode'])) {
      return VoiceCommand(type: VoiceCommandType.lightMode, rawText: rawText);
    }
    if (_matches(text, const ['open wardrobe'])) {
      return VoiceCommand(type: VoiceCommandType.openWardrobe, rawText: rawText);
    }
    if (_matches(text, const ['close wardrobe'])) {
      return VoiceCommand(type: VoiceCommandType.closeWardrobe, rawText: rawText);
    }
    if (_matches(text, const ['capture', 'take a photo', 'take photo'])) {
      return VoiceCommand(type: VoiceCommandType.capture, rawText: rawText);
    }
    if (_matches(text, const ['save'])) {
      return VoiceCommand(type: VoiceCommandType.save, rawText: rawText);
    }
    if (_matches(text, const ['share'])) {
      return VoiceCommand(type: VoiceCommandType.share, rawText: rawText);
    }
    if (_matches(text, const ['next'])) {
      return VoiceCommand(type: VoiceCommandType.next, rawText: rawText);
    }
    if (_matches(text, const ['previous', 'go back'])) {
      return VoiceCommand(type: VoiceCommandType.previous, rawText: rawText);
    }
    if (_matches(text, const ['reset'])) {
      return VoiceCommand(type: VoiceCommandType.reset, rawText: rawText);
    }
    if (_matches(text, const ['exit', 'quit', 'close mirror', 'stop mirror'])) {
      return VoiceCommand(type: VoiceCommandType.exit, rawText: rawText);
    }

    if (text.startsWith('recommend') && text.contains('outfit')) {
      return VoiceCommand(
        type: VoiceCommandType.recommendOutfit,
        rawText: rawText,
        occasion: _extractOccasion(text),
      );
    }

    if (text.startsWith('show')) {
      final remainder = text.replaceFirst('show', '').trim();
      final color = _firstMatch(_colors, remainder);
      final category = _firstMatch(_categories, remainder);
      return VoiceCommand(
        type: VoiceCommandType.showItems,
        rawText: rawText,
        color: color,
        // Falls back to the raw remainder if it doesn't match the known
        // category list — the real clothing catalog (Module 8) is
        // open-ended, so an unrecognized-but-present category phrase is
        // still useful information rather than nothing.
        category: category ?? (remainder.isEmpty ? null : remainder),
      );
    }

    return VoiceCommand(type: VoiceCommandType.unknown, rawText: rawText);
  }

  /// A phrase "matches" if every word in it appears somewhere in the
  /// transcript, in any order, with any other words mixed in around them
  /// — not just as one exact contiguous substring. Speech-to-text output
  /// is natural spoken language ("can you open the wardrobe please"), not
  /// a scripted command, so requiring "open wardrobe" to sit
  /// back-to-back was silently failing on almost every real phrasing.
  /// Whole-word comparison (via a word-boundary split) avoids the
  /// opposite problem — a raw substring check would let "reset" match
  /// inside "presets" — while still being tolerant of filler words.
  bool _matches(String text, List<String> phrases) {
    final textWords = _words(text).toSet();
    return phrases.any((phrase) {
      final phraseWords = _words(phrase);
      return phraseWords.every(textWords.contains);
    });
  }

  List<String> _words(String text) =>
      text.split(RegExp(r'[^a-z0-9]+')).where((w) => w.isNotEmpty).toList();

  String? _firstMatch(List<String> options, String text) {
    for (final option in options) {
      if (text.contains(option)) return option;
    }
    return null;
  }

  String? _extractOccasion(String text) {
    final keyword = _firstMatch(_occasionKeywords, text);
    if (keyword != null) return keyword;

    // Fallback: whatever word sits between "recommend" and "outfit".
    final match = RegExp(r'recommend\s+(\w+)\s+outfit').firstMatch(text);
    return match?.group(1);
  }
}