/// A single speech-recognition update — either a partial (still being
/// refined as the user keeps talking) or final transcript.
class SpeechRecognitionEvent {
  const SpeechRecognitionEvent({
    required this.recognizedText,
    required this.isFinal,
    required this.confidence,
  });

  final String recognizedText;
  final bool isFinal;

  /// 0-1, as reported by the speech engine. Not always meaningful on every
  /// platform (some return 1.0 unconditionally) — treat as a rough signal.
  final double confidence;
}
