/// The command categories from the spec's "VOICE COMMANDS" section.
/// Color/category/occasion details for "Show X" and "Recommend X outfit"
/// are captured as parameters on `VoiceCommand`, not as separate enum
/// values — there's an open-ended catalog of colors/categories/occasions,
/// not a fixed small set.
enum VoiceCommandType {
  showItems,
  recommendOutfit,
  capture,
  save,
  share,
  next,
  previous,
  reset,
  darkMode,
  lightMode,
  openWardrobe,
  closeWardrobe,
  exit,
  unknown,
}

extension VoiceCommandTypeMeta on VoiceCommandType {
  String get label => switch (this) {
        VoiceCommandType.showItems => 'Show Items',
        VoiceCommandType.recommendOutfit => 'Recommend Outfit',
        VoiceCommandType.capture => 'Capture',
        VoiceCommandType.save => 'Save',
        VoiceCommandType.share => 'Share',
        VoiceCommandType.next => 'Next',
        VoiceCommandType.previous => 'Previous',
        VoiceCommandType.reset => 'Reset',
        VoiceCommandType.darkMode => 'Dark Mode',
        VoiceCommandType.lightMode => 'Light Mode',
        VoiceCommandType.openWardrobe => 'Open Wardrobe',
        VoiceCommandType.closeWardrobe => 'Close Wardrobe',
        VoiceCommandType.exit => 'Exit',
        VoiceCommandType.unknown => 'Unrecognized',
      };

  /// Whether this build actually performs the action, vs. just
  /// acknowledging that the command was understood. Mirrors `GestureType.
  /// isImplemented`'s honesty pattern: Dark Mode, Light Mode, and Exit
  /// were wired to real behavior in Module 7; Reset, Open Wardrobe, and
  /// Close Wardrobe became real in Module 8; Show Items and Recommend
  /// Outfit became real in Module 9, once there was an actual
  /// recommendation engine and catalog search to run. Only Capture,
  /// Save, and Share remain unimplemented — they need the photo-capture
  /// pipeline this build doesn't include.
  bool get isImplemented => switch (this) {
        VoiceCommandType.darkMode ||
        VoiceCommandType.lightMode ||
        VoiceCommandType.exit ||
        VoiceCommandType.reset ||
        VoiceCommandType.openWardrobe ||
        VoiceCommandType.closeWardrobe ||
        VoiceCommandType.showItems ||
        VoiceCommandType.recommendOutfit ||
        VoiceCommandType.save ||
        VoiceCommandType.next ||
        VoiceCommandType.previous =>
          true,
        _ => false,
      };

  /// Which module will implement the real behavior for a command that
  /// isn't wired up yet. Null once `isImplemented` is true.
  ///
  /// `save`/`next`/`previous` became real in Module 10, once
  /// `WardrobeController` existed to save to and cycle through — see
  /// `SmartCameraPage`'s voice dispatch.
  String? get owningModule => switch (this) {
        VoiceCommandType.capture || VoiceCommandType.share =>
          'Photo Capture (planned, not yet built)',
        VoiceCommandType.save ||
        VoiceCommandType.next ||
        VoiceCommandType.previous ||
        VoiceCommandType.showItems ||
        VoiceCommandType.recommendOutfit ||
        VoiceCommandType.reset ||
        VoiceCommandType.openWardrobe ||
        VoiceCommandType.closeWardrobe ||
        VoiceCommandType.darkMode ||
        VoiceCommandType.lightMode ||
        VoiceCommandType.exit ||
        VoiceCommandType.unknown =>
          null,
      };
}

/// One parsed voice command, with whatever category/color/occasion
/// details `VoiceCommandParser` was able to extract from the raw
/// transcript alongside it.
class VoiceCommand {
  const VoiceCommand({
    required this.type,
    required this.rawText,
    this.color,
    this.category,
    this.occasion,
  });

  final VoiceCommandType type;
  final String rawText;

  /// e.g. "blue" from "show blue shirts" (showItems only).
  final String? color;

  /// e.g. "shirts" from "show blue shirts" (showItems only).
  final String? category;

  /// e.g. "interview" from "recommend interview outfit" (recommendOutfit only).
  final String? occasion;
}
