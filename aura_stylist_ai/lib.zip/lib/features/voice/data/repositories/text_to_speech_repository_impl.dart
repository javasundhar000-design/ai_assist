import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../../domain/repositories/text_to_speech_repository.dart';
import '../datasources/flutter_tts_datasource.dart';

class TextToSpeechRepositoryImpl implements TextToSpeechRepository {
  TextToSpeechRepositoryImpl(this._dataSource);

  final FlutterTtsDataSource _dataSource;

  @override
  Future<Result<void>> initialize() async {
    try {
      await _dataSource.initialize();
      return const Success(null);
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> speak(String text) async {
    try {
      await _dataSource.speak(text);
      return const Success(null);
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> stop() async {
    try {
      await _dataSource.stop();
      return const Success(null);
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }
}
