import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/speech_recognition_event.dart';
import '../../domain/repositories/speech_recognition_repository.dart';
import '../datasources/speech_to_text_datasource.dart';

class SpeechRecognitionRepositoryImpl implements SpeechRecognitionRepository {
  SpeechRecognitionRepositoryImpl(this._dataSource);

  final SpeechToTextDataSource _dataSource;

  @override
  Stream<SpeechRecognitionEvent> get events => _dataSource.events;

  @override
  bool get isListening => _dataSource.isListening;

  @override
  Future<Result<bool>> initialize() async {
    try {
      final available = await _dataSource.initialize();
      return Success(available);
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> startListening({String localeId = 'en_US'}) async {
    try {
      await _dataSource.startListening(localeId: localeId);
      return const Success(null);
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Result<void>> stopListening() async {
    try {
      await _dataSource.stopListening();
      return const Success(null);
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<void> dispose() => _dataSource.dispose();
}
