import 'dart:async';

import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../../domain/entities/speech_recognition_event.dart';

/// Raw access to the `speech_to_text` plugin.
///
/// ⚠️ Version note: `speech_to_text`'s `listen()` API has changed shape
/// across major versions — older releases took `partialResults`/
/// `cancelOnError`/`listenMode` as direct named parameters, while recent
/// ones (pinned here, ^7.0.0) group them into a `SpeechListenOptions`
/// object, used below. If `flutter pub get` resolves a version where this
/// doesn't compile, swap the `listenOptions:` line for the classic form:
/// `partialResults: true, cancelOnError: true, listenMode: stt.ListenMode.confirmation`
/// passed directly to `listen()` instead.
class SpeechToTextDataSource {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final _controller = StreamController<SpeechRecognitionEvent>.broadcast();
  bool _isInitialized = false;

  Stream<SpeechRecognitionEvent> get events => _controller.stream;

  bool get isListening => _speech.isListening;

  Future<bool> initialize() async {
    if (_isInitialized) return true;
    _isInitialized = await _speech.initialize(
      onError: (error) => _controller.addError(error.errorMsg),
      onStatus: (_) {}, // listening/notListening/done — not needed beyond events themselves
    );
    return _isInitialized;
  }

  Future<void> startListening({String localeId = 'en_US'}) async {
    if (!_isInitialized) return;
    await _speech.listen(
      onResult: (result) {
        _controller.add(SpeechRecognitionEvent(
          recognizedText: result.recognizedWords,
          isFinal: result.finalResult,
          confidence: result.confidence,
        ));
      },
      localeId: localeId,
      listenOptions: stt.SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        listenMode: stt.ListenMode.confirmation,
      ),
    );
  }

  Future<void> stopListening() => _speech.stop();

  Future<void> dispose() async {
    await _speech.cancel();
    await _controller.close();
  }
}
