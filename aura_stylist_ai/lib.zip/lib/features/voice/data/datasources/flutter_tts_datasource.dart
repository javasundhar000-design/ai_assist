import 'package:flutter_tts/flutter_tts.dart';

/// Raw access to the `flutter_tts` plugin.
class FlutterTtsDataSource {
  final FlutterTts _tts = FlutterTts();
  bool _isInitialized = false;

  Future<void> initialize() async {
    if (_isInitialized) return;
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.5);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);
    _isInitialized = true;
  }

  Future<void> speak(String text) => _tts.speak(text);

  Future<void> stop() => _tts.stop();

  Future<void> setLanguage(String languageCode) => _tts.setLanguage(languageCode);

  Future<void> setSpeechRate(double rate) => _tts.setSpeechRate(rate);
}
