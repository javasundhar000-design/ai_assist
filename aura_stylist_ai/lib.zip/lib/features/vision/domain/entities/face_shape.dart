/// The five face-shape categories from the spec.
enum FaceShape { oval, round, square, heart, diamond }

extension FaceShapeLabel on FaceShape {
  String get label => switch (this) {
        FaceShape.oval => 'Oval',
        FaceShape.round => 'Round',
        FaceShape.square => 'Square',
        FaceShape.heart => 'Heart',
        FaceShape.diamond => 'Diamond',
      };
}
