import '../services/color_science.dart';


/// The six skin-tone categories from the spec.
enum SkinTone { fair, light, medium, olive, brown, dark }

extension SkinToneLabel on SkinTone {
  String get label => switch (this) {
        SkinTone.fair => 'Fair',
        SkinTone.light => 'Light',
        SkinTone.medium => 'Medium',
        SkinTone.olive => 'Olive',
        SkinTone.brown => 'Brown',
        SkinTone.dark => 'Dark',
      };

  /// Starter palette suggestion per tone (spec: "Recommend suitable
  /// colors"). This is a simple, commonly-cited starting mapping — Module 9
  /// (Recommendation Engine) builds the real occasion/outfit-aware
  /// recommendation logic on top of this; treat this list as a sensible
  /// default, not the final word.
  List<String> get recommendedColors => switch (this) {
        SkinTone.fair => const ['Navy', 'Emerald', 'Burgundy', 'Cool Gray'],
        SkinTone.light => const ['Soft Pink', 'Periwinkle', 'Sage Green', 'Charcoal'],
        SkinTone.medium => const ['Coral', 'Teal', 'Mustard', 'Warm Brown'],
        SkinTone.olive => const ['Olive Green', 'Terracotta', 'Cream', 'Deep Purple'],
        SkinTone.brown => const ['Amber', 'Royal Blue', 'Ivory', 'Rust'],
        SkinTone.dark => const ['Bright White', 'Fuchsia', 'Cobalt Blue', 'Gold'],
      };
}

/// Parses a `SkinTone.label` string back into the enum — used by Module 9
/// to convert a stored `UserProfile.skinTone` or a live
/// `VisionAnalysisState.skinToneSample?.tone.label` back into a `SkinTone`
/// for the recommendation engine.
extension SkinToneParsing on SkinTone {
  static SkinTone? fromLabel(String label) {
    for (final tone in SkinTone.values) {
      if (tone.label == label) return tone;
    }
    return null;
  }
}

/// The result of one skin-tone analysis pass: the averaged, validated
/// color sample plus the classified tone. Kept around (not just the enum)
/// so the HUD/debug UI can show the underlying RGB/HSV/LAB values the spec
/// explicitly asks for.
class SkinToneSample {
  const SkinToneSample({
    required this.tone,
    required this.averageColor,
    required this.validSampleCount,
    required this.totalSampleCount,
  });

  final SkinTone tone;
  final ColorSample averageColor;

  /// How many of the sampled pixels passed the highlight/shadow filter
  /// and were used in the average.
  final int validSampleCount;
  final int totalSampleCount;
}
