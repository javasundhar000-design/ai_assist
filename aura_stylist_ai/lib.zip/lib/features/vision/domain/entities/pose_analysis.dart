import 'dart:ui';

/// A single tracked body point, decoupled from ML Kit's `PoseLandmark`.
class PoseKeypoint {
  const PoseKeypoint({
    required this.x,
    required this.y,
    required this.z,
    required this.likelihood,
  });

  /// Image-pixel-space coordinates.
  final double x;
  final double y;

  /// ML Kit's relative depth estimate (negative = closer to the camera
  /// than the hips, roughly) — not a calibrated real-world distance.
  final double z;

  /// 0-1 confidence for this specific point.
  final double likelihood;

  Offset get offset => Offset(x, y);
}

/// The subset of ML Kit's 33 pose landmarks this app tracks, matching the
/// spec's "POSE DETECTION" list (head/shoulders/elbows/wrists/hips/knees/
/// ankles — "neck", "chest", and "waist" are derived midpoints rather than
/// direct ML Kit landmarks, computed in `BodyMetricsCalculator`).
enum PoseLandmarkKind {
  nose,
  leftShoulder,
  rightShoulder,
  leftElbow,
  rightElbow,
  leftWrist,
  rightWrist,
  leftHip,
  rightHip,
  leftKnee,
  rightKnee,
  leftAnkle,
  rightAnkle,
}

class PoseAnalysis {
  const PoseAnalysis({required this.landmarks, required this.imageSize});

  final Map<PoseLandmarkKind, PoseKeypoint> landmarks;
  final Size imageSize;

  PoseKeypoint? operator [](PoseLandmarkKind kind) => landmarks[kind];
}
