/// The four body-type categories from the spec.
enum BodyType { slim, athletic, average, broad }

extension BodyTypeLabel on BodyType {
  String get label => switch (this) {
        BodyType.slim => 'Slim',
        BodyType.athletic => 'Athletic',
        BodyType.average => 'Average',
        BodyType.broad => 'Broad',
      };
}

/// Parses a `BodyType.label` string back into the enum — used by Module 9
/// the same way `SkinToneParsing` is.
extension BodyTypeParsing on BodyType {
  static BodyType? fromLabel(String label) {
    for (final type in BodyType.values) {
      if (type.label == label) return type;
    }
    return null;
  }
}

/// Which way the body is currently turned relative to the camera, derived
/// from shoulder depth asymmetry (see `BodyMetricsCalculator`). Used to
/// gate the virtual try-on overlay in a later module — clothing shouldn't
/// render as if facing the camera when the user has turned away.
enum BodyOrientation { facingCamera, turnedLeft, turnedRight, turnedAway, unknown }

/// Geometric measurements derived from one pose frame, matching the spec's
/// "Calculate: Shoulder Width, Hip Width, Body Rotation, Body Orientation,
/// Torso Height".
class BodyMetrics {
  const BodyMetrics({
    required this.shoulderWidth,
    required this.hipWidth,
    required this.torsoHeight,
    required this.shoulderToHipRatio,
    required this.bodyRotationDegrees,
    required this.orientation,
  });

  /// All distances are in image-pixel space (not real-world units — there's
  /// no calibrated scale without a reference object or depth sensor), so
  /// they're only meaningful as *ratios* to each other, which is exactly
  /// what `BodyTypeEstimator` uses them for.
  final double shoulderWidth;
  final double hipWidth;
  final double torsoHeight;
  final double shoulderToHipRatio;

  /// Heuristic yaw estimate, in degrees (-90 = fully turned one way,
  /// 0 = square to the camera, +90 = fully turned the other way). See
  /// `BodyMetricsCalculator` for the (documented, approximate) derivation.
  final double bodyRotationDegrees;

  final BodyOrientation orientation;
}
