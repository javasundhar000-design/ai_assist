import 'dart:ui';

/// The subset of ML Kit's face landmarks this app uses, given its own
/// names so the domain layer never has to import `google_mlkit_face_detection`
/// types directly (mapping happens once, in `data/mappers/face_mapper.dart`).
enum FaceLandmarkKind {
  leftEye,
  rightEye,
  leftEar,
  rightEar,
  leftCheek,
  rightCheek,
  noseBase,
  leftMouth,
  rightMouth,
  bottomMouth,
}

/// Contour point sets ("Eyebrows", "Cheeks", "Mouth" as continuous outlines
/// rather than single points) — only available when ML Kit's contour
/// detection is enabled (see `FaceDetectorDataSource`).
enum FaceContourKind {
  face,
  leftEyebrowTop,
  leftEyebrowBottom,
  rightEyebrowTop,
  rightEyebrowBottom,
  leftEye,
  rightEye,
  upperLipTop,
  upperLipBottom,
  lowerLipTop,
  lowerLipBottom,
  noseBridge,
  noseBottom,
}

/// One detected face, normalized into this app's own vocabulary. Matches
/// the spec's "FACE DETECTION" section: bounding box, landmarks (eyes,
/// nose, cheeks, mouth), eyebrows (via contours), head rotation, and an
/// approximate confidence.
class FaceAnalysis {
  const FaceAnalysis({
    required this.boundingBox,
    required this.landmarks,
    required this.contours,
    required this.headEulerAngleX,
    required this.headEulerAngleY,
    required this.headEulerAngleZ,
    required this.imageSize,
    this.smilingProbability,
    this.leftEyeOpenProbability,
    this.rightEyeOpenProbability,
    this.trackingId,
  });

  final Rect boundingBox;
  final Map<FaceLandmarkKind, Offset> landmarks;
  final Map<FaceContourKind, List<Offset>> contours;

  /// Pitch (nod up/down), in degrees.
  final double headEulerAngleX;

  /// Yaw (turn left/right), in degrees.
  final double headEulerAngleY;

  /// Roll (tilt side to side), in degrees — this is "Face Angle" in the spec.
  final double headEulerAngleZ;

  final double? smilingProbability;
  final double? leftEyeOpenProbability;
  final double? rightEyeOpenProbability;
  final int? trackingId;

  /// Full camera-frame size (in image pixel space) this face was detected
  /// against — needed to map landmark coordinates onto the preview widget.
  final Size imageSize;

  /// ML Kit doesn't expose a single overall "detection confidence" number
  /// for a face the way it does for e.g. object detection. This is a
  /// practical proxy — the fraction of the core landmarks (eyes, nose,
  /// mouth, cheeks, ears) that were actually located — used only to give
  /// the HUD *something* to show under "Face Confidence"; it is not an
  /// official ML Kit metric.
  double get landmarkCompleteness {
    const expected = FaceLandmarkKind.values;
    if (expected.isEmpty) return 0;
    final found = expected.where(landmarks.containsKey).length;
    return found / expected.length;
  }
}
