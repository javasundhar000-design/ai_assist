import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../../../core/utils/result.dart';
import '../entities/face_analysis.dart';

/// Pragmatic exception to strict layering (same reasoning as
/// `CameraRepository.controller`): this takes ML Kit's `InputImage` type
/// directly rather than hiding it behind another abstraction, since
/// `InputImage` *is* the interchange format between the camera pipeline
/// and every ML Kit detector — there's nothing meaningful to abstract away.
abstract class FaceDetectorRepository {
  /// Runs face detection and returns the largest/most prominent detected
  /// face (there's normally exactly one subject in front of the Smart
  /// Mirror), or `null` if none was found.
  Future<Result<FaceAnalysis?>> detectPrimaryFace(InputImage inputImage);

  Future<void> dispose();
}
