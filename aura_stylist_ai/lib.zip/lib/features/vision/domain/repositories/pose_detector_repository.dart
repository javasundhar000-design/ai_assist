import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../../../core/utils/result.dart';
import '../entities/pose_analysis.dart';

abstract class PoseDetectorRepository {
  /// Runs pose detection and returns the detected pose, or `null` if no
  /// body was found in the frame.
  Future<Result<PoseAnalysis?>> detectPose(InputImage inputImage);

  Future<void> dispose();
}
