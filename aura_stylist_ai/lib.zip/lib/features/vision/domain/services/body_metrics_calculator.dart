import 'dart:math' as math;

import '../entities/body_metrics.dart';
import '../entities/pose_analysis.dart';

/// Derives `BodyMetrics` from one `PoseAnalysis` frame, per the spec's
/// "POSE DETECTION" section ("Calculate: Shoulder Width, Hip Width, Body
/// Rotation, Body Orientation, Torso Height").
///
/// All distances are in image-pixel space — there's no calibrated
/// real-world scale available from a single 2D camera frame without a
/// reference object or depth sensor, so only *ratios* between these
/// measurements (shoulder-to-hip, etc.) are meaningful, never absolute
/// values.
class BodyMetricsCalculator {
  const BodyMetricsCalculator();

  /// Minimum per-landmark confidence required before trusting a point for
  /// measurement — below this, ML Kit itself is uncertain where the joint
  /// actually is, and using it would just inject noise.
  static const _minLikelihood = 0.5;

  BodyMetrics? calculate(PoseAnalysis pose) {
    final leftShoulder = pose[PoseLandmarkKind.leftShoulder];
    final rightShoulder = pose[PoseLandmarkKind.rightShoulder];
    final leftHip = pose[PoseLandmarkKind.leftHip];
    final rightHip = pose[PoseLandmarkKind.rightHip];

    final points = [leftShoulder, rightShoulder, leftHip, rightHip];
    if (points.any((p) => p == null || p.likelihood < _minLikelihood)) {
      return null;
    }

    final shoulderWidth = _distance2D(leftShoulder!, rightShoulder!);
    final hipWidth = _distance2D(leftHip!, rightHip!);
    final shoulderMidY = (leftShoulder.y + rightShoulder.y) / 2;
    final hipMidY = (leftHip.y + rightHip.y) / 2;
    final torsoHeight = (hipMidY - shoulderMidY).abs();

    // Rough yaw estimate: ML Kit's landmark `z` is a relative depth
    // (roughly, negative = closer to the camera than the hip center). A
    // meaningfully asymmetric z between the two shoulders means the body
    // has rotated rather than facing the camera square-on. The `* 45`
    // scale factor is an empirical heuristic (not a calibrated
    // measurement) chosen so a fully-turned shoulder maps to roughly
    // +/-90 degrees; it has not been validated against real rotation
    // angles and should be treated as a rough directional signal only.
    final shoulderZDiff = leftShoulder.z - rightShoulder.z;
    final bodyRotationDegrees = (shoulderZDiff * 45).clamp(-90.0, 90.0);

    final BodyOrientation orientation;
    if (bodyRotationDegrees.abs() < 12) {
      orientation = BodyOrientation.facingCamera;
    } else if (bodyRotationDegrees > 0) {
      orientation = BodyOrientation.turnedRight;
    } else {
      orientation = BodyOrientation.turnedLeft;
    }

    return BodyMetrics(
      shoulderWidth: shoulderWidth,
      hipWidth: hipWidth,
      torsoHeight: torsoHeight,
      shoulderToHipRatio: hipWidth == 0 ? 0 : shoulderWidth / hipWidth,
      bodyRotationDegrees: bodyRotationDegrees,
      orientation: orientation,
    );
  }

  double _distance2D(PoseKeypoint a, PoseKeypoint b) {
    final dx = a.x - b.x;
    final dy = a.y - b.y;
    return math.sqrt(dx * dx + dy * dy);
  }
}
