import 'dart:math' as math;

/// A single color sample in three color spaces at once, computed from one
/// RGB reading. Kept together because the skin-tone classifier looks at
/// LAB lightness primarily but HSV/RGB are useful for debugging/display.
class ColorSample {
  const ColorSample({
    required this.r,
    required this.g,
    required this.b,
    required this.h,
    required this.s,
    required this.v,
    required this.l,
    required this.labA,
    required this.labB,
  });

  final int r, g, b; // 0-255
  final double h, s, v; // hue 0-360, saturation/value 0-1
  final double l, labA, labB; // CIELAB: L 0-100, a/b roughly -128..127

  factory ColorSample.fromRgb(int r, int g, int b) {
    final hsv = ColorScience.rgbToHsv(r, g, b);
    final lab = ColorScience.rgbToLab(r, g, b);
    return ColorSample(
      r: r,
      g: g,
      b: b,
      h: hsv.$1,
      s: hsv.$2,
      v: hsv.$3,
      l: lab.$1,
      labA: lab.$2,
      labB: lab.$3,
    );
  }

  /// Perceived luminance (0-255), used to reject overexposed/underexposed
  /// pixel samples before they're averaged (see `SkinToneEstimator`).
  double get luminance => 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/// Pure color-space conversion math — no Flutter/plugin dependencies, so
/// it's trivially unit-testable and reusable anywhere pixel colors need
/// to be reasoned about in perceptual terms rather than raw RGB.
class ColorScience {
  ColorScience._();

  /// Returns (hue 0-360, saturation 0-1, value 0-1).
  static (double, double, double) rgbToHsv(int r, int g, int b) {
    final rf = r / 255.0, gf = g / 255.0, bf = b / 255.0;
    final maxV = [rf, gf, bf].reduce(math.max);
    final minV = [rf, gf, bf].reduce(math.min);
    final delta = maxV - minV;

    double hue = 0;
    if (delta != 0) {
      if (maxV == rf) {
        hue = 60 * (((gf - bf) / delta) % 6);
      } else if (maxV == gf) {
        hue = 60 * (((bf - rf) / delta) + 2);
      } else {
        hue = 60 * (((rf - gf) / delta) + 4);
      }
    }
    if (hue < 0) hue += 360;

    final saturation = maxV == 0 ? 0.0 : delta / maxV;
    return (hue, saturation, maxV);
  }

  /// Returns (L, a, b) in CIELAB space, via sRGB -> linear RGB -> XYZ (D65)
  /// -> LAB. Standard formulas; see any colorimetry reference (e.g. Bruce
  /// Lindbloom's widely-cited conversion notes) for the constants used.
  static (double, double, double) rgbToLab(int r, int g, int b) {
    double toLinear(int c) {
      final v = c / 255.0;
      return v <= 0.04045 ? v / 12.92 : math.pow((v + 0.055) / 1.055, 2.4).toDouble();
    }

    final rl = toLinear(r), gl = toLinear(g), bl = toLinear(b);

    // sRGB (D65) -> XYZ
    final x = rl * 0.4124564 + gl * 0.3575761 + bl * 0.1804375;
    final y = rl * 0.2126729 + gl * 0.7151522 + bl * 0.0721750;
    final z = rl * 0.0193339 + gl * 0.1191920 + bl * 0.9503041;

    // Normalize by the D65 reference white, then XYZ -> LAB.
    const xn = 0.95047, yn = 1.0, zn = 1.08883;
    double f(double t) =>
        t > 0.008856 ? math.pow(t, 1 / 3).toDouble() : (7.787 * t) + (16 / 116);

    final fx = f(x / xn), fy = f(y / yn), fz = f(z / zn);

    final l = (116 * fy) - 16;
    final a = 500 * (fx - fy);
    final labB = 200 * (fy - fz);
    return (l, a, labB);
  }
}
