import 'dart:math' as math;
import 'dart:ui';

import 'package:camera/camera.dart';

import '../../../smart_camera/domain/entities/camera_frame.dart';
import '../entities/face_analysis.dart';
import '../entities/skin_tone.dart';
import 'color_science.dart';

/// Skin-tone analysis per the spec's "SKIN TONE ANALYSIS" section: samples
/// multiple points across both cheeks, converts each to RGB/HSV/LAB,
/// discards over/under-exposed samples ("avoid highlights and shadows"),
/// averages what's left, and classifies the result into one of six tones.
///
/// This reads raw pixels directly out of the `CameraImage` at the cheek
/// landmark coordinates — no image decode/library needed, just YUV420/
/// BGRA8888 pixel math, so it stays fast enough to run per-frame.
class SkinToneEstimator {
  const SkinToneEstimator();

  static const _sampleRadius = 4; // pixels, in each direction from center
  static const _sampleStep = 2; // skip every other pixel — plenty of samples, less work

  // Perceived-luminance (0-255) bounds a sample must fall within to be
  // trusted — outside this range the pixel is more likely a specular
  // highlight or a shadow than representative skin color.
  static const _minLuminance = 40.0;
  static const _maxLuminance = 225.0;

  SkinToneSample? sample(CameraFrame frame, FaceAnalysis face) {
    final leftCheek = face.landmarks[FaceLandmarkKind.leftCheek];
    final rightCheek = face.landmarks[FaceLandmarkKind.rightCheek];
    if (leftCheek == null || rightCheek == null) return null;

    // Spec asks for "multiple cheek samples" — in addition to the two
    // primary landmark points, add a secondary point per side nudged
    // toward the nose, which stays reliably on skin rather than drifting
    // toward hair/ears/background as face angle varies.
    final midOffset = (rightCheek.dx - leftCheek.dx) * 0.08;
    final samplePoints = <Offset>[
      leftCheek,
      rightCheek,
      Offset(leftCheek.dx + midOffset, leftCheek.dy),
      Offset(rightCheek.dx - midOffset, rightCheek.dy),
    ];

    final validSamples = <ColorSample>[];
    var totalCount = 0;

    for (final point in samplePoints) {
      for (final color in _samplePixelBlock(frame.image, point)) {
        totalCount++;
        if (color.luminance >= _minLuminance && color.luminance <= _maxLuminance) {
          validSamples.add(color);
        }
      }
    }

    if (validSamples.isEmpty) return null;

    final avgR = (validSamples.map((c) => c.r).reduce((a, b) => a + b) / validSamples.length).round();
    final avgG = (validSamples.map((c) => c.g).reduce((a, b) => a + b) / validSamples.length).round();
    final avgB = (validSamples.map((c) => c.b).reduce((a, b) => a + b) / validSamples.length).round();
    final averageColor = ColorSample.fromRgb(avgR, avgG, avgB);

    return SkinToneSample(
      tone: _classify(averageColor),
      averageColor: averageColor,
      validSampleCount: validSamples.length,
      totalSampleCount: totalCount,
    );
  }

  List<ColorSample> _samplePixelBlock(CameraImage image, Offset center) {
    final results = <ColorSample>[];
    final cx = center.dx.round();
    final cy = center.dy.round();

    for (var dy = -_sampleRadius; dy <= _sampleRadius; dy += _sampleStep) {
      for (var dx = -_sampleRadius; dx <= _sampleRadius; dx += _sampleStep) {
        final x = cx + dx;
        final y = cy + dy;
        if (x < 0 || y < 0 || x >= image.width || y >= image.height) continue;

        final rgb = _readPixel(image, x, y);
        if (rgb != null) results.add(ColorSample.fromRgb(rgb.$1, rgb.$2, rgb.$3));
      }
    }
    return results;
  }

  /// Reads one pixel as (r, g, b), or `null` if the format isn't one we
  /// know how to decode or the coordinates are out of range for the
  /// plane's actual stride. Supports the two formats Module 4's camera
  /// datasource requests: BGRA8888 (iOS) and YUV420 (Android).
  (int, int, int)? _readPixel(CameraImage image, int x, int y) {
    try {
      switch (image.format.group) {
        case ImageFormatGroup.bgra8888:
          final plane = image.planes[0];
          const bytesPerPixel = 4;
          final index = y * plane.bytesPerRow + x * bytesPerPixel;
          if (index + 2 >= plane.bytes.length) return null;
          final b = plane.bytes[index];
          final g = plane.bytes[index + 1];
          final r = plane.bytes[index + 2];
          return (r, g, b);

        case ImageFormatGroup.yuv420:
          final yPlane = image.planes[0];
          final uPlane = image.planes[1];
          final vPlane = image.planes[2];

          final yIndex = y * yPlane.bytesPerRow + x * (yPlane.bytesPerPixel ?? 1);
          if (yIndex < 0 || yIndex >= yPlane.bytes.length) return null;
          final yVal = yPlane.bytes[yIndex];

          final uvRow = y ~/ 2;
          final uvCol = x ~/ 2;
          final uIndex = uvRow * uPlane.bytesPerRow + uvCol * (uPlane.bytesPerPixel ?? 1);
          final vIndex = uvRow * vPlane.bytesPerRow + uvCol * (vPlane.bytesPerPixel ?? 1);
          if (uIndex < 0 || uIndex >= uPlane.bytes.length) return null;
          if (vIndex < 0 || vIndex >= vPlane.bytes.length) return null;

          return _yuvToRgb(yVal, uPlane.bytes[uIndex], vPlane.bytes[vIndex]);

        default:
          return null;
      }
    } catch (_) {
      // Any stride/plane-layout surprise on a given device — skip this
      // sample rather than crash the whole detection pipeline over it.
      return null;
    }
  }

  (int, int, int) _yuvToRgb(int y, int u, int v) {
    final c = y - 16;
    final d = u - 128;
    final e = v - 128;
    final r = (298 * c + 409 * e + 128) >> 8;
    final g = (298 * c - 100 * d - 208 * e + 128) >> 8;
    final b = (298 * c + 516 * d + 128) >> 8;
    return (r.clamp(0, 255), g.clamp(0, 255), b.clamp(0, 255));
  }

  /// Classifies primarily on CIELAB lightness (L), with a hue-angle check
  /// in the a*/b* plane to catch the yellow-green "olive" undertone that
  /// lightness alone can't distinguish from Medium/Brown. Thresholds are a
  /// documented heuristic, not a clinically validated skin-tone scale —
  /// see the module README for the honest caveats on accuracy.
  SkinTone _classify(ColorSample color) {
    final rawHueAngle = math.atan2(color.labB, color.labA) * 180 / math.pi;
    final hueAngle = rawHueAngle < 0 ? rawHueAngle + 360 : rawHueAngle;
    final isOliveUndertone = hueAngle > 75 && hueAngle < 130 && color.l >= 45 && color.l < 68;

    if (isOliveUndertone) return SkinTone.olive;
    if (color.l >= 80) return SkinTone.fair;
    if (color.l >= 68) return SkinTone.light;
    if (color.l >= 55) return SkinTone.medium;
    if (color.l >= 40) return SkinTone.brown;
    return SkinTone.dark;
  }
}
