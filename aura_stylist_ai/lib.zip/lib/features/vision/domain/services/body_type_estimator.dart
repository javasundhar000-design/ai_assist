import '../entities/body_metrics.dart';

/// Heuristic body-type estimate from shoulder-to-hip proportions.
///
/// A real product would combine this with height, weight, and more
/// landmarks (or a trained model) for real accuracy — this uses the one
/// signal reliably derivable from a single 2D pose frame: the ratio of
/// shoulder width to hip width. Thresholds below are a reasonable starting
/// point based on common proportion heuristics, not a validated model;
/// like `FaceShapeEstimator`, this is swappable for a trained-model
/// implementation later without touching any caller.
class BodyTypeEstimator {
  const BodyTypeEstimator();

  BodyType? estimate(BodyMetrics metrics) {
    final ratio = metrics.shoulderToHipRatio;
    if (ratio <= 0) return null;

    if (ratio >= 1.25) return BodyType.athletic; // shoulders notably broader than hips
    if (ratio >= 1.05) return BodyType.average; // slightly shoulder-dominant, balanced
    if (ratio >= 0.92) return BodyType.slim; // roughly even, narrower overall frame signal
    return BodyType.broad; // hip-dominant proportions
  }
}
