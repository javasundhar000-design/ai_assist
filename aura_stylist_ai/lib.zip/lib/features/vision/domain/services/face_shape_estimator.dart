import 'dart:ui';

import '../entities/face_analysis.dart';
import '../entities/face_shape.dart';

/// Best-effort GEOMETRIC estimate of face shape from ML Kit's landmarks
/// and face contour — not a trained classifier.
///
/// Real face-shape products typically train a small CNN on labeled faces
/// for this. This approximates the same underlying signal (relative
/// widths at forehead/cheekbone/jaw level vs. overall face length) using
/// only what ML Kit's on-device landmark/contour detector already gives us
/// for free, with zero extra model weight to ship or run. Treat results as
/// a reasonable starting point the user can always override, not a
/// guarantee — accuracy depends heavily on head pose, lighting, hair
/// covering the jawline/forehead, and how "typical" the face shape is.
///
/// Kept as its own class (rather than a static function) specifically so
/// it can be swapped for a real trained-model-backed implementation later
/// without touching any caller — `VisionPipelineController` only depends
/// on the `estimate()` signature.
class FaceShapeEstimator {
  const FaceShapeEstimator();

  FaceShape? estimate(FaceAnalysis face) {
    final faceContour = face.contours[FaceContourKind.face];
    if (faceContour == null || faceContour.length < 10) return null;

    final length = face.boundingBox.height;
    final cheekboneWidth = _distance(
          face.landmarks[FaceLandmarkKind.leftCheek],
          face.landmarks[FaceLandmarkKind.rightCheek],
        ) ??
        face.boundingBox.width;

    if (cheekboneWidth <= 0 || length <= 0) return null;

    final foreheadWidth = _widthAtHeightFraction(faceContour, face.boundingBox, 0.12);
    final jawWidth = _widthAtHeightFraction(faceContour, face.boundingBox, 0.88);

    final lengthToWidthRatio = length / cheekboneWidth;
    final jawToCheekRatio = jawWidth / cheekboneWidth;
    final foreheadToCheekRatio = foreheadWidth / cheekboneWidth;

    // Long face, jaw noticeably narrower than cheekbones: heart (if
    // forehead is the widest point) or diamond (if cheekbones are widest
    // and both forehead and jaw taper in).
    if (lengthToWidthRatio > 1.5 && jawToCheekRatio < 0.85) {
      return foreheadToCheekRatio > jawToCheekRatio ? FaceShape.heart : FaceShape.diamond;
    }

    // Long face, proportions otherwise fairly even: oval.
    if (lengthToWidthRatio > 1.45) return FaceShape.oval;

    // Forehead, cheekbones, and jaw all similarly wide: square (sharper,
    // shorter face) or round (softer, slightly longer face) — the ratio
    // threshold is the only signal available without curvature analysis.
    if (jawToCheekRatio > 0.9 && foreheadToCheekRatio > 0.9) {
      return lengthToWidthRatio < 1.15 ? FaceShape.square : FaceShape.round;
    }

    // No strong signal either way — oval is the most common shape and the
    // safest default rather than forcing a low-confidence guess.
    return FaceShape.oval;
  }

  double? _distance(Offset? a, Offset? b) {
    if (a == null || b == null) return null;
    return (a - b).distance;
  }

  /// Finds the horizontal width of the face contour at a given fraction
  /// down the bounding box (e.g. 0.12 = near the forehead, 0.88 = near the
  /// jawline), by scanning contour points near that height band.
  double _widthAtHeightFraction(List<Offset> contour, Rect box, double fraction) {
    final targetY = box.top + box.height * fraction;
    final band = box.height * 0.06;

    Offset? leftMost;
    Offset? rightMost;
    for (final point in contour) {
      if ((point.dy - targetY).abs() > band) continue;
      if (leftMost == null || point.dx < leftMost.dx) leftMost = point;
      if (rightMost == null || point.dx > rightMost.dx) rightMost = point;
    }

    if (leftMost == null || rightMost == null) return box.width;
    return (rightMost.dx - leftMost.dx).abs();
  }
}
