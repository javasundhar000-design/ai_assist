import 'dart:io';
import 'dart:typed_data';
import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../../smart_camera/domain/entities/camera_frame.dart';

/// Converts a `CameraFrame` (from Module 4's camera pipeline) into ML
/// Kit's `InputImage`.
///
/// ⚠️ This is the single most device-fragile piece of code in this module.
/// Getting rotation and pixel format right for every Android OEM camera
/// stack is a famously fiddly part of any Flutter + ML Kit integration —
/// see the README's Module 5 section for what to test on a real device.
/// The rotation-compensation table below follows the same approach used in
/// Google's own ML Kit Flutter sample app.
class InputImageConverter {
  InputImageConverter._();

  // Maps a *device* orientation to the rotation compensation (in degrees)
  // needed on Android, where `CameraDescription.sensorOrientation` is
  // fixed relative to the physical device but the UI can rotate.
  static const _orientations = {
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  /// [deviceOrientation] is hardcoded to `portraitUp` by callers for now —
  /// the Smart Mirror screen is portrait-only in this build (see the
  /// module README's "known limitations"). Wiring up a real device-
  /// orientation stream (e.g. via a sensor plugin) to support landscape is
  /// a documented follow-up, not in Module 5's scope.
  static InputImage? fromCameraFrame(
    CameraFrame frame, {
    DeviceOrientation deviceOrientation = DeviceOrientation.portraitUp,
  }) {
    final rotation = _rotationFor(frame, deviceOrientation);
    if (rotation == null) return null;

    final bytes = _bytesFor(frame.image);
    if (bytes == null) return null;

    final format = _formatFor(frame.image);
    if (format == null) return null;

    final plane = frame.image.planes.first;

    return InputImage.fromBytes(
      bytes: bytes,
      metadata: InputImageMetadata(
        size: Size(frame.image.width.toDouble(), frame.image.height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  static InputImageRotation? _rotationFor(
    CameraFrame frame,
    DeviceOrientation deviceOrientation,
  ) {
    return rotationForSensor(
      sensorOrientation: frame.sensorOrientation,
      lensDirection: frame.lensDirection,
      deviceOrientation: deviceOrientation,
    );
  }

  /// Public so `VisionOverlay` can compute the exact same rotation (from a
  /// `CameraController`'s description) to correctly position landmark
  /// overlays — single source of truth for the rotation-compensation math
  /// instead of two places that could drift out of sync.
  static InputImageRotation? rotationForSensor({
    required int sensorOrientation,
    required CameraLensDirection lensDirection,
    DeviceOrientation deviceOrientation = DeviceOrientation.portraitUp,
  }) {
    if (Platform.isIOS) {
      return InputImageRotationValue.fromRawValue(sensorOrientation);
    }

    if (Platform.isAndroid) {
      var rotationCompensation = _orientations[deviceOrientation];
      if (rotationCompensation == null) return null;

      if (lensDirection == CameraLensDirection.front) {
        rotationCompensation = (sensorOrientation + rotationCompensation) % 360;
      } else {
        rotationCompensation = (sensorOrientation - rotationCompensation + 360) % 360;
      }
      return InputImageRotationValue.fromRawValue(rotationCompensation);
    }

    return null;
  }

  static InputImageFormat? _formatFor(CameraImage image) {
    // ML Kit only accepts NV21 on Android and BGRA8888 on iOS — both of
    // which we normalize to below regardless of how the plane data
    // actually arrived, so this is intentionally always one of these two.
    return Platform.isAndroid ? InputImageFormat.nv21 : InputImageFormat.bgra8888;
  }

  static Uint8List? _bytesFor(CameraImage image) {
    if (Platform.isIOS) {
      // iOS delivers a single BGRA8888 plane already in the layout ML Kit
      // expects — no conversion needed.
      if (image.planes.length != 1) return null;
      return image.planes.first.bytes;
    }

    if (Platform.isAndroid) {
      // Some devices/plugin versions already hand back a single NV21-like
      // plane; most deliver 3-plane YUV420 (Y, U, V) and need conversion.
      if (image.planes.length == 1) return image.planes.first.bytes;
      if (image.planes.length == 3) return _yuv420ToNv21(image);
      return null;
    }

    return null;
  }

  /// Converts 3-plane YUV420 (as delivered by `ImageFormatGroup.yuv420`)
  /// into single-plane NV21 (Y plane followed by interleaved V,U pairs),
  /// which is what ML Kit's Android pipeline expects.
  ///
  /// Respects each plane's `bytesPerRow` (stride), which is commonly wider
  /// than the image's logical width due to padding — a very common source
  /// of subtly-corrupted-looking frames if ignored. Even so, exact plane
  /// layout (particularly `bytesPerPixel` for the chroma planes) varies
  /// across Android OEM camera stacks; this follows the standard/most
  /// common layout, but if detection looks visibly wrong on a specific
  /// device, this is the first place to check.
  static Uint8List _yuv420ToNv21(CameraImage image) {
    final width = image.width;
    final height = image.height;
    final ySize = width * height;
    final uvSize = width * height ~/ 2;
    final nv21 = Uint8List(ySize + uvSize);

    final yPlane = image.planes[0];
    final uPlane = image.planes[1];
    final vPlane = image.planes[2];

    var outputIndex = 0;
    for (var row = 0; row < height; row++) {
      final rowStart = row * yPlane.bytesPerRow;
      nv21.setRange(outputIndex, outputIndex + width, yPlane.bytes, rowStart);
      outputIndex += width;
    }

    final uvPixelStride = uPlane.bytesPerPixel ?? 1;
    final vPixelStride = vPlane.bytesPerPixel ?? 1;
    final chromaHeight = height ~/ 2;
    final chromaWidth = width ~/ 2;

    for (var row = 0; row < chromaHeight; row++) {
      for (var col = 0; col < chromaWidth; col++) {
        final uIndex = row * uPlane.bytesPerRow + col * uvPixelStride;
        final vIndex = row * vPlane.bytesPerRow + col * vPixelStride;
        if (uIndex >= uPlane.bytes.length || vIndex >= vPlane.bytes.length) continue;
        // NV21 byte order is Y-plane then interleaved V,U (not U,V).
        nv21[outputIndex++] = vPlane.bytes[vIndex];
        nv21[outputIndex++] = uPlane.bytes[uIndex];
      }
    }

    return nv21;
  }
}
