import 'dart:ui';

import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart' as mlkit;

import '../../domain/entities/face_analysis.dart';

class FaceMapper {
  FaceMapper._();

  static const _landmarkTypeMap = {
    mlkit.FaceLandmarkType.leftEye: FaceLandmarkKind.leftEye,
    mlkit.FaceLandmarkType.rightEye: FaceLandmarkKind.rightEye,
    mlkit.FaceLandmarkType.leftEar: FaceLandmarkKind.leftEar,
    mlkit.FaceLandmarkType.rightEar: FaceLandmarkKind.rightEar,
    mlkit.FaceLandmarkType.leftCheek: FaceLandmarkKind.leftCheek,
    mlkit.FaceLandmarkType.rightCheek: FaceLandmarkKind.rightCheek,
    mlkit.FaceLandmarkType.noseBase: FaceLandmarkKind.noseBase,
    mlkit.FaceLandmarkType.leftMouth: FaceLandmarkKind.leftMouth,
    mlkit.FaceLandmarkType.rightMouth: FaceLandmarkKind.rightMouth,
    mlkit.FaceLandmarkType.bottomMouth: FaceLandmarkKind.bottomMouth,
  };

  static const _contourTypeMap = {
    mlkit.FaceContourType.face: FaceContourKind.face,
    mlkit.FaceContourType.leftEyebrowTop: FaceContourKind.leftEyebrowTop,
    mlkit.FaceContourType.leftEyebrowBottom: FaceContourKind.leftEyebrowBottom,
    mlkit.FaceContourType.rightEyebrowTop: FaceContourKind.rightEyebrowTop,
    mlkit.FaceContourType.rightEyebrowBottom: FaceContourKind.rightEyebrowBottom,
    mlkit.FaceContourType.leftEye: FaceContourKind.leftEye,
    mlkit.FaceContourType.rightEye: FaceContourKind.rightEye,
    mlkit.FaceContourType.upperLipTop: FaceContourKind.upperLipTop,
    mlkit.FaceContourType.upperLipBottom: FaceContourKind.upperLipBottom,
    mlkit.FaceContourType.lowerLipTop: FaceContourKind.lowerLipTop,
    mlkit.FaceContourType.lowerLipBottom: FaceContourKind.lowerLipBottom,
    mlkit.FaceContourType.noseBridge: FaceContourKind.noseBridge,
    mlkit.FaceContourType.noseBottom: FaceContourKind.noseBottom,
  };

  static FaceAnalysis fromMlkitFace(mlkit.Face face, Size imageSize) {
    final landmarks = <FaceLandmarkKind, Offset>{};
    for (final entry in _landmarkTypeMap.entries) {
      final landmark = face.landmarks[entry.key];
      if (landmark?.position != null) {
        landmarks[entry.value] = Offset(
          landmark!.position.x.toDouble(),
          landmark.position.y.toDouble(),
        );
      }
    }

    final contours = <FaceContourKind, List<Offset>>{};
    for (final entry in _contourTypeMap.entries) {
      final contour = face.contours[entry.key];
      final points = contour?.points;
      if (points != null && points.isNotEmpty) {
        contours[entry.value] =
            points.map((p) => Offset(p.x.toDouble(), p.y.toDouble())).toList();
      }
    }

    return FaceAnalysis(
      boundingBox: face.boundingBox,
      landmarks: landmarks,
      contours: contours,
      headEulerAngleX: face.headEulerAngleX ?? 0,
      headEulerAngleY: face.headEulerAngleY ?? 0,
      headEulerAngleZ: face.headEulerAngleZ ?? 0,
      imageSize: imageSize,
      smilingProbability: face.smilingProbability,
      leftEyeOpenProbability: face.leftEyeOpenProbability,
      rightEyeOpenProbability: face.rightEyeOpenProbability,
      trackingId: face.trackingId,
    );
  }
}
