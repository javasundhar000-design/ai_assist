import 'dart:ui';

import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart' as mlkit;

import '../../domain/entities/pose_analysis.dart';

class PoseMapper {
  PoseMapper._();

  static const _landmarkTypeMap = {
    mlkit.PoseLandmarkType.nose: PoseLandmarkKind.nose,
    mlkit.PoseLandmarkType.leftShoulder: PoseLandmarkKind.leftShoulder,
    mlkit.PoseLandmarkType.rightShoulder: PoseLandmarkKind.rightShoulder,
    mlkit.PoseLandmarkType.leftElbow: PoseLandmarkKind.leftElbow,
    mlkit.PoseLandmarkType.rightElbow: PoseLandmarkKind.rightElbow,
    mlkit.PoseLandmarkType.leftWrist: PoseLandmarkKind.leftWrist,
    mlkit.PoseLandmarkType.rightWrist: PoseLandmarkKind.rightWrist,
    mlkit.PoseLandmarkType.leftHip: PoseLandmarkKind.leftHip,
    mlkit.PoseLandmarkType.rightHip: PoseLandmarkKind.rightHip,
    mlkit.PoseLandmarkType.leftKnee: PoseLandmarkKind.leftKnee,
    mlkit.PoseLandmarkType.rightKnee: PoseLandmarkKind.rightKnee,
    mlkit.PoseLandmarkType.leftAnkle: PoseLandmarkKind.leftAnkle,
    mlkit.PoseLandmarkType.rightAnkle: PoseLandmarkKind.rightAnkle,
  };

  static PoseAnalysis fromMlkitPose(mlkit.Pose pose, Size imageSize) {
    final landmarks = <PoseLandmarkKind, PoseKeypoint>{};
    for (final entry in _landmarkTypeMap.entries) {
      final landmark = pose.landmarks[entry.key];
      if (landmark != null) {
        landmarks[entry.value] = PoseKeypoint(
          x: landmark.x,
          y: landmark.y,
          z: landmark.z,
          likelihood: landmark.likelihood,
        );
      }
    }
    return PoseAnalysis(landmarks: landmarks, imageSize: imageSize);
  }
}
