import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

/// Raw ML Kit access. Created once and reused for the app's lifetime (see
/// `visionProviders.dart`) — ML Kit detectors are relatively expensive to
/// spin up, and are explicitly designed to be reused across many
/// `processImage` calls rather than recreated per frame.
class FaceDetectorDataSource {
  FaceDetectorDataSource()
      : _detector = FaceDetector(
          options: FaceDetectorOptions(
            enableContours: true, // needed for eyebrows/jawline (spec: "Eyebrows", face shape)
            enableLandmarks: true, // eyes, ears, cheeks, nose, mouth
            enableClassification: true, // smiling / eyes-open probabilities
            enableTracking: true, // stable trackingId across frames
            performanceMode: FaceDetectorMode.fast, // tuned for live video, not single photos
          ),
        );

  final FaceDetector _detector;

  Future<List<Face>> process(InputImage inputImage) => _detector.processImage(inputImage);

  Future<void> close() => _detector.close();
}
