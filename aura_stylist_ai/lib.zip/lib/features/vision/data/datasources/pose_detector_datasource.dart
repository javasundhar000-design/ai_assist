import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

class PoseDetectorDataSource {
  PoseDetectorDataSource()
      : _detector = PoseDetector(
          options: PoseDetectorOptions(
            mode: PoseDetectionMode.stream, // tuned for live video, not single photos
          ),
        );

  final PoseDetector _detector;

  Future<List<Pose>> process(InputImage inputImage) => _detector.processImage(inputImage);

  Future<void> close() => _detector.close();
}
