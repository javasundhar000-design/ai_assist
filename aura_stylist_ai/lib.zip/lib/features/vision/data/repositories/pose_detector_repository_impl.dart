import 'dart:ui';

import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/pose_analysis.dart';
import '../../domain/repositories/pose_detector_repository.dart';
import '../datasources/pose_detector_datasource.dart';
import '../mappers/pose_mapper.dart';

class PoseDetectorRepositoryImpl implements PoseDetectorRepository {
  PoseDetectorRepositoryImpl(this._dataSource);

  final PoseDetectorDataSource _dataSource;

  @override
  Future<Result<PoseAnalysis?>> detectPose(InputImage inputImage) async {
    try {
      final poses = await _dataSource.process(inputImage);
      if (poses.isEmpty) return const Success(null);

      final size = inputImage.metadata?.size;
      final imageSize = size ?? const Size(0, 0);
      return Success(PoseMapper.fromMlkitPose(poses.first, imageSize));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<void> dispose() => _dataSource.close();
}
