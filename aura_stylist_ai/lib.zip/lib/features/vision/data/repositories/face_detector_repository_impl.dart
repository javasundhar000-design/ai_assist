import 'dart:ui';

import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../../../core/errors/failure.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/face_analysis.dart';
import '../../domain/repositories/face_detector_repository.dart';
import '../datasources/face_detector_datasource.dart';
import '../mappers/face_mapper.dart';

class FaceDetectorRepositoryImpl implements FaceDetectorRepository {
  FaceDetectorRepositoryImpl(this._dataSource);

  final FaceDetectorDataSource _dataSource;

  @override
  Future<Result<FaceAnalysis?>> detectPrimaryFace(InputImage inputImage) async {
    try {
      final faces = await _dataSource.process(inputImage);
      if (faces.isEmpty) return const Success(null);

      // Multiple people could be in frame — assume the largest face is the
      // person actually standing in front of the Smart Mirror.
      faces.sort((a, b) {
        final areaA = a.boundingBox.width * a.boundingBox.height;
        final areaB = b.boundingBox.width * b.boundingBox.height;
        return areaB.compareTo(areaA);
      });

      final size = inputImage.metadata?.size;
      final imageSize = size ?? const Size(0, 0);
      return Success(FaceMapper.fromMlkitFace(faces.first, imageSize));
    } catch (e) {
      return Err(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<void> dispose() => _dataSource.close();
}
