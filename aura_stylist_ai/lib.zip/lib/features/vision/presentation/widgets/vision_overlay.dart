import 'package:camera/camera.dart';
import 'package:flutter/widgets.dart';

import '../../data/utils/input_image_converter.dart';
import '../painters/face_overlay_painter.dart';
import '../painters/pose_overlay_painter.dart';
import '../providers/vision_pipeline_controller.dart';

/// Layers face/pose overlay painters on top of the camera preview.
///
/// Must be sized identically to the `CameraPreview` texture it overlays —
/// `SmartCameraPage` achieves this by wrapping both this widget and
/// `MirroredCameraPreview` in the same fixed-size box (scaled to fill the
/// screen via `FittedBox`), so this widget only needs `size` (from
/// `LayoutBuilder`) to correctly map ML Kit's image-space coordinates
/// onto the canvas (see `CoordinateTranslator`).
class VisionOverlay extends StatelessWidget {
  const VisionOverlay({
    super.key,
    required this.controller,
    required this.state,
  });

  final CameraController controller;
  final VisionAnalysisState state;

  @override
  Widget build(BuildContext context) {
    final rotation = InputImageConverter.rotationForSensor(
      sensorOrientation: controller.description.sensorOrientation,
      lensDirection: controller.description.lensDirection,
    );
    if (rotation == null) return const SizedBox.shrink();

    return IgnorePointer(
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (state.face != null)
            CustomPaint(
              painter: FaceOverlayPainter(
                face: state.face!,
                rotation: rotation,
                lensDirection: controller.description.lensDirection,
              ),
            ),
          if (state.pose != null)
            CustomPaint(
              painter: PoseOverlayPainter(
                pose: state.pose!,
                rotation: rotation,
                lensDirection: controller.description.lensDirection,
              ),
            ),
        ],
      ),
    );
  }
}
