import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../smart_camera/domain/entities/camera_frame.dart';
import '../../../smart_camera/presentation/providers/camera_providers.dart';
import '../../data/utils/input_image_converter.dart';
import '../../domain/entities/body_metrics.dart';
import '../../domain/entities/face_analysis.dart';
import '../../domain/entities/face_shape.dart';
import '../../domain/entities/pose_analysis.dart';
import '../../domain/entities/skin_tone.dart';
import '../../domain/services/body_metrics_calculator.dart';
import '../../domain/services/body_type_estimator.dart';
import '../../domain/services/face_shape_estimator.dart';
import '../../domain/services/skin_tone_estimator.dart';
import 'vision_providers.dart';

class VisionAnalysisState {
  const VisionAnalysisState({
    this.isRunning = false,
    this.face,
    this.pose,
    this.faceShape,
    this.skinToneSample,
    this.bodyType,
    this.bodyMetrics,
    this.lastUpdated,
    this.errorMessage,
  });

  final bool isRunning;
  final FaceAnalysis? face;
  final PoseAnalysis? pose;
  final FaceShape? faceShape;
  final SkinToneSample? skinToneSample;
  final BodyType? bodyType;
  final BodyMetrics? bodyMetrics;
  final DateTime? lastUpdated;
  final String? errorMessage;

  bool get hasFace => face != null;
  bool get hasPose => pose != null;

  VisionAnalysisState copyWith({
    bool? isRunning,
    FaceAnalysis? face,
    PoseAnalysis? pose,
    FaceShape? faceShape,
    SkinToneSample? skinToneSample,
    BodyType? bodyType,
    BodyMetrics? bodyMetrics,
    DateTime? lastUpdated,
    String? errorMessage,
    bool clearFace = false,
    bool clearPose = false,
  }) {
    return VisionAnalysisState(
      isRunning: isRunning ?? this.isRunning,
      face: clearFace ? null : (face ?? this.face),
      pose: clearPose ? null : (pose ?? this.pose),
      faceShape: clearFace ? null : (faceShape ?? this.faceShape),
      skinToneSample: clearFace ? null : (skinToneSample ?? this.skinToneSample),
      bodyType: clearPose ? null : (bodyType ?? this.bodyType),
      bodyMetrics: clearPose ? null : (bodyMetrics ?? this.bodyMetrics),
      lastUpdated: lastUpdated ?? this.lastUpdated,
      errorMessage: errorMessage,
    );
  }
}

/// Subscribes independently to the same broadcast `frameStream` Module 4's
/// `FrameStreamController` uses (both can listen at once — `startFrameStream`
/// on the camera repository is idempotent), converts each frame to an ML
/// Kit `InputImage`, runs face + pose detection concurrently, and derives
/// face shape / skin tone / body type from the results.
///
/// Frames are dropped (not queued) while a previous frame is still being
/// processed — ML Kit inference takes tens of milliseconds, camera frames
/// arrive much faster than that, and queuing would make the pipeline fall
/// further and further behind real time instead of staying live.
///
/// Known simplification: results are only ever replaced by a *new*
/// detection, never cleared just because one frame had no face/pose (to
/// avoid HUD flicker during brief detection gaps, e.g. a blink or fast
/// movement). They're only cleared on `stop()`. A production build would
/// likely add a short "stale after N seconds" timeout — noted as a
/// follow-up rather than implemented here.
class VisionPipelineController extends StateNotifier<VisionAnalysisState> {
  VisionPipelineController(this._ref) : super(const VisionAnalysisState());

  final Ref _ref;
  StreamSubscription<CameraFrame>? _subscription;
  bool _isProcessing = false;

  static const _faceShapeEstimator = FaceShapeEstimator();
  static const _skinToneEstimator = SkinToneEstimator();
  static const _bodyMetricsCalculator = BodyMetricsCalculator();
  static const _bodyTypeEstimator = BodyTypeEstimator();

  Future<void> start() async {
    if (_subscription != null) return;

    final cameraRepository = _ref.read(cameraRepositoryProvider);
    await cameraRepository.startFrameStream(); // no-op if already streaming
    _subscription = cameraRepository.frameStream.listen(_onFrame);
    if (mounted) state = state.copyWith(isRunning: true);
  }

  Future<void> stop() async {
    await _subscription?.cancel();
    _subscription = null;
    if (mounted) {
      state = const VisionAnalysisState(isRunning: false);
    }
  }

  Future<void> _onFrame(CameraFrame frame) async {
    if (_isProcessing) return;
    _isProcessing = true;

    try {
      final inputImage = InputImageConverter.fromCameraFrame(frame);
      if (inputImage == null) return;

      final faceRepo = _ref.read(faceDetectorRepositoryProvider);
      final poseRepo = _ref.read(poseDetectorRepositoryProvider);

      final results = await Future.wait([
        faceRepo.detectPrimaryFace(inputImage),
        poseRepo.detectPose(inputImage),
      ]);

      final face = results[0].valueOrNull as FaceAnalysis?;
      final pose = results[1].valueOrNull as PoseAnalysis?;

      FaceShape? faceShape;
      SkinToneSample? skinToneSample;
      if (face != null) {
        faceShape = _faceShapeEstimator.estimate(face);
        skinToneSample = _skinToneEstimator.sample(frame, face);
      }

      BodyMetrics? bodyMetrics;
      BodyType? bodyType;
      if (pose != null) {
        bodyMetrics = _bodyMetricsCalculator.calculate(pose);
        if (bodyMetrics != null) bodyType = _bodyTypeEstimator.estimate(bodyMetrics);
      }

      if (!mounted) return;
      state = state.copyWith(
        face: face,
        pose: pose,
        faceShape: faceShape,
        skinToneSample: skinToneSample,
        bodyType: bodyType,
        bodyMetrics: bodyMetrics,
        lastUpdated: DateTime.now(),
        errorMessage: null,
      );
    } catch (e) {
      if (mounted) state = state.copyWith(errorMessage: e.toString());
    } finally {
      _isProcessing = false;
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}

final visionPipelineControllerProvider =
    StateNotifierProvider.autoDispose<VisionPipelineController, VisionAnalysisState>(
  (ref) => VisionPipelineController(ref),
);
