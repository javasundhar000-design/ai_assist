import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/face_detector_datasource.dart';
import '../../data/datasources/pose_detector_datasource.dart';
import '../../data/repositories/face_detector_repository_impl.dart';
import '../../data/repositories/pose_detector_repository_impl.dart';
import '../../domain/repositories/face_detector_repository.dart';
import '../../domain/repositories/pose_detector_repository.dart';

/// Kept as plain (non-autoDispose) providers: ML Kit detectors are meant
/// to be created once and reused across the app's lifetime, not
/// recreated every time the Smart Mirror screen is opened — recreating
/// them per visit would repeatedly pay their (non-trivial) initialization
/// cost for no benefit.
final faceDetectorDataSourceProvider =
    Provider<FaceDetectorDataSource>((ref) => FaceDetectorDataSource());

final poseDetectorDataSourceProvider =
    Provider<PoseDetectorDataSource>((ref) => PoseDetectorDataSource());

final faceDetectorRepositoryProvider = Provider<FaceDetectorRepository>((ref) {
  return FaceDetectorRepositoryImpl(ref.watch(faceDetectorDataSourceProvider));
});

final poseDetectorRepositoryProvider = Provider<PoseDetectorRepository>((ref) {
  return PoseDetectorRepositoryImpl(ref.watch(poseDetectorDataSourceProvider));
});
