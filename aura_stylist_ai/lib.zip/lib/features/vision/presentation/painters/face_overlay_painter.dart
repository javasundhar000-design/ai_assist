import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart' show Colors;
import 'package:flutter/rendering.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../domain/entities/face_analysis.dart';
import 'coordinate_translator.dart';

/// Draws the detected face's bounding box, point landmarks (eyes, nose,
/// cheeks, mouth), and contour outlines (face outline, eyebrows, lips) —
/// the visual counterpart to the spec's "FACE DETECTION" section.
class FaceOverlayPainter extends CustomPainter {
  FaceOverlayPainter({
    required this.face,
    required this.rotation,
    required this.lensDirection,
  });

  final FaceAnalysis face;
  final InputImageRotation rotation;
  final CameraLensDirection lensDirection;

  static final _contourPaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.5
    ..color = Colors.tealAccent.withOpacity(0.7);

  static final _landmarkPaint = Paint()
    ..style = PaintingStyle.fill
    ..color = Colors.amberAccent;

  @override
  void paint(Canvas canvas, Size size) {
    Offset map(Offset point) => CoordinateTranslator.translate(
          point,
          rotation,
          size,
          face.imageSize,
          lensDirection,
        );

    // Bounding box — SKIPPED. `face.boundingBox` comes from a different
    // coordinate convention than `face.landmarks`/`face.contours` on at
    // least some ML Kit plugin versions/devices (a known upstream
    // inconsistency, not something `CoordinateTranslator` can compensate
    // for since it's not a rotation/mirroring issue — the two are simply
    // not in the same space to begin with). Feeding it through the same
    // `map()` as everything else produced a wildly oversized rectangle
    // (its edges landing off-canvas) rather than a box hugging the face.
    // The contour outline drawn below already traces the face shape
    // correctly and makes the box redundant, so rather than ship a
    // rectangle that's wrong on-device, it's left out entirely.

    // Contours (face outline, eyebrows, lips, etc.) as connected polylines.
    for (final points in face.contours.values) {
      if (points.length < 2) continue;
      final path = Path()..moveTo(map(points.first).dx, map(points.first).dy);
      for (final point in points.skip(1)) {
        final mapped = map(point);
        path.lineTo(mapped.dx, mapped.dy);
      }
      canvas.drawPath(path, _contourPaint);
    }

    // Point landmarks (eyes, nose, cheeks, mouth corners).
    for (final point in face.landmarks.values) {
      canvas.drawCircle(map(point), 3, _landmarkPaint);
    }
  }

  @override
  bool shouldRepaint(covariant FaceOverlayPainter oldDelegate) {
    return oldDelegate.face != face || oldDelegate.rotation != rotation;
  }
}
