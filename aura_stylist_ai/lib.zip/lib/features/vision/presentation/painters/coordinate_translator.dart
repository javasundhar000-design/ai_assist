import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

/// Maps a point in ML Kit's image-pixel space (the raw `CameraImage`
/// dimensions the detectors ran against) onto the canvas the overlay is
/// painted on.
///
/// ⚠️ Along with `InputImageConverter`, this is the other genuinely
/// device-fragile piece of Module 5 — getting the rotation/mirroring
/// combination exactly right for every sensor-orientation × lens-direction
/// combination is very hard to verify without a physical device to test
/// against. The formulas below follow the same approach used in Google's
/// own ML Kit Flutter sample app's `CoordinatesTranslator`. See the README
/// for what to visually check on-device.
///
/// Assumes the overlay's `CustomPaint` is sized identically to the
/// `CameraPreview` texture (both live inside the same `AspectRatio` box in
/// `VisionOverlay` — see that widget), so `canvasSize` and `imageSize`
/// alone are enough to compute the mapping without a separate widget
/// offset.
class CoordinateTranslator {
  CoordinateTranslator._();

  /// Per-axis scale factor from image-pixel space to canvas space —
  /// extracted from `translateX`/`translateY` so callers that need to
  /// scale a *magnitude* (a width or height, e.g. Module 8's clothing
  /// layer sizing) rather than translate a point can reuse the exact same
  /// rotation-aware logic instead of re-deriving it.
  static double scaleX(InputImageRotation rotation, Size canvasSize, Size imageSize) {
    switch (rotation) {
      case InputImageRotation.rotation90deg:
      case InputImageRotation.rotation270deg:
        return canvasSize.width / imageSize.height;
      case InputImageRotation.rotation0deg:
      case InputImageRotation.rotation180deg:
        return canvasSize.width / imageSize.width;
    }
  }

  static double scaleY(InputImageRotation rotation, Size canvasSize, Size imageSize) {
    switch (rotation) {
      case InputImageRotation.rotation90deg:
      case InputImageRotation.rotation270deg:
        return canvasSize.height / imageSize.width;
      case InputImageRotation.rotation0deg:
      case InputImageRotation.rotation180deg:
        return canvasSize.height / imageSize.height;
    }
  }

  static double translateX(
    double x,
    InputImageRotation rotation,
    Size canvasSize,
    Size imageSize,
    CameraLensDirection lensDirection,
  ) {
    switch (rotation) {
      case InputImageRotation.rotation90deg:
        return x * scaleX(rotation, canvasSize, imageSize);
      case InputImageRotation.rotation270deg:
        return canvasSize.width - (x * scaleX(rotation, canvasSize, imageSize));
      case InputImageRotation.rotation0deg:
      case InputImageRotation.rotation180deg:
        return lensDirection == CameraLensDirection.front
            ? canvasSize.width - (x * scaleX(rotation, canvasSize, imageSize))
            : x * scaleX(rotation, canvasSize, imageSize);
    }
  }

  static double translateY(
    double y,
    InputImageRotation rotation,
    Size canvasSize,
    Size imageSize,
  ) {
    return y * scaleY(rotation, canvasSize, imageSize);
  }

  static Offset translate(
    Offset point,
    InputImageRotation rotation,
    Size canvasSize,
    Size imageSize,
    CameraLensDirection lensDirection,
  ) {
    return Offset(
      translateX(point.dx, rotation, canvasSize, imageSize, lensDirection),
      translateY(point.dy, rotation, canvasSize, imageSize),
    );
  }
}
