import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart' show Colors;
import 'package:flutter/rendering.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

import '../../domain/entities/pose_analysis.dart';
import 'coordinate_translator.dart';

/// Draws the detected body pose as a skeleton — the visual counterpart to
/// the spec's "POSE DETECTION" section.
class PoseOverlayPainter extends CustomPainter {
  PoseOverlayPainter({
    required this.pose,
    required this.rotation,
    required this.lensDirection,
  });

  final PoseAnalysis pose;
  final InputImageRotation rotation;
  final CameraLensDirection lensDirection;

  // Bones as pairs of landmarks to connect — mirrors the spec's list
  // (shoulders, elbows, wrists, hips, knees, ankles).
  static const _bones = [
    (PoseLandmarkKind.leftShoulder, PoseLandmarkKind.rightShoulder),
    (PoseLandmarkKind.leftShoulder, PoseLandmarkKind.leftElbow),
    (PoseLandmarkKind.leftElbow, PoseLandmarkKind.leftWrist),
    (PoseLandmarkKind.rightShoulder, PoseLandmarkKind.rightElbow),
    (PoseLandmarkKind.rightElbow, PoseLandmarkKind.rightWrist),
    (PoseLandmarkKind.leftShoulder, PoseLandmarkKind.leftHip),
    (PoseLandmarkKind.rightShoulder, PoseLandmarkKind.rightHip),
    (PoseLandmarkKind.leftHip, PoseLandmarkKind.rightHip),
    (PoseLandmarkKind.leftHip, PoseLandmarkKind.leftKnee),
    (PoseLandmarkKind.leftKnee, PoseLandmarkKind.leftAnkle),
    (PoseLandmarkKind.rightHip, PoseLandmarkKind.rightKnee),
    (PoseLandmarkKind.rightKnee, PoseLandmarkKind.rightAnkle),
  ];

  static const _minLikelihood = 0.5;

  static final _bonePaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 3
    ..color = Colors.lightBlueAccent;

  static final _jointPaint = Paint()
    ..style = PaintingStyle.fill
    ..color = Colors.pinkAccent;

  @override
  void paint(Canvas canvas, Size size) {
    Offset map(PoseKeypoint point) => CoordinateTranslator.translate(
          point.offset,
          rotation,
          size,
          pose.imageSize,
          lensDirection,
        );

    for (final (startKind, endKind) in _bones) {
      final start = pose[startKind];
      final end = pose[endKind];
      if (start == null || end == null) continue;
      if (start.likelihood < _minLikelihood || end.likelihood < _minLikelihood) continue;
      canvas.drawLine(map(start), map(end), _bonePaint);
    }

    for (final point in pose.landmarks.values) {
      if (point.likelihood < _minLikelihood) continue;
      canvas.drawCircle(map(point), 4, _jointPaint);
    }
  }

  @override
  bool shouldRepaint(covariant PoseOverlayPainter oldDelegate) {
    return oldDelegate.pose != pose || oldDelegate.rotation != rotation;
  }
}
